<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.bgc{background:#C6FFFF}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from t_product3data")->result();
	$product3HostingPlans='';
	$product3HostingPlansbody='';
	
	$product3HostingPlans1Name='';
	$product3HostingPlans1Price='';
	$product3Hosting1processor='';
	$product3Hosting1RAM='';
	$product3Hosting1HDD='';
	$product3Hosting1OS='';
	$product3Hosting1LAN='';
	$product3Hosting1Application='';
	$product3Hosting1ConcurrentCalls='';
	$product3Hosting1Billing='';
	$product3Hosting1Apps='';
	$product3Hosting1Service='';
	
	$product3HostingPlans2Name='';
	$product3HostingPlans2Price='';
	$product3Hosting2processor='';
	$product3Hosting2RAM='';
	$product3Hosting2HDD='';
	$product3Hosting2OS='';
	$product3Hosting2LAN='';
	$product3Hosting2Application='';
	$product3Hosting2ConcurrentCalls='';
	$product3Hosting2Billing='';
	$product3Hosting2Apps='';
	$product3Hosting2Service='';
	
	$product3HostingPlans3Name='';
	$product3HostingPlans3Price='';
	$product3Hosting3processor='';
	$product3Hosting3RAM='';
	$product3Hosting3HDD='';
	$product3Hosting3OS='';
	$product3Hosting3LAN='';
	$product3Hosting3Application='';
	$product3Hosting3ConcurrentCalls='';
	$product3Hosting3Billing='';
	$product3Hosting3Apps='';
	$product3Hosting3Service='';
	
	$product3HostingPlans4Name='';
	$product3HostingPlans4Price='';
	$product3Hosting4processor='';
	$product3Hosting4RAM='';
	$product3Hosting4HDD='';
	$product3Hosting4OS='';
	$product3Hosting4LAN='';
	$product3Hosting4Application='';
	$product3Hosting4ConcurrentCalls='';
	$product3Hosting4Billing='';
	$product3Hosting4Apps='';
	$product3Hosting4Service='';
	
	$product3Hosting1buttonname='';
	$product3Hosting2buttonname='';
	$product3Hosting3buttonname='';
	$product3Hosting4buttonname='';
	
	$product3HostingPlanSharedDataUrl='';
	$product3HostingPlanVPSDataUrl='';
	$product3HostingPlanResellerDataUrl='';
	$product3HostingPlanDedicatedDataUrl='';
	
	
	//form section focus need to work, create 4 section focus in db then work 
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home Hosting Plans'){$product3HostingPlans = $set->value;}
			if($set->name == 'home Hosting Plans body'){$product3HostingPlansbody = $set->value;}
			
			if($set->name == 'home Hosting Plans1 Name'){$product3HostingPlans1Name = $set->value;}
			if($set->name == 'home Hosting Plans1 Price'){$product3HostingPlans1Price = $set->value;}
			if($set->name == 'home hosting1 processor'){$product3Hosting1processor = $set->value;}
			if($set->name == 'home hosting1 RAM'){$product3Hosting1RAM = $set->value;}
			if($set->name == 'home hosting1 HDD'){$product3Hosting1HDD = $set->value;}
			if($set->name == 'home hosting1 OS'){$product3Hosting1OS = $set->value;}
			if($set->name == 'home hosting1 LAN'){$product3Hosting1LAN = $set->value;}
			if($set->name == 'home hosting1 Application'){$product3Hosting1Application = $set->value;}
			if($set->name == 'home hosting1 Concurrent Calls'){$product3Hosting1ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting1 Billing'){$product3Hosting1Billing = $set->value;}
			if($set->name == 'home hosting1 Apps'){$product3Hosting1Apps = $set->value;}
			if($set->name == 'home hosting1 Service'){$product3Hosting1Service = $set->value;}
			
			if($set->name == 'home Hosting Plans2 Name'){$product3HostingPlans2Name = $set->value;}
			if($set->name == 'home Hosting Plans2 Price'){$product3HostingPlans2Price = $set->value;}
			if($set->name == 'home hosting2 processor'){$product3Hosting2processor = $set->value;}
			if($set->name == 'home hosting2 RAM'){$product3Hosting2RAM = $set->value;}
			if($set->name == 'home hosting2 HDD'){$product3Hosting2HDD = $set->value;}
			if($set->name == 'home hosting2 OS'){$product3Hosting2OS = $set->value;}
			if($set->name == 'home hosting2 LAN'){$product3Hosting2LAN = $set->value;}
			if($set->name == 'home hosting2 Application'){$product3Hosting2Application = $set->value;}
			if($set->name == 'home hosting2 Concurrent Calls'){$product3Hosting2ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting2 Billing'){$product3Hosting2Billing = $set->value;}
			if($set->name == 'home hosting2 Apps'){$product3Hosting2Apps = $set->value;}
			if($set->name == 'home hosting2 Service'){$product3Hosting2Service = $set->value;}
			
			if($set->name == 'home Hosting Plans3 Name'){$product3HostingPlans3Name = $set->value;}
			if($set->name == 'home Hosting Plans3 Price'){$product3HostingPlans3Price = $set->value;}
			if($set->name == 'home hosting3 processor'){$product3Hosting3processor = $set->value;}
			if($set->name == 'home hosting3 RAM'){$product3Hosting3RAM = $set->value;}
			if($set->name == 'home hosting3 HDD'){$product3Hosting3HDD = $set->value;}
			if($set->name == 'home hosting3 OS'){$product3Hosting3OS = $set->value;}
			if($set->name == 'home hosting3 LAN'){$product3Hosting3LAN = $set->value;}
			if($set->name == 'home hosting3 Application'){$product3Hosting3Application = $set->value;}
			if($set->name == 'home hosting3 Concurrent Calls'){$product3Hosting3ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting3 Billing'){$product3Hosting3Billing = $set->value;}
			if($set->name == 'home hosting3 Apps'){$product3Hosting3Apps = $set->value;}
			if($set->name == 'home hosting3 Service'){$product3Hosting3Service = $set->value;}
			
			if($set->name == 'home Hosting Plans4 Name'){$product3HostingPlans4Name = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$product3HostingPlans4Price = $set->value;}
			if($set->name == 'home hosting4 processor'){$product3Hosting4processor = $set->value;}
			if($set->name == 'home hosting4 RAM'){$product3Hosting4RAM = $set->value;}
			if($set->name == 'home hosting4 HDD'){$product3Hosting4HDD = $set->value;}
			if($set->name == 'home hosting4 OS'){$product3Hosting4OS = $set->value;}
			if($set->name == 'home hosting4 LAN'){$product3Hosting4LAN = $set->value;}
			if($set->name == 'home hosting4 Application'){$product3Hosting4Application = $set->value;}
			if($set->name == 'home hosting4 Concurrent Calls'){$product3Hosting4ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting4 Billing'){$product3Hosting4Billing = $set->value;}
			if($set->name == 'home hosting4 Apps'){$product3Hosting4Apps = $set->value;}
			if($set->name == 'home hosting4 Service'){$product3Hosting4Service = $set->value;}
			
			if($set->name == 'homehosting1buttonname'){$product3Hosting1buttonname = $set->value;}
			if($set->name == 'homehosting2buttonname'){$product3Hosting2buttonname = $set->value;}
			if($set->name == 'homehosting3buttonname'){$product3Hosting3buttonname = $set->value;}
			if($set->name == 'homehosting4buttonname'){$product3Hosting4buttonname = $set->value;}
			
			if($set->name == 'homeHostingPlanSharedDataUrl'){ $product3HostingPlanSharedDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanVPSDataUrl'){ $product3HostingPlanVPSDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanResellerDataUrl'){ $product3HostingPlanResellerDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanDedicatedDataUrl'){ $product3HostingPlanDedicatedDataUrl = $set->value;}
			
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Easy Recharge Hosting Plans</h3>
        <form action="<?php echo 'admincontroller/update_easy_recharge_hosting_plan'?>" method="post">
          <table style="width:100%;">
            <tr>
              <td>Hosting Plans Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="homeHostingPlans" value="<?php if(isset($product3HostingPlans)&& !empty($product3HostingPlans))echo $product3HostingPlans;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            <tr>
              <td><br>Hosting Plans Description<br>
                <textarea name="homeHostingPlansbody" value="<?php if(isset($product3HostingPlansbody)&& !empty($product3HostingPlansbody))echo $product3HostingPlansbody;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($product3HostingPlansbody)&& !empty($product3HostingPlansbody))echo $product3HostingPlansbody;?></textarea>
                </td>
            </tr>
            <tr>
              	<td>
        <table>
        	<tr>
            	<th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>
            <tr>
            	<th>Plan1</th>
                <th>Plan2</th>
                <th>Plan3</th>
                <th>Plan4</th>
            </tr>              
            <tr>
                <td><br>Price<br /><input type="text" name="homeHostingPlans1Price" value="<?php if(isset($product3HostingPlans1Price))echo $product3HostingPlans1Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans2Price" value="<?php if(isset($product3HostingPlans2Price))echo $product3HostingPlans2Price ?>" class="bgc"/></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans3Price" value="<?php if(isset($product3HostingPlans3Price))echo $product3HostingPlans3Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans4Price" value="<?php if(isset($product3HostingPlans4Price))echo $product3HostingPlans4Price ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans1Name" value="<?php if(isset($product3HostingPlans1Name))echo $product3HostingPlans1Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans2Name" value="<?php if(isset($product3HostingPlans2Name))echo $product3HostingPlans2Name ?>" class="bgc"/></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans3Name" value="<?php if(isset($product3HostingPlans3Name))echo $product3HostingPlans3Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans4Name" value="<?php if(isset($product3HostingPlans4Name))echo $product3HostingPlans4Name ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>processor<br /><input type="text" name="homehosting1processor" value="<?php if(isset($product3Hosting1processor))echo $product3Hosting1processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting2processor" value="<?php if(isset($product3Hosting2processor))echo $product3Hosting2processor ?>" class="bgc"/></td>
                <td><br>processor<br /><input type="text" name="homehosting3processor" value="<?php if(isset($product3Hosting3processor))echo $product3Hosting3processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting4processor" value="<?php if(isset($product3Hosting4processor))echo $product3Hosting4processor ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>RAM<br /><input type="text" name="homehosting1RAM" value="<?php if(isset($product3Hosting1RAM))echo $product3Hosting1RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting2RAM" value="<?php if(isset($product3Hosting2RAM))echo $product3Hosting2RAM ?>" class="bgc"/></td>
                <td><br>RAM<br /><input type="text" name="homehosting3RAM" value="<?php if(isset($product3Hosting3RAM))echo $product3Hosting3RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting4RAM" value="<?php if(isset($product3Hosting4RAM))echo $product3Hosting4RAM ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>HDD<br /><input type="text" name="homehosting1HDD" value="<?php if(isset($product3Hosting1HDD))echo $product3Hosting1HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting2HDD" value="<?php if(isset($product3Hosting2HDD))echo $product3Hosting2HDD ?>" class="bgc"/></td>
                <td><br>HDD<br /><input type="text" name="homehosting3HDD" value="<?php if(isset($product3Hosting3HDD))echo $product3Hosting3HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting4HDD" value="<?php if(isset($product3Hosting4HDD))echo $product3Hosting4HDD ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>OS<br /><input type="text" name="homehosting1OS" value="<?php if(isset($product3Hosting1OS))echo $product3Hosting1OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting2OS" value="<?php if(isset($product3Hosting2OS))echo $product3Hosting2OS ?>" class="bgc"/></td>
                <td><br>OS<br /><input type="text" name="homehosting3OS" value="<?php if(isset($product3Hosting3OS))echo $product3Hosting3OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting4OS" value="<?php if(isset($product3Hosting4OS))echo $product3Hosting4OS ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>LAN<br /><input type="text" name="homehosting1LAN" value="<?php if(isset($product3Hosting1LAN))echo $product3Hosting1LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting2LAN" value="<?php if(isset($product3Hosting2LAN))echo $product3Hosting2LAN ?>" class="bgc"/></td>
                <td><br>LAN<br /><input type="text" name="homehosting3LAN" value="<?php if(isset($product3Hosting3LAN))echo $product3Hosting3LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting4LAN" value="<?php if(isset($product3Hosting4LAN))echo $product3Hosting4LAN ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Application<br /><input type="text" name="homehosting1Application" value="<?php if(isset($product3Hosting1Application))echo $product3Hosting1Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting2Application" value="<?php if(isset($product3Hosting2Application))echo $product3Hosting2Application ?>" class="bgc"/></td>
                <td><br>Application<br /><input type="text" name="homehosting3Application" value="<?php if(isset($product3Hosting3Application))echo $product3Hosting3Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting4Application" value="<?php if(isset($product3Hosting4Application))echo $product3Hosting4Application ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting1ConcurrentCalls" value="<?php if(isset($product3Hosting1ConcurrentCalls))echo $product3Hosting1ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting2ConcurrentCalls" value="<?php if(isset($product3Hosting2ConcurrentCalls))echo $product3Hosting2ConcurrentCalls ?>" class="bgc"/></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting3ConcurrentCalls" value="<?php if(isset($product3Hosting3ConcurrentCalls))echo $product3Hosting3ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting4ConcurrentCalls" value="<?php if(isset($product3Hosting4ConcurrentCalls))echo $product3Hosting4ConcurrentCalls ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Billing<br /><input type="text" name="homehosting1Billing" value="<?php if(isset($product3Hosting1Billing))echo $product3Hosting1Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting2Billing" value="<?php if(isset($product3Hosting2Billing))echo $product3Hosting2Billing ?>" class="bgc"/></td>
                <td><br>Billing<br /><input type="text" name="homehosting3Billing" value="<?php if(isset($product3Hosting3Billing))echo $product3Hosting3Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting4Billing" value="<?php if(isset($product3Hosting4Billing))echo $product3Hosting4Billing ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Apps<br /><input type="text" name="homehosting1Apps" value="<?php if(isset($product3Hosting1Apps))echo $product3Hosting1Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting2Apps" value="<?php if(isset($product3Hosting2Apps))echo $product3Hosting2Apps ?>" class="bgc"/></td>
                <td><br>Apps<br /><input type="text" name="homehosting3Apps" value="<?php if(isset($product3Hosting3Apps))echo $product3Hosting3Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting4Apps" value="<?php if(isset($product3Hosting4Apps))echo $product3Hosting4Apps ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Service<br /><input type="text" name="homehosting1Service" value="<?php if(isset($product3Hosting1Service))echo $product3Hosting1Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting2Service" value="<?php if(isset($product3Hosting2Service))echo $product3Hosting2Service ?>" class="bgc"/></td>
                <td><br>Service<br /><input type="text" name="homehosting3Service" value="<?php if(isset($product3Hosting3Service))echo $product3Hosting3Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting4Service" value="<?php if(isset($product3Hosting4Service))echo $product3Hosting4Service ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Name<br /><input type="text" name="homehosting1buttonname" value="<?php if(isset($product3Hosting1buttonname))echo $product3Hosting1buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting2buttonname" value="<?php if(isset($product3Hosting2buttonname))echo $product3Hosting2buttonname ?>" class="bgc"/></td>
                <td><br>Button Name<br /><input type="text" name="homehosting3buttonname" value="<?php if(isset($product3Hosting3buttonname))echo $product3Hosting3buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting4buttonname" value="<?php if(isset($product3Hosting4buttonname))echo $product3Hosting4buttonname ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanSharedDataUrl" value="<?php if(isset($product3HostingPlanSharedDataUrl))echo $product3HostingPlanSharedDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanVPSDataUrl" value="<?php if(isset($product3HostingPlanVPSDataUrl))echo $product3HostingPlanVPSDataUrl ?>" class="bgc"/></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanResellerDataUrl" value="<?php if(isset($product3HostingPlanResellerDataUrl))echo $product3HostingPlanResellerDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanDedicatedDataUrl" value="<?php if(isset($product3HostingPlanDedicatedDataUrl))echo $product3HostingPlanDedicatedDataUrl ?>" class="bgc"/></td>
            </tr>
        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
