<?php
	$productdata = $this->db->query("select * from t_productdata")->result();
	$bannerimg='';
	
	foreach($productdata as $p)
	{
		if($p->name=='bannerimg'){$bannerimg=$p->value;}
	}
	
	$settingdata = $this->db->query("select * from t_productdata")->result();
	
	$product1HostingPlans='';
	$product1HostingPlansbody='';
	$product1HostingPlans1Name='';
	$product1HostingPlans1Price=0;
	$product1HostingPlans2Name='';
	$product1HostingPlans2Price=0;
	$product1HostingPlans3Name='';
	$product1HostingPlans3Price=0;
	$product1HostingPlans4Name='';
	$product1HostingPlans4Price=0;
	$homeKnowledgeBaseHeader='';
	$homeKnowledgeBasebody='';
	
	$product1Hosting1buttonname='';
	$product1Hosting2buttonname='';
	$product1Hosting3buttonname='';
	$product1Hosting4buttonname='';
	$product1HostingPlanSharedDataUrl='';
	$product1HostingPlanVPSDataUrl='';
	$product1HostingPlanResellerDataUrl='';
	$product1HostingPlanDedicatedDataUrl='';
	
	$whychoseustitle = '';
	$whychoseussubtitle = '';
	
   $whychoseussection1title = '';
   $whychoseussection2title = '';
   $whychoseussection3title= '';
   $whychoseussection4title = '';
   
   $whychoseussection1subtitle = '';
   $whychoseussection2subtitle = '';
   $whychoseussection3subtitle = '';
   $whychoseussection4subtitle = '';
   
   $whychoseussection1url = '';
   $whychoseussection2url = '';
   $whychoseussection3url = '';
  $whychoseussection4url = '';
	
	
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home Hosting Plans'){$product1HostingPlans = $set->value;}
			if($set->name == 'home Hosting Plans body'){$product1HostingPlansbody = $set->value;}
			if($set->name == 'home Hosting Plans1 Name'){$product1HostingPlans1Name = $set->value;}
			if($set->name == 'home Hosting Plans1 Price'){$product1HostingPlans1Price = $set->value;}
			if($set->name == 'home Hosting Plans2 Name'){$product1HostingPlans2Name = $set->value;}
			if($set->name == 'home Hosting Plans2 Price'){$product1HostingPlans2Price = $set->value;}
			if($set->name == 'home Hosting Plans3 Name'){$product1HostingPlans3Name = $set->value;}
			if($set->name == 'home Hosting Plans3 Price'){$product1HostingPlans3Price = $set->value;}
			if($set->name == 'home Hosting Plans4 Name'){$product1HostingPlans4Name = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$product1HostingPlans4Price = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$product1HostingPlans4Price = $set->value;}
			if($set->name == 'home Knowledge Base Header'){$homeKnowledgeBaseHeader = $set->value;}
			if($set->name == 'home Knowledge Base body'){$homeKnowledgeBasebody = $set->value;}
			
			if($set->name == 'homehosting1buttonname'){ $product1Hosting1buttonname = $set->value;}
			if($set->name == 'homehosting2buttonname'){ $product1Hosting2buttonname = $set->value;}
			if($set->name == 'homehosting3buttonname'){ $product1Hosting3buttonname = $set->value;}
			if($set->name == 'homehosting4buttonname'){ $product1Hosting4buttonname = $set->value;}
			
			if($set->name == 'homeHostingPlanSharedDataUrl'){ $product1HostingPlanSharedDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanVPSDataUrl'){ $product1HostingPlanVPSDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanResellerDataUrl'){ $product1HostingPlanResellerDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanDedicatedDataUrl'){ $product1HostingPlanDedicatedDataUrl = $set->value;}
			
			
			if($set->name == 'whychoseustitle' ){ $whychoseustitle = $set->value;} 
			if($set->name == 'whychoseussubtitle'){ $whychoseussubtitle = $set->value;} 
		   
		   if($set->name == 'whychoseussection1title'){ $whychoseussection1title = $set->value;} 
		   if($set->name == 'whychoseussection2title' ){ $whychoseussection2title = $set->value;}
		   if($set->name == 'whychoseussection3title' ){ $whychoseussection3title = $set->value;}
		   if($set->name == 'whychoseussection4title' ){ $whychoseussection4title = $set->value;}
		   
		   if($set->name == 'whychoseussection1subtitle' ){ $whychoseussection1subtitle = $set->value;}
		   if($set->name == 'whychoseussection2subtitle' ){ $whychoseussection2subtitle = $set->value;}
		   if($set->name == 'whychoseussection3subtitle' ){ $whychoseussection3subtitle = $set->value;}
		   if($set->name == 'whychoseussection4subtitle' ){ $whychoseussection4subtitle = $set->value;} 
		   
		   if($set->name == 'whychoseussection1url' ){ $whychoseussection1url = $set->value;}
		   if($set->name == 'whychoseussection2url' ){ $whychoseussection2url = $set->value;}
		   if($set->name == 'whychoseussection3url' ){ $whychoseussection3url = $set->value;}
		   if($set->name == 'whychoseussection4url' ){ $whychoseussection4url = $set->value;}
		}
	}
?>


<div class="container-fluid">
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12"> <img src="img/product/<?php if(isset($bannerimg))echo $bannerimg;?>" style="width: 100%;height:100%;" class="img-responsive"> </div>
  </div>
</div>
<!-----------> 

<!----------- Pricing ---------------------------------------------------------------->


<div class="vc_row-full-width"></div>
    <div class="vc_row wpb_row vc_row-fluid " style=" ">
      <div class="wpb_column vc_column_container vc_col-md-12 vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper" style="margin-top:80px;">
            <div class="title">
              <h2 style="color: ;"><span style="background: ;" class="line blueline"></span><span style="color: ;" class="text">Our Best</span><br>
              
                <?php if(isset($product1HostingPlans)&& !empty($product1HostingPlans))echo $product1HostingPlans;?>
                
                <em style="color: ;">
                <?php if(isset($product1HostingPlansbody)&& !empty($product1HostingPlansbody))echo $product1HostingPlansbody;?>
                </em></h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="vc_row wpb_row vc_row-fluid " style=" padding-bottom: 100px; width:90%;margin:auto;">
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($product1HostingPlans1Price)&& !empty($product1HostingPlans1Price))echo $product1HostingPlans1Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($product1HostingPlans1Name)&& !empty($product1HostingPlans1Name))echo $product1HostingPlans1Name;?></h2>
                </div>
                <ul class="plan-list">
                
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting1' && $hp->name !='homehosting1buttonname' && $hp->name !='homeHostingPlanSharedDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>	
                      <li class="light">10 GB Disk Space<br></li>
                      <li class="dark">256 MB Memory<br></li>
                      <li class="light">Free Domain Registration<br></li>
                      <li class="dark">5 Email Accounts<br></li>
                      <li class="light">1 Hosting Space<br></li>
                      <li class="dark">24/7 Full Support</li>
                  <?php
						}
				  ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($product1HostingPlanSharedDataUrl)) echo $product1HostingPlanSharedDataUrl;?>" class="btn darkbox "><?php if(isset($product1Hosting1buttonname)&& !empty($product1Hosting1buttonname)){echo $product1Hosting1buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col active">
                <div class="price">
                  <h4><?php if(isset($product1HostingPlans2Price)&& !empty($product1HostingPlans2Price))echo $product1HostingPlans2Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($product1HostingPlans2Name)&& !empty($product1HostingPlans2Name))echo $product1HostingPlans2Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting2' && $hp->name !='homehosting2buttonname' && $hp->name !='homeHostingPlanVPSDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>	
                      <li class="light">15 GB Disk Space<br>
                      </li>
                      <li class="dark">512 MB Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">10 Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
				  <?php
						}
                  ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($product1HostingPlanVPSDataUrl)) echo $product1HostingPlanVPSDataUrl;?>" class="btn darkbox active"><?php if(isset($product1Hosting2buttonname)&& !empty($product1Hosting2buttonname)){echo $product1Hosting2buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($product1HostingPlans3Price)&& !empty($product1HostingPlans3Price))echo $product1HostingPlans3Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($product1HostingPlans3Name)&& !empty($product1HostingPlans3Name))echo $product1HostingPlans3Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting3' && $hp->name !='homehosting3buttonname' && $hp->name !='homeHostingPlanResellerDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>	
                      <li class="light">20 GB Disk Space<br>
                      </li>
                      <li class="dark">1 GB Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">15 Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
                     <?php
						}
					 ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($product1HostingPlanResellerDataUrl)) echo $product1HostingPlanResellerDataUrl;?>" class="btn darkbox "><?php if(isset($product1Hosting3buttonname)&& !empty($product1Hosting3buttonname)){echo $product1Hosting3buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($product1HostingPlans4Price)&& !empty($product1HostingPlans4Price))echo $product1HostingPlans4Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($product1HostingPlans4Name)&& !empty($product1HostingPlans4Name))echo $product1HostingPlans4Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting4' && $hp->name !='homehosting4buttonname' && $hp->name !='homeHostingPlanDedicatedDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>
                      <li class="light">Unlimited Disk Space<br>
                      </li>
                      <li class="dark">Unlimited Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">Unlimited Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
                     <?php
						}
					 ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($product1HostingPlanDedicatedDataUrl))  echo $product1HostingPlanDedicatedDataUrl;?>" class="btn darkbox "><?php if(isset($product1Hosting4buttonname)&& !empty($product1Hosting4buttonname)){echo $product1Hosting4buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<!-------- Why Choose us ------------------------------------------------------------------------------------------------------>
<style>
.caption .big{font-size:55px;}
.caption h4{font-weight:bold;font-size:24px;padding:10px 0;color:#545454;border-top:1px solid #CCC;border-bottom:1px solid #CCC;margin-top:25px;
}
.button-a{display:block;background:#1E7898;width:110px;text-align:center;padding:5px 0px;color:#FFF;}
.box{text-align:center;background:#F0F0F0;padding:30px 40px;border:1px solid #DDDDDD;border-radius:5px;}

</style>


<div class="container-fluid" style="width:90%;margin:auto;">
	<div class="row">
    	<div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom:50px;">
        	<center>
        	<h2><?php if(!empty($whychoseustitle)){echo $whychoseustitle;}else{echo 'Why choose us?';}?></h2>
            <div style="width:60%;height:2px;border-bottom:1px solid #E0E0E0;"></div>
			<h5 style="padding-top:20px;"><?php if(!empty($whychoseussubtitle)){echo $whychoseussubtitle;}else{echo 'The top reasons to choose us for your hosting needs';}?></h5>
            </center>
        </div>
    </div>
	<div class="row"> 
      <!--Begin Item-->
      <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="box">
          <div class="caption"><i class="fa fa-life-ring big"></i>
            <center>
            <h4><?php if(!empty($whychoseussection1title)){echo $whychoseussection1title;}else{echo '   ';}?></h4>
            <h6 style="padding:20px 0;"><?php if(!empty($whychoseussection1subtitle)){echo $whychoseussection1subtitle;}else{echo '  ';}?></h6>
            <a href="<?php if(!empty($whychoseussection1url)){echo $whychoseussection1url;}else{echo '#';}?>" class="button-a" role="button"><i class="fa fa-angle-double-right"></i>Learn More</a>
            </center>
          </div>
        </div>
      </div>
      <!--End Item--> 
      <!--Begin Item-->
      <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="box">
          <div class="caption"><i class="fa fa-life-ring big"></i>
            <center>
            <h4><?php if(!empty($whychoseussection2title)){echo $whychoseussection2title;}else{echo '   ';}?></h4>
            <h6 style="padding:20px 0;"><?php if(!empty($whychoseussection2subtitle)){echo $whychoseussection2subtitle;}else{echo '  ';}?></h6>
            <a href="<?php if(!empty($whychoseussection2url)){echo $whychoseussection2url;}else{echo '#';}?>" class="button-a" role="button"><i class="fa fa-angle-double-right"></i>Learn More</a>
            </center>
          </div>
        </div>
      </div>
      <!--End Item--> 
      <!--Begin Item-->
      <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="box">
          <div class="caption"><i class="fa fa-life-ring big"></i>
            <center>
            <h4><?php if(!empty($whychoseussection3title)){echo $whychoseussection3title;}else{echo '   ';}?></h4>
            <h6 style="padding:20px 0;"><?php if(!empty($whychoseussection3subtitle)){echo $whychoseussection3subtitle;}else{echo '  ';}?></h6>
            <a href="<?php if(!empty($whychoseussection3url)){echo $whychoseussection3url;}else{echo '#';}?>" class="button-a" role="button"><i class="fa fa-angle-double-right"></i>Learn More</a>
            </center>
          </div>
        </div>
      </div>
      <!--End Item--> 
      <!--Begin Item-->
      <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="box">
          <div class="caption"><i class="fa fa-life-ring big"></i>
            <center>
            <h4><?php if(!empty($whychoseussection4title)){echo $whychoseussection4title;}else{echo '   ';}?></h4>
            <h6 style="padding:20px 0;"><?php if(!empty($whychoseussection4subtitle)){echo $whychoseussection4subtitle;}else{echo '  ';}?></h6>
            <a href="<?php if(!empty($whychoseussection4url)){echo $whychoseussection4url;}else{echo '#';}?>" class="button-a" role="button"><i class="fa fa-angle-double-right"></i>Learn More</a>
            </center>
          </div>
        </div>
      </div>
      <!--End Item--> 
    </div>

</div>

<!------- Partner ------------------------------------------------------------------------------------------------------------->
<!-----
<div class="container">
  <div class="vc_row wpb_row vc_row-fluid " style=" ">
    <div class="wpb_column vc_column_container vc_col-sm-12">
      <div class="vc_column-inner ">
        <div class="wpb_wrapper">
          <section class="section10">
            <div class="container">
              <style>
						.imgspace{width:11%;min-height:40px;}
					</style>
              <center>
                <img src="img/link/hostingpanel-icon1.jpg" alt="" class="imgspace"> <img src="img/link/hostingpanel-icon2.jpg" alt="" class="imgspace"> <img src="img/link/hostingpanel-icon3.jpg" alt="" class="imgspace"> <img src="img/link/hostingpanel-icon4.jpg" alt="" class="imgspace"> <img src="img/link/hostingpanel-icon5.jpg" alt="" class="imgspace"> <img src="img/link/hostingpanel-icon6.jpg" alt="" class="imgspace"> <img src="img/link/hostingpanel-icon7.jpg" alt="" class="imgspace"> <img src="img/link/hostingpanel-icon8.jpg" alt="" class="imgspace">
              </center>
            </div>
          </section>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<------
