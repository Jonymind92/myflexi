<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$bannerinfo = $this->db->query("select * from t_aboutusdata where subject='banner'")->result();
	$bannertitle='';
	$bannerimg='';
	
	foreach($bannerinfo as $s)
	{
		if($s->name=='bannertitle')
		{
			$facebook=$s->value;
		}
		if($s->name=='bannerimg')
		{
			$googleplus=$s->value;
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;">About Us Banner</h3>
        <form action="<?php echo 'admincontroller/update_aboutusbanner'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Banner Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="bannertitle" value="<?php if(isset($bannertitle)&& !empty($bannertitle))echo $bannertitle;?> " style="width:100%;min-height:30px;font-size:16px;"><br /><br /></td>
            </tr>
            <tr>
              <td>Banner Image (1600x200)
              <br> 
                <input type="file"  name="bannerimg"></td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
