<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.bgc{background:#C6FFFF}
.fl-r{float:right;m}
</style>
<?php
	$servicehostingdata = $this->db->query("select * from t_servicedata where subject='servicehosting'")->result();
	
	$headertitle1='';
	$headertitle2='';
	$headertitle3='';
	
	$subtitle1='';
	$subtitle2='';
	$subtitle3='';
	
	$comment1='';
	$comment2='';
	$comment3='';
	
	$url1='';
	$url2='';
	$url3='';
	
	if(isset($servicehostingdata)&& !empty($servicehostingdata))
	{
		foreach($servicehostingdata as $set)
		{
			if($set->name == 'headertitle1'){$headertitle1 = $set->value;}
			if($set->name == 'headertitle2'){$headertitle2 = $set->value;}
			if($set->name == 'headertitle3'){$headertitle3 = $set->value;}
			
			if($set->name == 'subtitle1'){$subtitle1 = $set->value;}
			if($set->name == 'subtitle2'){$subtitle2 = $set->value;}
			if($set->name == 'subtitle3'){$subtitle3 = $set->value;}
			
			if($set->name == 'comment1'){$comment1 = $set->value;}
			if($set->name == 'comment2'){$comment2 = $set->value;}
			if($set->name == 'comment3'){$comment3 = $set->value;}
			
			if($set->name == 'url1'){$url1 = $set->value;}
			if($set->name == 'url2'){$url2 = $set->value;}
			if($set->name == 'url3'){$url3 = $set->value;}
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
    	
      <div class="form">
      	<h3 style="margin-top:-20px;text-transform:uppercase;">Service Hosting Info</h3>
        <form action="<?php echo 'admincontroller/update_service_hosting'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              </td>
            </tr>
            
            <tr>
              	<td>
        <table>

            <tr>
            	<th>Hosting Info1</th>
                <th>Hosting Info2</th>
                <th>Hosting Info3</th>
            </tr>              
            <tr>
                <td><br>Sub Title<br /><input type="text" name="subtitle1" value="<?php if(isset($subtitle1))echo $subtitle1 ?>" /></td>
                <td><br>Sub Title<br /><input type="text" name="subtitle2" value="<?php if(isset($subtitle2))echo $subtitle2 ?>" class="bgc"/></td>
                <td><br>Sub Title<br /><input type="text" name="subtitle3" value="<?php if(isset($subtitle3))echo $subtitle3 ?>" /></td>
            </tr>
            
            
            
            <tr>
                <td><br>Header Title<br /><input type="text" name="headertitle1" value="<?php if(isset($headertitle1))echo $headertitle1 ?>" /></td>
                <td><br>Header Title<br /><input type="text" name="headertitle2" value="<?php if(isset($headertitle2))echo $headertitle2 ?>" class="bgc"/></td>
                <td><br>Header Title<br /><input type="text" name="headertitle3" value="<?php if(isset($headertitle3))echo $headertitle3 ?>" /></td>
            </tr>
            
            <tr>
                <td><br>Image<br /><input type="file" name="pic1" /></td>
                <td><br>Image<br /><input type="file" name="pic2" /></td>
                <td><br>Image<br /><input type="file" name="pic3"  /></td>
            </tr>
            
            <tr>
                <td><br>Comment<br /><input type="text" name="comment1" value="<?php if(isset($comment1))echo $comment1 ?>" /></td>
                <td><br>Comment<br /><input type="text" name="comment2" value="<?php if(isset($comment2))echo $comment2 ?>" class="bgc"/></td>
                <td><br>Comment<br /><input type="text" name="comment3" value="<?php if(isset($comment3))echo $comment3 ?>" /></td>
            </tr>
            <tr>
                <td><br>Url<br /><input type="text" name="url1" value="<?php if(isset($url1))echo $url1 ?>" /></td>
                <td><br>Url<br /><input type="text" name="url2" value="<?php if(isset($url2))echo $url2 ?>" class="bgc"/></td>
                <td><br>Url<br /><input type="text" name="url3" value="<?php if(isset($url3))echo $url3 ?>" /></td>
            </tr>

        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
