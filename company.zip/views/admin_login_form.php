 <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url();?>css/mystyle.css" />

<style>

.form{min-width:250px;height:300px;border:1px solid #999;padding:50px 50px;margin-bottom:50px;}

</style>

<script>
$(document).ready(function(e) {
setTimeout('$(".mymsg").hide()',4000);
});
</script>


    
<section id="about-section" class="about-section">
  <div class="container">
  	       
    <div class="row" style="margin-top:23%;">
      <div class="col-md-4 col-sm-4 col-xs-12"></div>
      <div class="col-md-4 col-sm-4 col-xs-12">
      	<div class="position">
        <div style="min-width:300px;min-height:20px;"><?php if(isset($_GET['sk']))echo '<label class="ms mymsg">'.$_GET['sk'].'</label>';?></div>
        <div class="form">
        <form action="<?php echo base_url();?>admincontroller/check_admin_login" method="post">
          <div class="formsize">
            <label>User Name</label>
            <br>
            <input type="text" name="username" class=" input form-control">
          </div>
          <!----------------------------------->
          <div class="formsize">
            <label>Password</label>
            <br>
            <input type="password" name="password" class=" input form-control">
          </div>
           
          <div style="padding-top:20px;">
          	
            <input type="submit" name="registersubmit" value="Login" class="register">
          </div>
        </form>
        <div style="min-width:300px;min-height:20px;"><?php if(isset($_GET['esk']))echo '<label class="ems">'.$_GET['esk'].'</label>';?></div>
        </div>
        
        
        
        </div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12"></div>
    </div>
  </div>
</section>
