<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$sociallink = $this->db->query("select * from t_settings")->result();
	$companyName='';
	$AboutCompanywork='';
	$address='';
	$email='';
	$loginLink='';
	$registerLink='';
	$phone='';
	$emailuslink='';
	$footerCopyrighttext='';
	
	foreach($sociallink as $s)
	{
		if($s->name=='Company Name')
		{
			$companyName=$s->value;
		}
		if($s->name=='About Company work')
		{
			$AboutCompanywork=$s->value;
		}
		if($s->name=='Address')
		{
			$address=$s->value;
		}
		if($s->name=='phone')
		{
			$phone=$s->value;
		}
		if($s->name=='servermail')
		{
			$email=$s->value;
		}
		if($s->name=='Login Link')
		{
			$loginLink=$s->value;
		}
		if($s->name=='Register Link')
		{
			$registerLink=$s->value;
		}
		if($s->name=='E-mail us link')
		{
			$emailuslink=$s->value;
		}
		if($s->name=='Footer Copyright text')
		{
			$footerCopyrighttext=$s->value;
		}
		
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
        <form action="<?php echo 'admincontroller/update_branding'?>" method="post">
          <table style="width:100%;">
            <tr>
              <td>Company Name
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="companyName" value="<?php if(isset($companyName)&& !empty($companyName))echo $companyName;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            <tr>
              <td>About Company work
              <br> 
                <textarea  name="aboutCompanywork" value="<?php if(isset($AboutCompanywork)&& !empty($AboutCompanywork))echo $AboutCompanywork;?> " style="width:100%;min-height:100px;font-size:16px;"><?php if(isset($AboutCompanywork)&& !empty($AboutCompanywork))echo $AboutCompanywork;?></textarea></td>
            </tr>
            <tr>
              <td>Address
              <br> 
                <input type="text"  name="address" value="<?php if(isset($address)&& !empty($address))echo $address;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            <tr>
              <td>Phone
              <br> 
                <input type="text"  name="phone" value="<?php if(isset($phone)&& !empty($phone))echo $phone;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            <tr>
              <td>email
              <br> 
                <input type="text"  name="email" value="<?php if(isset($email)&& !empty($email))echo $email;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            <tr>
              <td>Login Link
              <br> 
                <input type="text"  name="loginLink" value="<?php if(isset($loginLink)&& !empty($loginLink))echo $loginLink;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            <tr>
              <td>Register Link
              <br> 
                <input type="text"  name="registerLink" value="<?php if(isset($registerLink)&& !empty($registerLink))echo $registerLink;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            <tr>
              <td>E-mail us link
              <br> 
                <input type="text"  name="emailuslink" value="<?php if(isset($emailuslink)&& !empty($emailuslink))echo $emailuslink;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            <tr>
              <td>Footer Copyright text
              <br> 
                <input type="text"  name="footerCopyrighttext" value="<?php if(isset($footerCopyrighttext)&& !empty($footerCopyrighttext))echo $footerCopyrighttext;?> " style="width:100%;min-height:30px;font-size:16px;"></td>
            </tr>
            
              
            
            
            
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
