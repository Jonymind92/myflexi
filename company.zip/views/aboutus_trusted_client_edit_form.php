<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}

</style>



<div class="container">
  <div class="row">
    <div class="col-md-5 col-sm-5 col-xs-12">
    	<h3>Edit Trusted Client Image</h3>
      <div class="form">
        <form action="<?php echo 'admincontroller/update_aboutus_trusted_client/'.$ourclient->value2?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
			
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
					if(isset($_GET['esk'])&& !empty($_GET['esk']))echo '<label class="ems mymsg fl-r">'.$_GET['esk'].'</label>';
				?>
              <br> 
            <tr>
              <td>Photo
              
              <br> 
                <input type="file"  name="pic"  style="width:100%;min-height:30px;font-size:16px;"><br>
                <img src="<?php if(isset($ourclient->value2)) echo 'img/aboutus/'.$ourclient->value2?>" style="width:80px;height:80px;"/>
                </td>
            </tr>
            

            
            <tr>
              <td><input type="submit" value="Upload" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>

</div>
