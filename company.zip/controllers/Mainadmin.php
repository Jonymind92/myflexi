<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mainadmin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
		$this->output->set_header("Cache-Control: post-check=0, pre-check=0", false);
		$this->output->set_header("Pragma: no-cache");
		date_default_timezone_set("Asia/Dhaka");
		
	}
	public function index()
	{
		$data = array();
		$data['title'] = 'Admin|Admin home';
		$data['content'] = $this->load->view('home_page_admin',$data,true);
		//$data['footercontainer'] = $this->load->view('footercontainer','',true);
		//$data['footercontainer'] = $this->load->view('footercontainer','',true);
		$this->load->view('master_admin',$data);
		//$this->load->view('master');
	}
	public function update_homebanner()
	{
		if($_POST)
		{
			$bannertitle = $this->input->post('homebannertitle');
			$bannersubtitle = $this->input->post('homebannersubtitle');
			$data = array();
			$data['value'] = trim($bannertitle);
			$this->mm->update_info('t_settings',$data,array('name'=>'home banner title'));
			$data = array();
			$data['value'] = trim($bannersubtitle);
			$this->mm->update_info('t_settings',$data,array('name'=>'home banner sub title'));
			redirect('mainadmin/index');
		}
		else{redirect('main/index');}
		
	}
	public function aboutus()
	{
		$data = array();
		$data['menu'] = 'aboutus';
		$data['content'] = $this->load->view('aboutus-admin',$data,true);
		$this->load->view('master_admin',$data);
	}
	public function products_page()
	{
		$data = array();
		$data['menu'] = 'products';
		$data['content'] = $this->load->view('products_page_admin',$data,true);
		$this->load->view('master_admin',$data);
	}
	public function contact_page()
	{
		$data = array();
		$data['menu'] = 'contact';
		$data['content'] = $this->load->view('contact_page-admin',$data,true);
		$this->load->view('master_admin',$data);
	}
	public function service_page()
	{
		$data = array();
		$data['menu'] = 'service';
		$data['content'] = $this->load->view('service_page_admin',$data,true);
		$this->load->view('master_admin',$data);
	}
	
	
	
	
	
}
