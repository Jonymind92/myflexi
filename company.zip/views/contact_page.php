
<?php
	$contactdata = $this->db->query("select * from t_contactdata ")->result();
	$contactaddress='';
	$contactemail='';
	$contactphone='';
	$map='';
	foreach($contactdata as $s)
	{
		if($s->name=='contactaddress')
		{
			$contactaddress=$s->value;
		}
		if($s->name=='contactemail')
		{
			$contactemail=$s->value;
		}
		if($s->name=='contactphone')
		{
			$contactphone=$s->value;
		}
		if($s->name=='map')
		{
			$map=$s->value;
		}
	}
?>



<link rel="stylesheet" href="css/contact.css">
<link rel="stylesheet" href="css/contact-blox.css">

<style>
.vertical-space5 {height: 100px;display: block;width: 100%;margin: 0;clear: both;}
#talk-business textarea:focus {
    background: #E8E8E8;
}
.style-1{height:40px;width:100%;}
.style-2{height:40px;width:100%;}
.style-3{height:150px;width:100%;}
input, textarea {
    background: #f0f0f0;
    border-radius: 2px;
    border: none;
    box-shadow: none;
    margin-bottom: 16px;
}
input[type="submit"] {
    margin-top: 10px;
    border-radius: 60px;
    background-color: #77da55;
	font-weight: bold;
	padding: 11px 42px;
	color: #fff;
	font-family: 'Poppins','Open Sans', Helvetica, Arial, sans-serif;
	display: inline-block;
	cursor: pointer;
	text-align: center;
	box-sizing: border-box;
	height:35px;
	line-height:1px;
	
}
.email-cr{width: 5em !important;height: 5em !important;border:2px solid #15bce8;border-radius:50%;}
#map{width:100% !important;height:655px;position: relative;overflow: hidden;margin:20px 0;}
.ms{color:#00F}
.ems{color:#F00}
</style>


<div class="container-fluid">
	<div class="vc_row wpb_row vc_row-fluid">
    	<div class="vc_col-md-12 vc_col-sm-12 vc_col-xs-12">
        	<img src="img/contactus.jpg">
        </div>
    </div>
</div>

<div class="container-fluid" style="width:90%;margin:auto;">
	
        	<br><br><br><br>
        	<div class="vc_row wpb_row vc_row-fluid " style="background:#F6F8F9;">
                <div class="wpb_column vc_column_container vc_col-sm-6" style="background:#77DA55;padding:0 20px;">
                	<div id="map" style="width:100%;">
                    	<?php 
							if(isset($map)&& !empty($map))
							{
						?>
                        <img src="img/contact/contactmap.jpg" class="img-responsive" style="width:100%;height:100%;"/>
                        <?php		
								
							}
							else
							{
						?>
                        	<img src="img/contact/map1.PNG" class="img-responsive" style="width:100%;height:100%;"/>		
						<?php		
								
							}
						?>

                    </div>
                </div>
                
                
                
                
                <div class="wpb_column vc_column_container vc_col-sm-6" style="background:#F6F8F9;padding:0 20px;">
                
  <!---------------- Contact Form Start --------------------------------------------------------------------------------------------->              
<div>
<form action="<?php echo 'main/contactmail'?>" method="post" style="width:100%;" >
<table style="width:100%;">
<tr>
	<td colspan="2">
    <center>
    <br><br>
    <div class="email-cr">
        <span class="fa fa-envelope-o" style="color:#15bce8 !important;font-size:40px;margin: 12px auto 0;"></span>
    </div><br>
    	<span style="margin-top: 40px; margin-bottom: 25px;  font-size: 17px; font-weight: 600; color: #51c1e9;">LET’S TALK BUSINESS</span>
        		<?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
					if(isset($_GET['esk'])&& !empty($_GET['esk']))echo '<label class="ems mymsg fl-r">'.$_GET['esk'].'</label>';
				?>
    </center>
    </td>
</tr>
<tr>
	<td colspan="2">Your Name<br><input type="text" name="name" id="name" class="style-2"  ></td>
</tr>
<tr>
	<td>Your Email<br><input name="email"   class="style-1"></td>
    <td>Subject<br><input name="subject"  class="style-1"  type="text"></td>
</tr>
<tr>
	<td colspan="2">Your Message<br><textarea name="message"  class="style-3" ></textarea></td>
</tr>
<tr>
	<td colspan="2"><center><input value="Send" class="" type="submit"></center></td>
</tr>
</table>
</form>

<div class="row">
	<div class="col-md-12" style="margin-bottom:20px;">
    	<b>Address:</b><br>
        <?php if(isset($contactaddress)&& !empty($contactaddress))echo $contactaddress;?>
    </div>
    <div class="col-md-6" style="margin-bottom:20px;">
    	<b>Email:</b><br>
        <?php if(isset($contactemail)&& !empty($contactemail))echo $contactemail;?>
    </div>
    <div class="col-md-6" style="margin-bottom:20px;">
    	<b>Phone:</b><br>
        <?php if(isset($contactphone)&& !empty($contactphone))echo $contactphone;?>
    </div>
</div>
</div>


</div>

 <!---------------- Contact Form End --------------------------------------------------------------------------------------------->


    </div>
    </div>


