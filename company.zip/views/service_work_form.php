<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from  t_servicedata")->result();
	$serviceworktitle='';
	$serviceworkdescribtion='';
	
	$servicework1='';
	$servicework2='';
	$servicework3='';
	$servicework4='';
	
	$servicework1percent='';
	$servicework2percent='';
	$servicework3percent='';
	$servicework4percent='';
	
	//form section focus need to work, create 4 section focus in db then work 
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'serviceworktitle'){$serviceworktitle = $set->value;}
			if($set->name == 'serviceworkdescribtion'){$serviceworkdescribtion = $set->value;}
			
			if($set->name == 'servicework1'){$servicework1 = $set->value;}
			if($set->name == 'servicework2'){$servicework2 = $set->value;}
			if($set->name == 'servicework3'){$servicework3 = $set->value;}
			if($set->name == 'servicework4'){$servicework4 = $set->value;}
			
			if($set->name == 'servicework1percent'){$servicework1percent = $set->value;}
			if($set->name == 'servicework2percent'){$servicework2percent = $set->value;}
			if($set->name == 'servicework3percent'){$servicework3percent = $set->value;}
			if($set->name == 'servicework4percent'){$servicework4percent = $set->value;}
			
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Service Work</h3>
        <form action="<?php echo 'admincontroller/update_servicework'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <textarea type="text"  name="serviceworktitle" value="<?php if(isset($serviceworktitle)&& !empty($serviceworktitle))echo $serviceworktitle;?> " style="width:100%;min-height:50px;font-size:16px;"><?php if(isset($serviceworktitle)&& !empty($serviceworktitle))echo $serviceworktitle;?> </textarea></td>
            </tr>
            <tr>
              <td><br>Describtion<br>
                <textarea name="serviceworkdescribtion" value="<?php if(isset($serviceworkdescribtion)&& !empty($serviceworkdescribtion))echo $serviceworkdescribtion;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($serviceworkdescribtion)&& !empty($serviceworkdescribtion))echo $serviceworkdescribtion;?></textarea>
                </td>
            </tr>
            <tr>
              	<td>
        <table>

            <tr>
                <td><br>Service work1<br /><textarea name="servicework1" value="<?php if(isset($servicework1))echo $servicework1;?>" style="width:100%;background:#FFF"><?php if(isset($servicework1))echo $servicework1;?></textarea></td>
                
                <td><br>Service work2<br /><textarea name="servicework2" value="<?php if(isset($servicework2))echo $servicework2;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($servicework2))echo $servicework2;?></textarea></td>
                
                <td><br>Service work3<br /><textarea name="servicework3" value="<?php if(isset($servicework3))echo $servicework3;?>" style="width:100%;"><?php if(isset($servicework3))echo $servicework3;?></textarea></td>
                
                <td><br>Service work4<br /><textarea name="servicework4" value="<?php if(isset($servicework4))echo $servicework4;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($servicework4))echo $servicework4;?></textarea></td>
            </tr>
            
            
            
            
            <tr>
                <td><br>Work1 Percent<br /><textarea name="servicework1percent" value="<?php if(isset($servicework1percent))echo $servicework1percent;?>" style="width:100%;background:#FFF"><?php if(isset($servicework1percent))echo $servicework1percent;?></textarea></td>
                
                <td><br>Work2 Percent<br /><textarea name="servicework2percent" value="<?php if(isset($servicework2percent))echo $servicework2percent;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($servicework2percent))echo $servicework2percent;?></textarea></td>
                
                <td><br>Work3 Percent<br /><textarea name="servicework3percent" value="<?php if(isset($servicework3percent))echo $servicework3percent;?>" style="width:100%"><?php if(isset($servicework3percent))echo $servicework3percent;?></textarea></td>
                
                <td><br>Work4 Percent<br /><textarea name="servicework4percent" value="<?php if(isset($servicework4percent))echo $servicework4percent;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($servicework4percent))echo $servicework4percent;?></textarea></td>
            </tr>

        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
