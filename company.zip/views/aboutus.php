<?php 
$aboutdata = $this->db->query("select * from t_aboutusdata")->result();
$bannertitle='';
$ourspeciality='';
$ourspecialitybody='';
$freedomaintitle='';
$freedomainbody='';
foreach($aboutdata as $a)
{
	if($a->name == 'bannertitle'){$bannertitle=$a->value;}
	if($a->name == 'ourspeciality'){$ourspeciality=$a->value;}
	if($a->name == 'ourspecialitybody'){$ourspecialitybody=$a->value;}
	if($a->name == 'freedomaintitle'){$freedomaintitle=$a->value;}
	if($a->name == 'freedomainbody'){$freedomainbody=$a->value;}
}

?>



<link rel="stylesheet" href="css/aboutus.css">


 <!------- breadcrumb-area  ----------------------------------------------->


<section class="breadcrumb-area">
		<div class="container-fluid" style="width:90%;margin:auto;">
			<div class="row">
				<div class="col-xs-12">
                	
					<div class="breadcrumb-inner-area">
                    
                    	<h2 style="margin-top:50px;font-family: Roboto,sans-serif;line-height:100px;font-weight:400;"><?php if(isset($bannertitle))echo $bannertitle?></h2>
						
					</div>
				</div>
			</div>
		</div>
	</section>
    
   
   
   <!------- aboutHost  ----------------------------------------------->   
   
    
    
    <section class="aboutHost">
		<div class="container-fluid" style="width:90%;margin:auto;">
			<div class="vc_row wpb_row vc_row-fluid ">
				<div class="wpb_column vc_column_container vc_col-md-6 vc_col-sm-7">
					<div class="about-big-host-left">
						<div class="section-title inner-page">
	                        <h2>Our <span>Speciality</span></h2>
	                        <span class="section-style"></span>
	                        <p>
	                        	<?php if(isset($ourspeciality))echo $ourspeciality?>
	                        </p>
	                    </div>
	                    <div class="about-us-inner-content">
	                    	<ul>
	                    		<li>
	                    			<p>
	                    				<?php if(isset($ourspecialitybody))echo $ourspecialitybody?>
	                    			</p>
	                    		</li>
	                    		
	                    	</ul>
	                    </div>
					</div>
				</div>
				<div class="vc_col-md-6 vc_col-sm-5">
					<div class="aboutHost-right">
						<figure>
							<img src="img/aboutus/about.jpg" alt="about-host">
						</figure>
					</div>
				</div>
			</div>
		</div>
	</section>
    
    
  <!------- speciality  ----------------------------------------------->   
    
    <div class="speciality">
        <div class="container-fluid" style="width:90%;margin:auto;">
            <!--<div class="vc_row wpb_row vc_row-fluid">
                <div class="vc_col-md-6 col-md-offset-3">
                    <div class="section-title">
                        <h2>Our <span>Speciality</span></h2>
                        <span class="section-style"></span>
                        <p>
                            Eu delicata rationibus usu. Vix te putant utroque, ludus fabellas duo eu, his dico ut debet consectetuer.
                        </p>
                    </div>
                </div>
            </div>-->
            
            
            <div class="row">
                <!--<div class="vc_col-md-12" >
                    <div style="width:100%;height:128px;background:#0C112A;">
                    	<style>
							.menu1{min-height:128px;float:left;margin:0 auto;background:#0C112A;margin-bottom: 60px;}
							.menu1 ul{list-style-type:none;}
							.menu1 ul li{float:left;}
							.menu1 ul li a{line-height:128px;text-decoration:none;text-align:center;padding-left:50px;}
						</style>
                        <div class="col-md-3 col-sm-2 col-xs-12">&nbsp;</div>
                        <div class="menu1">
                        	<ul>
                                <li><a href="<?php echo ''?>"><img src="img/s1.PNG" /></a></li>
                                <li><a href="<?php echo ''?>"><img src="img/s2.PNG" /></a></li>
                                <li><a href="<?php echo ''?>"><img src="img/s3.PNG" /></a></li>
                                <li><a href="<?php echo ''?>"><img src="img/s4.PNG" /></a></li>
                                <li><a href="<?php echo ''?>"><img src="img/s5.PNG" /></a></li>
                                <li><a href="<?php echo ''?>"><img src="img/s6.PNG" /></a></li>
                            </ul>
                         </div>
                        
                        </div>
                    </div>-->
                    
                    
                    
                    
                    <div class="speciality-content-body">
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="domain-transfer">
                                <div class="row">
                                    <div class="vc_col-md-4 vc_col-sm-4">
                                        <div class="speciality-image">
                                            <img src="img/aboutus/specialty-monitor.png" alt="speciality-monitor">
                                        </div>
                                    </div>
                                    <div class="vc_col-md-8 vc_col-sm-8">
                                        <div class="speciality-main-content">
                                            <h5>
                                                <?php if(isset($freedomaintitle))echo $freedomaintitle?>
                                            </h5>
                                            <ul>
                                                <li>
                                                    <?php if(isset($freedomainbody))echo $freedomainbody?>
                                                </li>
                                                
                                            </ul>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
   <!------- team-area  -----------------------------------------------> 
    
    
    <section class="team-area">
		<div class="container-fluid" style="width:90%;margin:auto;">
			<div class="row">
				<div class="vc_col-xs-12 vc_col-md-6 col-md-offset-3">
					<div class="section-title">
                        <h2>our <span>awesome</span> team</h2>
                        <span class="section-style"></span>
                        <!--<p>
                            Eu delicata rationibus usu. Vix te putant utroque, ludus fabellas duo eu, his dico ut debet consectetuer.
                        </p>-->
                    </div>
				</div>
			</div>
			<div class="row">
            	<div class="vc_col-md-12 vc_col-sm-12">
                
                
                
				<?php 
				 $aboutdata = $this->db->query("select * from t_pic where subject='ourteam'")->result();
				 foreach($aboutdata as $ab)
				 {
					 
				?>
                <div class="vc_col-md-3 vc_col-sm-3 vc_col-xs-12">
					<div class="single-team-member">
						<figure>
							<img src="img/aboutus/<?php if(isset($ab->value2)) echo $ab->value2?>" alt="">
						</figure>
						<div class="member-information">
							<h6><?php if(isset($ab->name)) echo $ab->name?></h6>
							<p><?php if(isset($ab->value1)) echo $ab->value1?></p>
						</div>
						<div class="single-member-hover">
							<div class="member-hover-inner-area">
								<div class="member-inner-content">
									<ul>
										<li>
											<a href="#">
												<i class="fa fa-facebook" aria-hidden="true"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="fa fa-twitter" aria-hidden="true"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="fa fa-google-plus" aria-hidden="true"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="fa fa-linkedin" aria-hidden="true"></i>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
                
                <?php 
				
				 }
				?>

                
                </div><!----- Column close------------------>
			</div>
		</div>
	</section>
    
    
    
 <!------- testimonial  ----------------------------------------------->   
    
    <section class="clint-testimonial">
		<div class="container-fluid" style="width:90%;margin:auto;">
			<div class="row">
				<div class="vc_col-md-6 vc_col-sm-6">
					<div class="row">
						<div class="section-title inner-page">
	                        <h2>Our trusted <span>clients</span></h2>
	                        <span class="section-style"></span>
                    	</div>
					</div>
					<div class="our-partners-type2">
						<ul class="bottom-border">
                        	<?php
                            $ourclient = $this->db->query("select * from  t_pic where subject='ourctrustedlient'")->result();
							foreach($ourclient as $c)
							{
							?>
							<li>
								<a href="#">
									<img src="img/aboutus/<?php echo $c->value2?>" alt="partners-logo">
								</a>
							</li>
							<?php
							}
							?>
						</ul>
					</div>
				</div>
				<div class="vc_col-md-6 vc_col-sm-6">
					<div class="row">
						<div class="col-xs-12">
							<div class="section-title inner-page">
		                        <h2>Our well<span>wishers</span></h2>
		                        <span class="section-style"></span>
	                    	</div>
						</div>
					</div>
					<div class="our-partners-type2">
						<ul class="bottom-border">
                        <?php
                            $ourclient = $this->db->query("select * from  t_pic where subject='wishers'")->result();
							foreach($ourclient as $a)
							{
						?>
							<li>
								<a href="#">
									<img src="img/aboutus/<?php echo $a->value2?>" alt="partners-logo">
								</a>
							</li>
                            <?php
							}
							?>
							
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
    
    
    
    
    
    
   