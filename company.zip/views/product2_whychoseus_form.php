<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
	font-size:11px;}
}
.bgc{background:#C6FFFF}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from t_product2data where subject='whychoseus'")->result();
	
	$whychosetitle=''; $whychoseusdescription=''; $section1title=''; $section2title=''; $section3title=''; $section4title=''; $section1subtitle=''; $section2subtitle=''; $section3subtitle=''; $section4subtitle=''; $section1url=''; $section2url=''; $section3url=''; $section4url='';
	
	
	//form section focus need to work, create 4 section focus in db then work 
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'whychoseustitle'){$whychosetitle = $set->value;}
			if($set->name == 'whychoseussubtitle'){$whychoseusdescription = $set->value;}
			
			if($set->name == 'whychoseussection1title'){$section1title = $set->value;}
			if($set->name == 'whychoseussection2title'){$section2title = $set->value;}
			if($set->name == 'whychoseussection3title'){$section3title = $set->value;}
			if($set->name == 'whychoseussection4title'){$section4title = $set->value;}
			
			if($set->name == 'whychoseussection1subtitle'){$section1subtitle = $set->value;}
			if($set->name == 'whychoseussection2subtitle'){$section2subtitle = $set->value;}
			if($set->name == 'whychoseussection3subtitle'){$section3subtitle = $set->value;}
			if($set->name == 'whychoseussection4subtitle'){$section4subtitle = $set->value;}
			
			if($set->name == 'whychoseussection1url'){$section1url = $set->value;}
			if($set->name == 'whychoseussection2url'){$section2url = $set->value;}
			if($set->name == 'whychoseussection3url'){$section3url = $set->value;}
			if($set->name == 'whychoseussection4url'){$section4url = $set->value;}
		}
	}
?>

  <div class="row">
    <div class="col-md-10 col-sm-12 col-xs-12">
    	
      <div class="form">
      	<h3 style="margin-top:-20px;text-transform:uppercase;">Voip Servers Page Why Chose Us</h3>
        
        <form action="<?php echo 'admincontroller/update_easy_billing_whychoseus'?>" method="post">
          <table >
            <tr>
              <td>Why Chose Us Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="whychosetitle" value="<?php if(isset($whychosetitle)&& !empty($whychosetitle))echo $whychosetitle;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            <tr>
              <td><br>Why Chose Us Description<br>
                <textarea name="whychoseusdescription" value="<?php if(isset($whychoseusdescription)&& !empty($whychoseusdescription))echo $whychoseusdescription;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($whychoseusdescription)&& !empty($whychoseusdescription))echo $whychoseusdescription;?></textarea>
                </td>
            </tr>
            <tr>
              	<td>
        <table>
        	<tr>
            	<th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>
            <tr>
            	<th>Section1</th>
                <th>Section2</th>
                <th>Section3</th>
                <th>Section4</th>
            </tr>              
            <!--<tr>
                <td><br>Image<br /><input type="file" name="pic1"  /></td>
                <td><br>Image<br /><input type="file" name="pic2"  class="bgc"/></td>
                <td><br>Image<br /><input type="file" name="pic3"  /></td>
                <td><br>Image<br /><input type="file" name="pic4"  class="bgc"/></td>
            </tr>-->
            
            <tr>
                <td><br>Title<br /><input type="text" name="section1title" value="<?php if(isset($section1title))echo $section1title ?>" style="width:100%;height:30px;"/></td>
                <td><br>Title<br /><input type="text" name="section2title" value="<?php if(isset($section2title))echo $section2title ?>" class="bgc" style="width:100%;height:30px;"/></td>
                <td><br>Title<br /><input type="text" name="section3title" value="<?php if(isset($section3title))echo $section3title ?>" style="width:100%;height:30px;"/></td>
                <td><br>Title<br /><input type="text" name="section4title" value="<?php if(isset($section4title))echo $section4title ?>" class="bgc" style="width:100%;height:30px;"/></td>
            </tr>
            
            <tr>
                <td><br>Describtion<br /><textarea name="section1subtitle" value="<?php if(isset($section1subtitle))echo $section1subtitle ?>" ><?php if(isset($section1subtitle))echo $section1subtitle ?></textarea></td>
                <td><br>Describtion<br /><textarea name="section2subtitle" value="<?php if(isset($section2subtitle))echo $section2subtitle ?>" class="bgc"><?php if(isset($section2subtitle))echo $section2subtitle ?></textarea></td>
                <td><br>Describtion<br /><textarea name="section3subtitle" value="<?php if(isset($section3subtitle))echo $section3subtitle ?>" ><?php if(isset($section3subtitle))echo $section3subtitle ?></textarea></td>
                <td><br>Describtion<br /><textarea name="section4subtitle" value="<?php if(isset($section4subtitle))echo $section4subtitle ?>" class="bgc"><?php if(isset($section4subtitle))echo $section4subtitle ?></textarea></td>
            </tr>
            <tr>
                <td><br>Button Url<br /><input type="text" name="section1url" value="<?php if(isset($section1url))echo $section1url ?>" style="width:100%;height:30px;"/></td>
                <td><br>Button Url<br /><input type="text" name="section2url" value="<?php if(isset($section2url))echo $section2url ?>" class="bgc" style="width:100%;height:30px;"/></td>
                <td><br>Button Url<br /><input type="text" name="section3url" value="<?php if(isset($section3url))echo $section3url ?>" style="width:100%;height:30px;"/></td>
                <td><br>Button Url<br /><input type="text" name="section4url" value="<?php if(isset($section4url))echo $section4url ?>" class="bgc" style="width:100%;height:30px;"/></td>
            </tr>

           
        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>

