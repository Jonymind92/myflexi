<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from t_homedata")->result();
	$homesiteuniq='';
	$homesiteuniqsubtext='';
	
	$homePARALLAXEFFECT='';
	$homeMOVABLESECTIONS='';
	$homeCUSTOMCONTENTBLOCKS='';
	$homeWOOCOMMERCE='';
	
	$section1focus='';
	$section2focus='';
	$section3focus='';
	$section4focus='';
	
	$section1body='';
	$section2body='';
	$section3body='';
	$section4body='';
	//form section focus need to work, create 4 section focus in db then work 
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home siteuniq'){$homesiteuniq = $set->value;}
			if($set->name == 'home siteuniq subtext'){$homesiteuniqsubtext = $set->value;}
			
			if($set->name == 'home PARALLAX EFFECT'){$homePARALLAXEFFECT = $set->value;}
			if($set->name == 'home MOVABLE SECTIONS'){$homeMOVABLESECTIONS = $set->value;}
			if($set->name == 'home WOOCOMMERCE'){$homeWOOCOMMERCE = $set->value;}
			if($set->name == 'home CUSTOM CONTENT BLOCKS'){$homeCUSTOMCONTENTBLOCKS = $set->value;}
			
			if($set->name == 'home FOCUS HEADING1'){$section1focus = $set->value;}
			if($set->name == 'home FOCUS HEADING2'){$section2focus = $set->value;}
			if($set->name == 'home FOCUS HEADING3'){$section3focus = $set->value;}
			if($set->name == 'home FOCUS HEADING4'){$section4focus = $set->value;}
			
			if($set->name == 'home PARALLAX EFFECT body'){$section1body = $set->value;}
			if($set->name == 'home MOVABLE SECTIONS body'){$section2body = $set->value;}
			if($set->name == 'home WOOCOMMERCE body'){$section3body = $set->value;}
			if($set->name == 'home CUSTOM CONTENT BLOCKS body'){$section4body = $set->value;}
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Home Page Why Choose Us Section</h3>
        <form action="<?php echo 'admincontroller/update_whatmakesthesiteunique'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Domain Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="homesiteuniq" value="<?php if(isset($homesiteuniq)&& !empty($homesiteuniq))echo $homesiteuniq;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            <tr>
              <td><br>Domain Sub Title<br>
                <textarea name="homesiteuniqsubtext" value="<?php if(isset($homesiteuniqsubtext)&& !empty($homesiteuniqsubtext))echo $homesiteuniqsubtext;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($homesiteuniqsubtext)&& !empty($homesiteuniqsubtext))echo $homesiteuniqsubtext;?></textarea>
                </td>
            </tr>
            <tr>
              	<td>
        <table>
        	<tr>
                <td><br>Section1 Image<br /><input type="file" name="pic1" style="font-size:9px;cursor:pointer;overflow:hidden"/></td>
                <td><br>Section2 Image<br /><input type="file" name="pic2" style="font-size:9px;cursor:pointer;overflow:hidden"/></td>
                
                <td><br>Section3 Image<br /><input type="file" name="pic3" style="font-size:9px;cursor:pointer;overflow:hidden"/></td>
                <td><br>Section4 Image<br /><input type="file" name="pic4" style="font-size:9px;cursor:pointer;overflow:hidden"/></td>
            </tr>
            
            <tr>
                <td><br>Section1 Name<br /><textarea name="homePARALLAXEFFECT" value="<?php if(isset($homePARALLAXEFFECT))echo $homePARALLAXEFFECT;?>" style="width:100%;background:#FFF"><?php if(isset($homePARALLAXEFFECT))echo $homePARALLAXEFFECT;?></textarea></td>
                <td><br>Section2 Name<br /><textarea name="homeMOVABLESECTIONS" value="<?php if(isset($homeMOVABLESECTIONS))echo $homeMOVABLESECTIONS;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($homeMOVABLESECTIONS))echo $homeMOVABLESECTIONS;?></textarea></td>
                
                <td><br>Section3 Name<br /><textarea name="homeWOOCOMMERCE" value="<?php if(isset($homeWOOCOMMERCE))echo $homeWOOCOMMERCE;?>" style="width:100%;"><?php if(isset($homeWOOCOMMERCE))echo $homeWOOCOMMERCE;?></textarea></td>
                <td><br>Section4 Name<br /><textarea name="homeCUSTOMCONTENTBLOCKS" value="<?php if(isset($homeCUSTOMCONTENTBLOCKS))echo $homeCUSTOMCONTENTBLOCKS;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($homeCUSTOMCONTENTBLOCKS))echo $homeCUSTOMCONTENTBLOCKS;?></textarea></td>
            </tr>
            
            <tr>
                <td><br>Section1 FOCUS<br /><textarea name="section1focus" value="<?php if(isset($section1focus))echo $section1focus;?>" style="width:100%;background:#FFF"><?php if(isset($section1focus))echo $section1focus;?></textarea></td>
                <td><br>Section2 FOCUS<br /><textarea name="section2focus" value="<?php if(isset($section2focus))echo $section2focus;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($section2focus))echo $section2focus;?></textarea></td>
                <td><br>Section3 FOCUS<br /><textarea name="section3focus" value="<?php if(isset($section3focus))echo $section3focus;?>" style="width:100%"><?php if(isset($section3focus))echo $section3focus;?></textarea></td>
                <td><br>Section4 FOCUS<br /><textarea name="section4focus" value="<?php if(isset($section4focus))echo $section4focus;?>" style="width:100%;background:#D9FFF8;"><?php if(isset($section4focus))echo $section4focus;?></textarea></td>
            </tr>
            
            <tr>
                <td><br>Section1 Body<br /><textarea name="section1body" value="<?php if(isset($section1body))echo $section1body;?>" style="width:100%;min-height:150px;background:#FFF"><?php if(isset($section1body))echo $section1body;?></textarea></td>
                <td><br>Section2 Body<br /><textarea name="section2body" value="<?php if(isset($section2body))echo $section2body;?>" style="width:100%;min-height:150px;background:#D9FFF8;"><?php if(isset($section2body))echo $section2body;?></textarea></td>
                <td><br>Section3 Body<br /><textarea name="section3body" value="<?php if(isset($section3body))echo $section3body;?>" style="width:100%;min-height:150px;"><?php if(isset($section3body))echo $section3body;?></textarea></td>
                <td><br>Section4 Body<br /><textarea name="section4body" value="<?php if(isset($section4body))echo $section4body;?>" style="width:100%;min-height:150px;background:#D9FFF8;"><?php if(isset($section4body))echo $section4body;?></textarea></td>
            </tr>
        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
