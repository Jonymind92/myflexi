<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$aboutusdata = $this->db->query("select * from t_aboutusdata ")->result();
	$ourspeciality='';
	$ourspecialitybody='';
	
	foreach($aboutusdata as $s)
	{
		if($s->name=='ourspeciality')
		{
			$ourspeciality=$s->value;
		}
		if($s->name=='ourspecialitybody')
		{
			$ourspecialitybody=$s->value;
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;">About Our Speciality</h3>
        <form action="<?php echo 'admincontroller/update_aboutourspeciality'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="title" value="<?php if(isset($ourspeciality)&& !empty($ourspeciality))echo $ourspeciality;?> " style="width:100%;min-height:30px;font-size:16px;"><br /><br /></td>
            </tr>
            <tr>
              <td>Our Speciality
              <br> 
                <textarea  name="speciality" value="<?php if(isset($ourspecialitybody)&& !empty($ourspecialitybody))echo $ourspecialitybody;?> " style="width:100%;min-height:200px;font-size:16px;"><?php if(isset($ourspecialitybody)&& !empty($ourspecialitybody))echo $ourspecialitybody;?></textarea><br /><br /></td>
            </tr>
            <tr>
              <td>Image
              <br> 
                <input type="file"  name="specialitysectionimg"></td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
