<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from t_homedata where subject='home banner'")->result();
	$homebannertitle ='';
	$homebannersubtitle='';
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home banner title'){$homebannertitle = $set->value;}
			if($set->name == 'home banner sub title'){$homebannersubtitle = $set->value;}
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Home Page Banner</h3>
        <form action="<?php echo 'admincontroller/update_homebanner'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Banner Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br>
                <input type="text"  name="homebannertitle" value="<?php if(isset($homebannertitle)&& !empty($homebannertitle))echo $homebannertitle;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            <tr>
              	<td><br>Banner Sub Title<br>
                <textarea name="homebannersubtitle" value="<?php if(isset($homebannersubtitle)&& !empty($homebannersubtitle))echo $homebannersubtitle;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($homebannersubtitle)&& !empty($homebannersubtitle))echo $homebannersubtitle;?></textarea>
                </td>
            </tr>
            <tr>
              	<td><br>Banner Image (192x650)<br>
                	<input type="file" name="pic">
                </td>
            </tr>
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/>
              	
              </td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
