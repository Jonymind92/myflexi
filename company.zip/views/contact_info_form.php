<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$contactdata = $this->db->query("select * from t_contactdata ")->result();
	$contactaddress='';
	$contactemail='';
	$contactphone='';
	
	foreach($contactdata as $s)
	{
		if($s->name=='contactaddress')
		{
			$contactaddress=$s->value;
		}
		if($s->name=='contactemail')
		{
			$contactemail=$s->value;
		}
		if($s->name=='contactphone')
		{
			$contactphone=$s->value;
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase">Contact Info</h3>
        <form action="<?php echo 'admincontroller/update_contactinfo'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Address
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="contactaddress" value="<?php if(isset($contactaddress)&& !empty($contactaddress))echo $contactaddress;?> " style="width:100%;min-height:30px;font-size:16px;" autocomplete="off"><br /><br /></td>
            </tr>
            <tr>
              <td>Email
              <br> 
                <input type="text"  name="contactemail" value="<?php if(isset($contactemail)&& !empty($contactemail))echo $contactemail;?> " style="width:100%;min-height:30px;font-size:16px;" autocomplete="off"><br /><br /></td>
            </tr>
            <tr>
              <td>Phone
              <br> 
                <input type="text"  name="contactphone" value="<?php if(isset($contactphone)&& !empty($contactphone))echo $contactphone;?> " style="width:100%;min-height:30px;font-size:16px;" autocomplete="off"><br /><br /></td>
            </tr>
            <tr>
              <td>map Image (560x660)
              <br> 
                <input type="file"  name="pic" ><br /></td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
