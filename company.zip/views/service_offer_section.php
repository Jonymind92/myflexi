<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.bgc{background:#C6FFFF}
.fl-r{float:right;m}
input,textarea{width:150px;}

</style>
<?php
	$serviceofferdata = $this->db->query("select * from t_servicedata where subject='serviceoffer'")->result();
	$sectiontitle='';
	
	$menutitle1='';
	$menutitle2='';
	$menutitle3='';
	$menutitle4='';
	$menutitle5='';
	
	$header1='';
	$header2='';
	$header3='';
	$header4='';
	$header5='';
	
	$description1='';
	$description2='';
	$description3='';
	$description4='';
	$description5='';
	
	$url1='';
	$url2='';
	$url3='';
	$url4='';
	$url5='';

	
	if(isset($serviceofferdata)&& !empty($serviceofferdata))
	{
		foreach($serviceofferdata as $set)
		{
			if($set->name == 'sectiontitle'){$sectiontitle = $set->value;}
			
			if($set->name == 'menutitle1'){$menutitle1 = $set->value;}
			if($set->name == 'menutitle2'){$menutitle2 = $set->value;}
			if($set->name == 'menutitle3'){$menutitle3 = $set->value;}
			if($set->name == 'menutitle4'){$menutitle4 = $set->value;}
			if($set->name == 'menutitle5'){$menutitle5 = $set->value;}
			
			if($set->name == 'header1'){$header1 = $set->value;}
			if($set->name == 'header2'){$header2 = $set->value;}
			if($set->name == 'header3'){$header3 = $set->value;}
			if($set->name == 'header4'){$header4 = $set->value;}
			if($set->name == 'header5'){$header5 = $set->value;}
			
			if($set->name == 'description1'){$description1 = $set->value;}
			if($set->name == 'description2'){$description2 = $set->value;}
			if($set->name == 'description3'){$description3 = $set->value;}
			if($set->name == 'description4'){$description4 = $set->value;}
			if($set->name == 'description5'){$description5 = $set->value;}
			
			if($set->name == 'url1'){$url1 = $set->value;}
			if($set->name == 'url2'){$url2 = $set->value;}
			if($set->name == 'url3'){$url3 = $set->value;}
			if($set->name == 'url4'){$url4 = $set->value;}
			if($set->name == 'url5'){$url5 = $set->value;}
			
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
    	
      <div class="form">
      	<h3 style="margin-top:-20px;text-transform:uppercase;">Service Offer Info</h3>
        <form action="<?php echo 'admincontroller/update_service_offer_section'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Section Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
                <br />
                <textarea name="sectiontitle" value="<?php if(isset($sectiontitle))echo $sectiontitle ?>" style="width:100%;" ><?php if(isset($sectiontitle))echo $sectiontitle ?></textarea>
              </td>
            </tr>
            
            <tr>
              	<td>
        <table>
			<tr>
            	<th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr> 
            <tr>
            	<th>Menu1</th>
                <th>Menu2</th>
                <th>Menu3</th>
                <th>Menu4</th>
                <th>Menu5</th>
            </tr>              
            <tr>
                <td><br>Menu Name<br /><input type="text" name="menutitle1" value="<?php if(isset($menutitle1))echo $menutitle1 ?>" /></td>
                <td><br>Menu Name<br /><input type="text" name="menutitle2" value="<?php if(isset($menutitle2))echo $menutitle2 ?>" class="bgc"/></td>
                <td><br>Menu Name<br /><input type="text" name="menutitle3" value="<?php if(isset($menutitle3))echo $menutitle3 ?>" /></td>
                <td><br>Menu Name<br /><input type="text" name="menutitle4" value="<?php if(isset($menutitle4))echo $menutitle4 ?>" class="bgc"/></td>
                <td><br>Menu Name<br /><input type="text" name="menutitle5" value="<?php if(isset($menutitle5))echo $menutitle5 ?>" /></td>
            </tr>
            
            
            <tr>
                <td><br>Image<br /><input type="file" name="pic1" /></td>
                <td><br>Image<br /><input type="file" name="pic2" /></td>
                <td><br>Image<br /><input type="file" name="pic3" /></td>
                <td><br>Image<br /><input type="file" name="pic4" /></td>
                <td><br>Image<br /><input type="file" name="pic5" /></td>
            </tr>
            
            <tr>
                <td><br>Header<br /><textarea name="header1" value="<?php if(isset($header1))echo $header1 ?>" ><?php if(isset($header1))echo $header1 ?></textarea></td>
                <td><br>Header<br /><textarea name="header2" value="<?php if(isset($header2))echo $header2 ?>" class="bgc"><?php if(isset($header2))echo $header2 ?></textarea></td>
                <td><br>Header<br /><textarea name="header3" value="<?php if(isset($header3))echo $header3 ?>" ><?php if(isset($header3))echo $header3 ?></textarea></td>
                <td><br>Header<br /><textarea name="header4" value="<?php if(isset($header4))echo $header4 ?>" class="bgc"><?php if(isset($header4))echo $header4 ?></textarea></td>
                <td><br>Header<br /><textarea name="header5" value="<?php if(isset($header5))echo $header5 ?>" ><?php if(isset($header5))echo $header5 ?></textarea></td>
            </tr>
            
            <tr>
                <td><br>description<br /><textarea name="description1" value="<?php if(isset($description1))echo $description1 ?>" ><?php if(isset($description1))echo $description1 ?></textarea></td>
                <td><br>description<br /><textarea name="description2" value="<?php if(isset($description2))echo $description2 ?>" class="bgc"><?php if(isset($description2))echo $description2 ?></textarea></td>
                <td><br>description<br /><textarea name="description3" value="<?php if(isset($description3))echo $description3 ?>" ><?php if(isset($description3))echo $description3 ?></textarea></td>
                <td><br>description<br /><textarea name="description4" value="<?php if(isset($description4))echo $description4 ?>" class="bgc"><?php if(isset($description4))echo $description4 ?></textarea></td>
                <td><br>description<br /><textarea name="description5" value="<?php if(isset($description5))echo $description5 ?>" ><?php if(isset($description5))echo $description5 ?></textarea></td>
            </tr>
            <tr>
                <td><br>Url<br /><textarea name="url1" value="<?php if(isset($url1))echo $url1 ?>" ><?php if(isset($url1))echo $url1 ?></textarea></td>
                <td><br>Url<br /><textarea name="url2" value="<?php if(isset($url2))echo $url2 ?>" class="bgc"><?php if(isset($url2))echo $url2 ?></textarea></td>
                <td><br>Url<br /><textarea name="url3" value="<?php if(isset($url3))echo $url3 ?>" ><?php if(isset($url3))echo $url3 ?></textarea></td>
                <td><br>Url<br /><textarea name="url4" value="<?php if(isset($url4))echo $url4 ?>" class="bgc"><?php if(isset($url4))echo $url4 ?></textarea></td>
                <td><br>Url<br /><textarea name="url5" value="<?php if(isset($url5))echo $url5 ?>" ><?php if(isset($url5))echo $url5 ?></textarea></td>
            </tr>

        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
