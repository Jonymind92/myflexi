<?php
    $brand = $this->mm->getSet('Company Name');
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<base href="<?php echo base_url();?>"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Panel</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="css/masteradmin/bootstrap.css" rel="stylesheet">
     <!-- FONTAWESOME STYLES-->
    <link href="css/masteradmin/font-awesome.css" rel="stylesheet">
     
        <!-- CUSTOM STYLES-->
    <link href="css/masteradmin/custom.css" rel="stylesheet">
     <!-- GOOGLE FONTS-->
   <link href="css/masteradmin/css.css" rel="stylesheet" type="text/css">
   <!-- JQUERY SCRIPTS -->
    <script src="js/masteradmin/jquery-1.js"></script>
   <script src="js/masteradmin/myjs.js"></script>
</head>
<body>

	<?php
    	$isAdminLogin = $this->session->userdata('sid');
		if($isAdminLogin == "")
		{
			redirect('main/index');
		}
	?>
   
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"  href="<?php echo "#";?>"><?php if(isset($brand)&&$brand != "") {echo $brand;}else{echo 'Brand Name';} ?></a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> <a href="<?php echo "admincontroller/admin_logout";?>" class="btn-danger" style="height:50px;padding:10px;text-decoration:none;">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse" aria-expanded="false" style="height: 0px;">
                <ul class="nav" id="main-menu">
					<li class="text-center">
                   	&nbsp;
					</li>
                    
                    <!---------------------------->
                          	<li>
                                <a href="#"> Settings<span style="float:right;font-size:26px;">&#9663;</span></a>
                                  <ul class="nav nav-third-level collapse">	
                                    
                                     <li>
                        		<a <?php if(isset($menu)&& $menu=='brand') echo "class='active-menu'";?> href="<?php echo 'admincontroller/branding_form'?>"> Branding</a>
                    				</li>	
                                     <li>
                                        <a <?php if(isset($menu)&& $menu=='link') echo "class='active-menu'";?> href="<?php echo "admincontroller/setting_sociallink";?>"> Social Link</a>
                                    </li>
                                    <li>
                        				<a <?php if(isset($menu)&& $menu=='partnerlink') echo "class='active-menu'";?>  href="<?php echo "admincontroller/partnerlink_form";?>"> Partner Link</a>
                    				</li>
                                    <!--<li>
                        				<a <?php if(isset($menu)&& $menu=='apisettings') echo "class='active-menu'";?> href="<?php echo "admincontroller/api_set_form";?>"> Api Settings</a>
                    				</li>-->
                                    <li>
                        				<a <?php if(isset($menu)&& $menu=='login') echo "class='active-menu'";?>  href="<?php echo "admincontroller/change_admin";?>"> Admin Login</a>
                    				</li>
                                 </ul>
                        	</li>	

                            <!---------------------------->
                     <!--<li>
                        <a href="#"> Reports<span style="float:right;font-size:26px;">&#9663;</span></a>
                        <ul class="nav nav-second-level collapse">	
                     	
                         <li>
                            <a <?php if(isset($menu)&& $menu=='client') echo "class='active-menu'";?> href="<?php echo "admincontroller/client";?>"> Client List View</a>
                        </li>	
                         <li>
                            <a <?php if(isset($menu)&& $menu=='cardPurchaseInfo') echo "class='active-menu'";?> href="<?php echo "admincontroller/card_purchase_info";?>"> Card Purchase Info</a>
                        </li>	
                     </ul>
                   </li>-->
                   
                   
                   
                   
                   
                   <li>
                        <a href="#"> Page<span style="float:right;font-size:26px;">&#9663;</span></a>
                        <ul class="nav nav-second-level collapse">	
                     	
                         <li>
                            <a href="#"> Home<span style="float:right;font-size:26px;">&#9663;</span></a>
                              <ul class="nav nav-third-level collapse">	
                                
                                 <li>
                                    <a <?php if(isset($menu)&& $menu=='Banner') echo "class='active-menu'";?> href="<?php echo "admincontroller/home_banner_form";?>"> Banner</a>
                                </li>	
                                 <li>
                                    <a <?php if(isset($menu)&& $menu=='Domain') echo "class='active-menu'";?> href="<?php echo "admincontroller/home_domain_form";?>"> Domain</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='homewhychooseus') echo "class='active-menu'";?> href="<?php echo "admincontroller/home_whychooseus_form";?>"> Why choose us</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='hosting_plan') echo "class='active-menu'";?> href="<?php echo "admincontroller/home_hosting_plan";?>"> Hosting plan</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='testimonial') echo "class='active-menu'";?> href="<?php echo "admincontroller/home_testimonial";?>"> Testimonial</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='offer') echo "class='active-menu'";?> href="<?php echo "admincontroller/home_special_officer";?>"> Special Offer</a>
                                </li>
                                <!--<li>
                                    <a <?php if(isset($menu)&& $menu=='knowledge') echo "class='active-menu'";?> href="<?php echo "admincontroller/home_KnowledgeBase";?>"> KnowledgeBase</a>
                                </li>-->	
                             </ul>
                        </li>	
                         <li>
                            <a href="#"> About Us<span style="float:right;font-size:26px;">&#9663;</span></a>
                              <ul class="nav nav-third-level collapse">	
                                
                                 <li>
                                    <a <?php if(isset($menu)&& $menu=='aboutusbanner') echo "class='active-menu'";?> href="<?php echo "admincontroller/aboutusbanner";?>"> Banner</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='aboutusspeciality') echo "class='active-menu'";?> href="<?php echo "admincontroller/about_ourspeciality_form";?>"> Our Speciality</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='aboutus_freedomain') echo "class='active-menu'";?> href="<?php echo "admincontroller/about_freedomain_form";?>"> About Free Domain</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='ourteam') echo "class='active-menu'";?> href="<?php echo "admincontroller/about_ourteam";?>"> Our Team</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='ourtrustedclient') echo "class='active-menu'";?> href="<?php echo "admincontroller/about_ourtrustedclient";?>"> Our Trusted Clients</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='wishers') echo "class='active-menu'";?> href="<?php echo "admincontroller/about_ourwishers";?>"> Our Wishers</a>
                                </li>		
                                 	
                             </ul>
                        </li>
                        
                        
                        
                        
                        <li>
                            <a href="#"> Product<span style="float:right;font-size:26px;">&#9663;</span></a>
                            	
                               <ul class="nav nav-third-level collapse">	
                                 <li>
                                    <a  href="#"> Voip Servers<span style="float:right;font-size:26px;">&#9663;</span></a>
                                    <ul class="nav nav-forth-level collapse">	
                                         <li>
                                            <a <?php if(isset($menu)&& $menu=='product1banner') echo "class='active-menu'";?> href="<?php echo "admincontroller/voip_servers_banner";?>"> Banner</a>
                                        </li>
                                        <li>
                                            <a <?php if(isset($menu)&& $menu=='whychoseus1') echo "class='active-menu'";?> href="<?php echo "admincontroller/voip_servers_whychoseus_form";?>"> Why Chose Us</a>
                                        </li>
                                        <li>
                                    		<a <?php if(isset($menu)&& $menu=='hosting_plan1') echo "class='active-menu'";?> href="<?php echo "admincontroller/voip_server_hosting_plan";?>"> Hosting plan</a>
                                		</li>
                                     </ul>
                                </li>
                                <!------------------>
                                <li>
                                    <a  href="#"> Easy Billing<span style="float:right;font-size:26px;">&#9663;</span></a>
                                    <ul class="nav nav-forth-level collapse">	
                                         <li>
                                            <a <?php if(isset($menu)&& $menu=='product2banner') echo "class='active-menu'";?> href="<?php echo "admincontroller/easy_billing_banner";?>"> Banner</a>
                                        </li>
                                        <li>
                                            <a <?php if(isset($menu)&& $menu=='whychoseus2') echo "class='active-menu'";?> href="<?php echo "admincontroller/easy_billing_whychoseus_form";?>"> Why Chose Us</a>
                                        </li>
                                        <li>
                                    		<a <?php if(isset($menu)&& $menu=='hosting_plan2') echo "class='active-menu'";?> href="<?php echo "admincontroller/easy_billing_hosting_plan";?>"> Hosting plan</a>
                                		</li>
                                     </ul>
                                </li>
                                <!------------------>
                                <li>
                                    <a  href="#"> Easy Recharge<span style="float:right;font-size:26px;">&#9663;</span></a>
                                    <ul class="nav nav-forth-level collapse">	
                                         <li>
                                            <a <?php if(isset($menu)&& $menu=='product3banner') echo "class='active-menu'";?> href="<?php echo "admincontroller/easy_recharge_banner";?>"> Banner</a>
                                        </li>
                                        <li>
                                            <a <?php if(isset($menu)&& $menu=='whychoseus3') echo "class='active-menu'";?> href="<?php echo "admincontroller/easy_recharge_whychoseus_form";?>"> Why Chose Us</a>
                                        </li>
                                        <li>
                                    		<a <?php if(isset($menu)&& $menu=='hosting_plan3') echo "class='active-menu'";?> href="<?php echo "admincontroller/easy_recharge_hosting_plan";?>"> Hosting plan</a>
                                		</li>
                                     </ul>
                                </li>
                             </ul> 
                        </li>
                        
                        
                        
                        <li>
                            <a href="#"> Service<span style="float:right;font-size:26px;">&#9663;</span></a>
                              <ul class="nav nav-third-level collapse">	
                                 <li>
                                    <a <?php if(isset($menu)&& $menu=='service_banner') echo "class='active-menu'";?> href="<?php echo "admincontroller/service_banner_form";?>"> Banner</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='service_work') echo "class='active-menu'";?> href="<?php echo "admincontroller/service_work_form";?>"> Service Work</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='service_hosting') echo "class='active-menu'";?> href="<?php echo "admincontroller/service_hosting_section";?>"> Hosting info</a>
                                </li>
                                <li>
                                    <a <?php if(isset($menu)&& $menu=='service_offer') echo "class='active-menu'";?> href="<?php echo "admincontroller/service_offer_section";?>"> Offer info</a>
                                </li>
                             </ul>
                        </li>
                        <li>
                           <a <?php if(isset($menu)&& $menu=='service_banner') echo "class='active-menu'";?> href="<?php echo "admincontroller/contact_info_form";?>"> Contact</a>
                        </li>		
                     </ul>
                   </li>
                    
                           
                                
                    <!--<li>
                        <a href="#"> Multi-Level Dropdown<span style="float:right">V</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link<span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level collapse">
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>

                                </ul>
                               
                            </li>
                        </ul>
                      </li>  
                  <li>
                        <a href="<?php echo "#";?>"> Blank Page</a>
                    </li>-->	
                </ul>
               <br>



            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <?php if(isset($content)) echo $content;?>          
    		</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="js/masteradmin/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="js/masteradmin/jquery.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="js/masteradmin/raphael-2.js"></script>
   
      <!-- CUSTOM SCRIPTS -->
    <script src="js/masteradmin/custom.js"></script>
    

 



</body></html>