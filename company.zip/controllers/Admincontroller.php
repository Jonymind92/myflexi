<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admincontroller extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
		//$this->output->set_header("Cache-Control: post-check=0, pre-check=0", false);
		//$this->output->set_header("Pragma: no-cache");
		date_default_timezone_set("Asia/Dhaka");
		//$this->mm->isLogin();  ///////// Call isLogin() for all function ////////////////////
	}
	public function index()
	{
		$this->admin_login();
		//$this->load->view('masteradmin');
	}
	public function admin_login()
	{
		$data = array();
		$data['content'] = $this->load->view('admin_login_form');
	}
	public function check_admin_login()
	{
		if($_POST)
		{
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$adminpass = $this->db->query("Select * from t_admin where username = '".$username."' ")->row()->password; 
			$adminpass = $this->mm->read_rc4_pass($username,$adminpass);
			
			if((string)$adminpass == (string)$password)
			{
				$ses = array();
				$usernamepass = $username.$adminpass;
				$ses['sid'] = md5(base64_encode($usernamepass));
				$ses['username'] = trim($username);
				$ses['userid'] = '1';
				$ses['time'] = time();
				$ses['login_time'] = date('Y-m-d h:i:s');
				$ses['ip'] = $_SERVER['REMOTE_ADDR'];
				$ses['loged_in'] = 'true';
				$this->mm->delete_info('t_user_online',array('username'=>$username));
				$this->mm->insert_data('t_user_online',$ses);
			
				$this->session->set_userdata($ses);
				redirect('admincontroller/adminpanel');
			}
			else{redirect('admincontroller/index?esk=Wrong username or password');}
		}
		else
		{
			redirect('main/index');
		}
	}
	public function adminpanel()
	{
		$sid = $this->session->userdata('sid');
		$siddb = $this->db->query("Select sid from t_user_online where sid='".$sid."'")->row()->sid;
		if((string)$siddb == (string)$sid)
		{
			$this->load->view('masteradmin');
		}		
	}
	public function admin_logout()
	{
		$this->session->unset_userdata('sid');
		$this->session->sess_destroy();
		redirect('main/index');
	}

	
	function image_upload ($destinationFolder , $maxSize , $maxWidth , $maxHeight , $fileName,$image1_width,$image1_height,$pic) 
	{
 		$config = array ();
		$config['upload_path'] = $destinationFolder ; 
		$config['allowed_types'] = 'gif|jpg|png|jpeg' ; 
		$config['max_size'] = $maxSize ; 
		$config['max_width'] = $maxWidth ;  
		$config['max_height'] = $maxHeight ; 
		$config['file_name'] = $fileName ; 

 		$this->upload->initialize($config ); 
 		$this->upload->do_upload($pic); 
		
		//Image Thumbnail
		
		$config = array();
		$config['source_image'] = $destinationFolder.$fileName;
		$config['new_image'] = $destinationFolder;
		$config['admintain_ratio'] = FALSE;
		if($image1_width == "" || $image1_height == "")
		{
			$image2_width = 300;
			$image2_height = 300;
		}
		$config['width'] = $image1_width;
		$config['height'] = $image1_height;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();
		
		$this->image_lib->clear(); 
		
 	}
	function image_upload2 ($destinationFolder , $maxSize , $maxWidth , $maxHeight , $fileName,$image1_width,$image1_height,$pic,$oldfile) 
	{
		//delete orginal file
		$oldfile = $destinationFolder.$oldfile;
		if(file_exists($oldfile))
		{
			unlink($oldfile);
		} 
		//new file
 		$config = array ();
		$config['upload_path'] = $destinationFolder ; 
		$config['allowed_types'] = 'gif|jpg|png|jpeg' ; 
		$config['max_size'] = $maxSize ; 
		$config['max_width'] = $maxWidth ;  
		$config['max_height'] = $maxHeight ; 
		$config['file_name'] = $fileName ; 

 		$this->upload->initialize($config ); 
 		$this->upload->do_upload($pic); 
		
		//Image Thumbnail
		
		$config = array();
		$config['source_image'] = $destinationFolder.$fileName;
		$config['new_image'] = $destinationFolder;
		$config['admintain_ratio'] = FALSE;
		if($image1_width == "" || $image1_height == "")
		{
			$image2_width = 300;
			$image2_height = 300;
		}
		$config['width'] = $image1_width;
		$config['height'] = $image1_height;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();
		
		$this->image_lib->clear(); 
		
		
 	}
	
	/////////first delete old file/////////////////////
	function image_upload3 ($destinationFolder , $maxSize , $maxWidth , $maxHeight , $fileName,$image1_width,$image1_height,$pic,$oldfile) 
	{
		//first delete old file
		$oldfile = $destinationFolder.$oldfile;
		if(file_exists($oldfile))
		{
			unlink($oldfile);
		}
		
 		$config = array ();
		$config['upload_path'] = $destinationFolder ; 
		$config['allowed_types'] = 'gif|jpg|png|jpeg' ; 
		$config['max_size'] = $maxSize ; 
		$config['max_width'] = $maxWidth ;  
		$config['max_height'] = $maxHeight ; 
		$config['file_name'] = $fileName ; 

 		$this->upload->initialize($config ); 
 		$this->upload->do_upload($pic); 
		
		//Image Thumbnail
		
		$config = array();
		$config['source_image'] = $destinationFolder.$fileName;
		$config['new_image'] = $destinationFolder;
		$config['admintain_ratio'] = FALSE;
		if($image1_width == "" || $image1_height == "")
		{
			$image2_width = 300;
			$image2_height = 300;
		}
		$config['width'] = $image1_width;
		$config['height'] = $image1_height;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();
		
		$this->image_lib->clear();  
 	}
	public function home_banner_form()
	{
		$data = array();
		$data['menu'] = 'Banner';
		$data['content'] = $this->load->view('home_banner_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_homebanner()
	{
		if($_POST)
		{
			$bannertitle = $this->input->post('homebannertitle');
			$bannersubtitle = $this->input->post('homebannersubtitle');
			$p = pathinfo($_FILES['pic']['name']);
			if(count($p)>2)//pic
			{
				$p = pathinfo($_FILES['pic']['name']);
				$ext = strtolower($p['extension']); 
				$picname = "";
				$rand = rand(1000,10000);
				$picname = $rand.'.png';

				$imgfilename = $picname;
				$oldfile = $this->db->query("select value from t_homedata where name ='homebannerimg'")->row()->value; 
				$this->image_upload2('./img/' , '3750000', '2500', '1500', $imgfilename ,'1920','650','pic',$oldfile);

				$data = array();
				$data['value'] = trim($picname);	
				$this->mm->update_info('t_homedata',$data,array('name'=>'homebannerimg'));
			}
			$data = array();
			$data['value'] = trim($bannertitle);
			$this->mm->update_info('t_homedata',$data,array('name'=>'home banner title'));
			$data = array();
			$data['value'] = trim($bannersubtitle);
			$this->mm->update_info('t_homedata',$data,array('name'=>'home banner sub title'));
			redirect('admincontroller/home_banner_form?sk=Updated');
		}
		else{redirect('main/index');}
		
	}
	public function home_domain_form()
	{
		$data = array();
		$data['menu'] = 'Domain';
		$data['content'] = $this->load->view('home_domain_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_homedomainsection()
	{
		if($_POST)
		{
			$homeyourdomain = $this->input->post('homeyourdomain');
			$homesearchtext = $this->input->post('homesearchtext');
			
			$comprice = $this->input->post('com');
			$netprice = $this->input->post('net');
			$infoprice = $this->input->post('info');
			$meprice = $this->input->post('me');
			
			$this->db->query("
				UPDATE t_homedata
   			SET value = CASE name 
               WHEN 'home yourdomain' THEN '".$homeyourdomain."' 
               WHEN 'home searchtext' THEN '".$homesearchtext."' 
			   WHEN '.com' THEN '".$comprice."'
			   WHEN '.net' THEN '".$netprice."'
			   WHEN '.info' THEN '".$infoprice."'
			   WHEN '.me' THEN '".$meprice."'
			   
               ELSE value
               END
 			WHERE name IN('home yourdomain', 'home searchtext', '.com', '.net', '.info', '.me');
			");
			
			redirect('admincontroller/home_domain_form?sk=Updated');
		}
		else{redirect('main/index');}
		
	}
	public function home_whychooseus_form()
	{
		$data = array();
		$data['menu'] = 'homewhychooseus';
		$data['content'] = $this->load->view('home_whychooseus_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	
	
	
	public function update_whatmakesthesiteunique()
	{
		$homesiteuniq  = htmlspecialchars(trim($this->input->post('homesiteuniq')), ENT_QUOTES);
		$homesiteuniqsubtext  = htmlspecialchars(trim($this->input->post('homesiteuniqsubtext')), ENT_QUOTES);
		$homePARALLAXEFFECT  = htmlspecialchars(trim($this->input->post('homePARALLAXEFFECT')), ENT_QUOTES);
		$homeMOVABLESECTIONS  = htmlspecialchars(trim($this->input->post('homeMOVABLESECTIONS')), ENT_QUOTES);
		$homeWOOCOMMERCE  = htmlspecialchars(trim($this->input->post('homeWOOCOMMERCE')), ENT_QUOTES);
		$homeCUSTOMCONTENTBLOCKS  = htmlspecialchars(trim($this->input->post('homeCUSTOMCONTENTBLOCKS')), ENT_QUOTES);
		$section1focus  = htmlspecialchars(trim($this->input->post('section1focus')), ENT_QUOTES);
		$section2focus  = htmlspecialchars(trim($this->input->post('section2focus')), ENT_QUOTES);
		$section3focus  = htmlspecialchars(trim($this->input->post('section3focus')), ENT_QUOTES);
		$section4focus  = htmlspecialchars(trim($this->input->post('section4focus')), ENT_QUOTES);
		$section1body  = htmlspecialchars(trim($this->input->post('section1body')), ENT_QUOTES);
		$section2body  = htmlspecialchars(trim($this->input->post('section2body')), ENT_QUOTES); 
		$section3body  = htmlspecialchars(trim($this->input->post('section3body')), ENT_QUOTES); 
		$section4body = htmlspecialchars(trim($this->input->post('section4body')), ENT_QUOTES);
		
		$this->db->query("UPDATE t_homedata
   			SET value = CASE name 
               WHEN 'home siteuniq' THEN '".$homesiteuniq."' 
			   WHEN 'home siteuniq subtext' THEN '".$homesiteuniqsubtext."'
			   WHEN 'home PARALLAX EFFECT' THEN '".$homePARALLAXEFFECT."'
			   WHEN 'home MOVABLE SECTIONS' THEN '".$homeMOVABLESECTIONS."'
			   WHEN 'home WOOCOMMERCE' THEN '".$homeWOOCOMMERCE."'
			   WHEN 'home CUSTOM CONTENT BLOCKS' THEN '".$homeCUSTOMCONTENTBLOCKS."'
			   WHEN 'home FOCUS HEADING1' THEN '".$section1focus."'
			   WHEN 'home FOCUS HEADING2' THEN '".$section2focus."' 
			   WHEN 'home FOCUS HEADING3' THEN '".$section3focus."'
			   WHEN 'home FOCUS HEADING4' THEN '".$section4focus."'
			   WHEN 'home PARALLAX EFFECT body' THEN '".$section1body."'
			   WHEN 'home MOVABLE SECTIONS body' THEN '".$section2body."'
			   WHEN 'home WOOCOMMERCE body' THEN '".$section3body."'
			   WHEN 'home CUSTOM CONTENT BLOCKS body' THEN '".$section4body."'
               
               ELSE value
               END
 			WHERE name IN('home siteuniq', 'home siteuniq subtext', 'home PARALLAX EFFECT', 'home MOVABLE SECTIONS', 'home WOOCOMMERCE', 'home CUSTOM CONTENT BLOCKS', 'home FOCUS HEADING1', 'home FOCUS HEADING2', 'home FOCUS HEADING3', 'home FOCUS HEADING4', 'home PARALLAX EFFECT body', 'home MOVABLE SECTIONS body', 'home WOOCOMMERCE body', 'home CUSTOM CONTENT BLOCKS body' )");
			//1//
				$p = pathinfo($_FILES['pic1']['name']);
				if(count($p)>2)//pic
				{
					$p = pathinfo($_FILES['pic1']['name']);
					$ext = strtolower($p['extension']); 
					$picname = "parallaximg.png";
					$imgfilename = $picname;
					$oldfile = $picname;
					$this->image_upload2('./img/' , '15000000', '5000', '3000', $imgfilename ,'67','63','pic1',$oldfile);
					$data = array();
					$data['value'] = trim($picname);	
					$this->mm->update_info('t_homedata',$data,array('name'=>'parallaximg'));
				}
			//2//
				$p = pathinfo($_FILES['pic2']['name']);
				if(count($p)>2)//pic
				{
					$p = pathinfo($_FILES['pic2']['name']);
					$ext = strtolower($p['extension']); 
					$picname = "movableimg.png";
					$imgfilename = $picname;
					$oldfile = $picname;
					$this->image_upload2('./img/' , '15000000', '5000', '3000', $imgfilename ,'62','63','pic2',$oldfile);
					$data = array();
					$data['value'] = trim($picname);	
					$this->mm->update_info('t_homedata',$data,array('name'=>'movableimg'));
				}
			//3//	
				$p = pathinfo($_FILES['pic3']['name']);
				if(count($p)>2)//pic
				{
					$p = pathinfo($_FILES['pic3']['name']);
					$ext = strtolower($p['extension']); 
					$picname = "wooimg.png";
					$imgfilename = $picname;
					$oldfile = $picname;
					$this->image_upload2('./img/' , '15000000', '5000', '3000', $imgfilename ,'62','63','pic3',$oldfile);
					$data = array();
					$data['value'] = trim($picname);	
					$this->mm->update_info('t_homedata',$data,array('name'=>'wooimg'));
				}
			//4//
				$p = pathinfo($_FILES['pic4']['name']);
				if(count($p)>2)//pic
				{
					$p = pathinfo($_FILES['pic4']['name']);
					$ext = strtolower($p['extension']); 
					$picname = "customcontentimg.png";
					$imgfilename = $picname;
					$oldfile = $picname;
					$this->image_upload2('./img/' , '15000000', '5000', '3000', $imgfilename ,'62','63','pic4',$oldfile);
					$data = array();
					$data['value'] = trim($picname);	
					$this->mm->update_info('t_homedata',$data,array('name'=>'customcontentimg'));
				}
		
		redirect('admincontroller/home_whychooseus_form?sk=Updated');	
	}
	public function home_hosting_plan()
	{
		$data = array();
		$data['menu'] = 'hosting_plan';
		$data['content'] = $this->load->view('home_hosting_plan',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_hosting_plan()
	{
		
         $homeHostingPlans = htmlspecialchars(trim($this->input->post('homeHostingPlans')),ENT_QUOTES);
		 $homeHostingPlansbody  = htmlspecialchars(trim($this->input->post('homeHostingPlansbody')),ENT_QUOTES);
		 
		 $homeHostingPlans1Price = htmlspecialchars(trim($this->input->post('homeHostingPlans1Price')),ENT_QUOTES);
		 $homeHostingPlans1Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans1Name')),ENT_QUOTES);
		 $homehosting1processor  = htmlspecialchars(trim($this->input->post('homehosting1processor')),ENT_QUOTES);
		 $homehosting1RAM  = htmlspecialchars(trim($this->input->post('homehosting1RAM')),ENT_QUOTES);
		 $homehosting1HDD  = htmlspecialchars(trim($this->input->post('homehosting1HDD')),ENT_QUOTES);
		 $homehosting1OS  = htmlspecialchars(trim($this->input->post('homehosting1OS')),ENT_QUOTES);
		 $homehosting1LAN  = htmlspecialchars(trim($this->input->post('homehosting1LAN')),ENT_QUOTES);
		 $homehosting1Application = htmlspecialchars(trim($this->input->post('homehosting1Application')),ENT_QUOTES); 
		 $homehosting1ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting1ConcurrentCalls')),ENT_QUOTES);
		 $homehosting1Billing  = htmlspecialchars(trim($this->input->post('homehosting1Billing')),ENT_QUOTES);
		 $homehosting1Apps  = htmlspecialchars(trim($this->input->post('homehosting1Apps')),ENT_QUOTES);
		 $homehosting1Service = htmlspecialchars(trim($this->input->post('homehosting1Service')),ENT_QUOTES);
		 
		 $homeHostingPlans2Price = htmlspecialchars(trim($this->input->post('homeHostingPlans2Price')),ENT_QUOTES);
		 $homeHostingPlans2Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans2Name')),ENT_QUOTES);
		 $homehosting2processor  = htmlspecialchars(trim($this->input->post('homehosting2processor')),ENT_QUOTES);
		 $homehosting2RAM  = htmlspecialchars(trim($this->input->post('homehosting2RAM')),ENT_QUOTES);
		 $homehosting2HDD  = htmlspecialchars(trim($this->input->post('homehosting2HDD')),ENT_QUOTES);
		 $homehosting2OS  = htmlspecialchars(trim($this->input->post('homehosting2OS')),ENT_QUOTES);
		 $homehosting2LAN  = htmlspecialchars(trim($this->input->post('homehosting2LAN')),ENT_QUOTES);
		 $homehosting2Application = htmlspecialchars(trim($this->input->post('homehosting2Application')),ENT_QUOTES);
		 $homehosting2ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting2ConcurrentCalls')),ENT_QUOTES);
		 $homehosting2Billing  = htmlspecialchars(trim($this->input->post('homehosting2Billing')),ENT_QUOTES);
		 $homehosting2Apps  = htmlspecialchars(trim($this->input->post('homehosting2Apps')),ENT_QUOTES);
		 $homehosting2Service = htmlspecialchars(trim($this->input->post('homehosting2Service')),ENT_QUOTES);
		 
		 $homeHostingPlans3Price = htmlspecialchars(trim($this->input->post('homeHostingPlans3Price')),ENT_QUOTES);
		 $homeHostingPlans3Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans3Name')),ENT_QUOTES);
		 $homehosting3processor  = htmlspecialchars(trim($this->input->post('homehosting3processor')),ENT_QUOTES);
		 $homehosting3RAM  = htmlspecialchars(trim($this->input->post('homehosting3RAM')),ENT_QUOTES);
		 $homehosting3HDD  = htmlspecialchars(trim($this->input->post('homehosting3HDD')),ENT_QUOTES);
		 $homehosting3OS  = htmlspecialchars(trim($this->input->post('homehosting3OS')),ENT_QUOTES);
		 $homehosting3LAN  = htmlspecialchars(trim($this->input->post('homehosting3LAN')),ENT_QUOTES);
		 $homehosting3Application = htmlspecialchars(trim($this->input->post('homehosting3Application')),ENT_QUOTES); 
		 $homehosting3ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting3ConcurrentCalls')),ENT_QUOTES);
		 $homehosting3Billing  = htmlspecialchars(trim($this->input->post('homehosting3Billing')),ENT_QUOTES);
		 $homehosting3Apps  = htmlspecialchars(trim($this->input->post('homehosting3Apps')),ENT_QUOTES);
		 $homehosting3Service = htmlspecialchars(trim($this->input->post('homehosting3Service')),ENT_QUOTES);
		 
		 $homeHostingPlans4Price = htmlspecialchars(trim($this->input->post('homeHostingPlans4Price')),ENT_QUOTES); 
		 $homeHostingPlans4Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans4Name')),ENT_QUOTES);
		 $homehosting4processor  = htmlspecialchars(trim($this->input->post('homehosting4processor')),ENT_QUOTES);
		 $homehosting4RAM  = htmlspecialchars(trim($this->input->post('homehosting4RAM')),ENT_QUOTES);
		 $homehosting4HDD  = htmlspecialchars(trim($this->input->post('homehosting4HDD')),ENT_QUOTES);
		 $homehosting4OS  = htmlspecialchars(trim($this->input->post('homehosting4OS')),ENT_QUOTES);
		 $homehosting4LAN  = htmlspecialchars(trim($this->input->post('homehosting4LAN')),ENT_QUOTES);
		 $homehosting4Application = htmlspecialchars(trim($this->input->post('homehosting4Application')),ENT_QUOTES);
		 $homehosting4ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting4ConcurrentCalls')),ENT_QUOTES);
		 $homehosting4Billing  = htmlspecialchars(trim($this->input->post('homehosting4Billing')),ENT_QUOTES);
		 $homehosting4Apps  = htmlspecialchars(trim($this->input->post('homehosting4Apps')),ENT_QUOTES);
		 $homehosting4Service = htmlspecialchars(trim($this->input->post('homehosting4Service')),ENT_QUOTES);
		
		 $homehosting1buttonname = htmlspecialchars(trim($this->input->post('homehosting1buttonname')),ENT_QUOTES);
		 $homehosting2buttonname = htmlspecialchars(trim($this->input->post('homehosting2buttonname')),ENT_QUOTES);
		 $homehosting3buttonname = htmlspecialchars(trim($this->input->post('homehosting3buttonname')),ENT_QUOTES);
		 $homehosting4buttonname = htmlspecialchars(trim($this->input->post('homehosting4buttonname')),ENT_QUOTES);
		 
		 $homeHostingPlanSharedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanSharedDataUrl')),ENT_QUOTES);
		 $homeHostingPlanVPSDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanVPSDataUrl')),ENT_QUOTES);
		 $homeHostingPlanResellerDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanResellerDataUrl')),ENT_QUOTES);
		 $homeHostingPlanDedicatedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanDedicatedDataUrl')),ENT_QUOTES);
		 
		 
		 $result = $this->db->query("UPDATE t_homedata
   			SET value = CASE name 
               WHEN 'home Hosting Plans' THEN '".$homeHostingPlans."' 
               WHEN 'home Hosting Plans body' THEN '".$homeHostingPlansbody."' 
			   
			   WHEN 'home Hosting Plans1 Name' THEN '".$homeHostingPlans1Name."'
			   WHEN 'home Hosting Plans1 Price' THEN '".$homeHostingPlans1Price."'
			   WHEN 'home hosting1 processor' THEN '".$homehosting1processor."'
			   WHEN 'home hosting1 RAM' THEN '".$homehosting1RAM."'
			   WHEN 'home hosting1 HDD' THEN '".$homehosting1HDD."'
			   WHEN 'home hosting1 OS' THEN '".$homehosting1OS."'
			   WHEN 'home hosting1 LAN' THEN '".$homehosting1LAN."'
			   WHEN 'home hosting1 Application' THEN '".$homehosting1Application."' 
			   WHEN 'home hosting1 Concurrent Calls' THEN '".$homehosting1ConcurrentCalls."'
			   WHEN 'home hosting1 Billing' THEN '".$homehosting1Billing."'
			   WHEN 'home hosting1 Apps' THEN '".$homehosting1Apps."'
			   WHEN 'home hosting1 Service' THEN '".$homehosting1Service."'
			   WHEN 'homehosting1buttonname' THEN '".$homehosting1buttonname."'
			   WHEN 'homeHostingPlanSharedDataUrl' THEN '".$homeHostingPlanSharedDataUrl."'
			   
			   WHEN 'home Hosting Plans2 Name' THEN '".$homeHostingPlans2Name."'
			   WHEN 'home Hosting Plans2 Price' THEN '".$homeHostingPlans2Price."'
			   WHEN 'home hosting2 processor' THEN '".$homehosting2processor."'
			   WHEN 'home hosting2 RAM' THEN '".$homehosting2RAM."'
			   WHEN 'home hosting2 HDD' THEN '".$homehosting2HDD."'
			   WHEN 'home hosting2 OS' THEN '".$homehosting2OS."'
			   WHEN 'home hosting2 LAN' THEN '".$homehosting2LAN."'
			   WHEN 'home hosting2 Application' THEN '".$homehosting2Application."' 
			   WHEN 'home hosting2 Concurrent Calls' THEN '".$homehosting2ConcurrentCalls."'
			   WHEN 'home hosting2 Billing' THEN '".$homehosting2Billing."'
			   WHEN 'home hosting2 Apps' THEN '".$homehosting2Apps."'
			   WHEN 'home hosting2 Service' THEN '".$homehosting2Service."'
			   WHEN 'homehosting2buttonname' THEN '".$homehosting2buttonname."'
			   WHEN 'homeHostingPlanVPSDataUrl' THEN '".$homeHostingPlanVPSDataUrl."'
			   
			   WHEN 'home Hosting Plans3 Name' THEN '".$homeHostingPlans3Name."'
			   WHEN 'home Hosting Plans3 Price' THEN '".$homeHostingPlans3Price."'
			   WHEN 'home hosting3 processor' THEN '".$homehosting3processor."'
			   WHEN 'home hosting3 RAM' THEN '".$homehosting3RAM."'
			   WHEN 'home hosting3 HDD' THEN '".$homehosting3HDD."'
			   WHEN 'home hosting3 OS' THEN '".$homehosting3OS."'
			   WHEN 'home hosting3 LAN' THEN '".$homehosting3LAN."'
			   WHEN 'home hosting3 Application' THEN '".$homehosting3Application."' 
			   WHEN 'home hosting3 Concurrent Calls' THEN '".$homehosting3ConcurrentCalls."'
			   WHEN 'home hosting3 Billing' THEN '".$homehosting3Billing."'
			   WHEN 'home hosting3 Apps' THEN '".$homehosting3Apps."'
			   WHEN 'home hosting3 Service' THEN '".$homehosting3Service."'
			   WHEN 'homehosting3buttonname' THEN '".$homehosting3buttonname."'
			   WHEN 'homeHostingPlanResellerDataUrl' THEN '".$homeHostingPlanResellerDataUrl."'
			   
			   WHEN 'home Hosting Plans4 Name' THEN '".$homeHostingPlans4Name."'
			   WHEN 'home Hosting Plans4 Price' THEN '".$homeHostingPlans4Price."'
			   WHEN 'home hosting4 processor' THEN '".$homehosting4processor."'
			   WHEN 'home hosting4 RAM' THEN '".$homehosting4RAM."'
			   WHEN 'home hosting4 HDD' THEN '".$homehosting4HDD."'
			   WHEN 'home hosting4 OS' THEN '".$homehosting4OS."'
			   WHEN 'home hosting4 LAN' THEN '".$homehosting4LAN."'
			   WHEN 'home hosting4 Application' THEN '".$homehosting4Application."' 
			   WHEN 'home hosting4 Concurrent Calls' THEN '".$homehosting4ConcurrentCalls."'
			   WHEN 'home hosting4 Billing' THEN '".$homehosting4Billing."'
			   WHEN 'home hosting4 Apps' THEN '".$homehosting4Apps."'
			   WHEN 'home hosting4 Service' THEN '".$homehosting4Service."'
			   WHEN 'homehosting4buttonname' THEN '".$homehosting4buttonname."'
			   WHEN 'homeHostingPlanDedicatedDataUrl' THEN '".$homeHostingPlanDedicatedDataUrl."'
			   
               ELSE value
               END
 			WHERE name IN('home Hosting Plans', 'home Hosting Plans body', 'home Hosting Plans1 Name', 'home Hosting Plans1 Price', 'home hosting1 processor','home hosting1 RAM', 'home hosting1 HDD', 'home hosting1 OS', 'home hosting1 LAN', 'home hosting1 Application', 'home hosting1 Concurrent Calls', 'home hosting1 Billing', 'home hosting1 Apps', 'home hosting1 Service', 'homehosting1buttonname', 'homeHostingPlanSharedDataUrl', 'home Hosting Plans2 Name', 'home Hosting Plans2 Price', 'home hosting2 processor','home hosting2 RAM', 'home hosting2 HDD', 'home hosting2 OS', 'home hosting2 LAN', 'home hosting2 Application', 'home hosting2 Concurrent Calls', 'home hosting2 Billing', 'home hosting2 Apps', 'home hosting2 Service', 'homehosting2buttonname', 'homeHostingPlanVPSDataUrl', 'home Hosting Plans3 Name', 'home Hosting Plans3 Price', 'home hosting3 processor','home hosting3 RAM', 'home hosting3 HDD', 'home hosting3 OS', 'home hosting3 LAN', 'home hosting3 Application', 'home hosting3 Concurrent Calls', 'home hosting3 Billing', 'home hosting3 Apps', 'home hosting3 Service', 'homehosting3buttonname', 'homeHostingPlanResellerDataUrl', 'home Hosting Plans4 Name', 'home Hosting Plans4 Price', 'home hosting4 processor','home hosting4 RAM', 'home hosting4 HDD', 'home hosting4 OS', 'home hosting4 LAN', 'home hosting4 Application', 'home hosting4 Concurrent Calls', 'home hosting4 Billing', 'home hosting4 Apps', 'home hosting4 Service', 'homehosting4buttonname', 'homeHostingPlanDedicatedDataUrl')");
			//echo $result;exit;
		redirect("admincontroller/home_hosting_plan?sk=Updated");	
		
	}
	
	
	public function home_testimonial()
	{
		$data = array();
		$data['menu'] = 'testimonial';
		$data['content'] = $this->load->view('home_testimonial',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_hometestimonial()
	{
		$testimonial = $this->input->post('testimonial');
		if(!empty($testimonial))
		{
			$data = array();$data['value'] = trim($testimonial);
			$this->mm->update_info('t_homedata',$data,array('name'=>'home Testimonial1'));
			$this->mm->update_info('t_homedata',$data,array('name'=>'home Testimonial2'));
		}
		redirect("admincontroller/home_testimonial?sk=Updated");
	}
	/*public function home_KnowledgeBase()
	{
		$data = array();
		$data['menu'] = 'knowledge';
		$data['content'] = $this->load->view('home_KnowledgeBase',$data,true);
		$this->load->view('masteradmin',$data);
	}*/
	/*public function update_homeKnowledge()
	{
		$header = $this->input->post('header');
		$des = $this->input->post('des');
		
		if(!empty($header)){$data = array();$data['value'] = trim($header);
			$this->mm->update_info('t_homedata',$data,array('name'=>'home Knowledge Base Header'));}	
		if(!empty($des)){$data = array();$data['value'] = trim($des);
			$this->mm->update_info('t_homedata',$data,array('name'=>'home Knowledge Base body'));}
		redirect("admincontroller/home_KnowledgeBase?sk=Updated");	
	}*/
	public function home_special_officer()
	{
		$data = array();
		$data['menu'] = 'offer';
		$data['content'] = $this->load->view('home_special_officer',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_home_special_officer()
	{
		$header = $this->input->post('header');
		$linkurl = $this->input->post('linkurl');
		$picname ="";
		if(isset($_FILES['pic']))
		{
			$p = pathinfo($_FILES['pic']['name']);
			if(count($p)>2)
			{
				$picname = "offer";
				$picname = $picname.'.png';
			}
		}
		
		if(!empty($header))
		{
			$data = array();
			$data['value'] = trim($header);
			$this->mm->update_info('t_homedata',$data,array('name'=>'special_offer'));
		}
		if(!empty($linkurl))
		{
			$data = array();
			$data['value'] = trim($linkurl);
			$this->mm->update_info('t_homedata',$data,array('name'=>'special_offer_url'));
		}	
		if(isset($_FILES['pic']))
		{
			$data = array();
			$data['value'] = $picname;
			$this->mm->update_info('t_homedata',$data,array('name'=>'specialofferimg'));
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->mm->image_upload2('./img/product/' , '15000000', '5000', '3000', $imgfilename ,'600','300','pic',$oldfile);
		}
		redirect("admincontroller/home_special_officer?sk=Updated");	
	}
	public function setting_sociallink()
	{
		$data = array();
		$data['menu'] = 'link';
		$data['content'] = $this->load->view('setting_link_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_sociallink()
	{
		$facebook = $this->input->post('facebook');
		$googleplus = $this->input->post('googleplus');
		$twitter = $this->input->post('twitter');
		$forum = $this->input->post('forum');
		
		if(!empty($facebook)){$data = array();$data['value'] = trim($facebook);
			$this->mm->update_info('t_settings',$data,array('name'=>'facebook'));}	
		if(!empty($googleplus)){$data = array();$data['value'] = trim($googleplus);
			$this->mm->update_info('t_settings',$data,array('name'=>'google plus'));}	
		if(!empty($twitter)){$data = array();$data['value'] = trim($twitter);
			$this->mm->update_info('t_settings',$data,array('name'=>'twitter'));}	
		if(!empty($forum)){$data = array();$data['value'] = trim($forum);
			$this->mm->update_info('t_settings',$data,array('name'=>'forum'));}
		redirect("admincontroller/setting_sociallink?sk=Updated");
	}
	public function branding_form()
	{
		$data = array();
		$data['menu'] = 'branding';
		$data['content'] = $this->load->view('setting_branding_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_branding()
	{
		$companyName = $this->input->post('companyName');
		$aboutCompanywork = $this->input->post('aboutCompanywork');
		$address = $this->input->post('address');
		$phone = $this->input->post('phone');
		$email = $this->input->post('email');
		$loginLink = $this->input->post('loginLink');
		$registerLink = $this->input->post('registerLink');
		$emailuslink = $this->input->post('emailuslink');
		$footerCopyrighttext = $this->input->post('footerCopyrighttext');
		if(!empty($companyName)){$data = array();$data['value'] = trim($companyName);
			$this->mm->update_info('t_settings',$data,array('name'=>'Company Name'));}	
		if(!empty($aboutCompanywork)){$data = array();$data['value'] = trim($aboutCompanywork);
			$this->mm->update_info('t_settings',$data,array('name'=>'About Company work'));}
		if(!empty($address)){$data = array();$data['value'] = trim($address);
			$this->mm->update_info('t_settings',$data,array('name'=>'Address'));}
		if(!empty($phone)){$data = array();$data['value'] = trim($phone);
			$this->mm->update_info('t_settings',$data,array('name'=>'phone'));}
			
		if(!empty($email)){$data = array();$data['value'] = trim($email);
			$this->mm->update_info('t_settings',$data,array('name'=>'servermail'));}
		if(!empty($loginLink)){$data = array();$data['value'] = trim($loginLink);
			$this->mm->update_info('t_settings',$data,array('name'=>'Login Link'));}	
		if(!empty($registerLink)){$data = array();$data['value'] = trim($registerLink);
			$this->mm->update_info('t_settings',$data,array('name'=>'Register Link'));}
		if(!empty($emailuslink)){$data = array();$data['value'] = trim($emailuslink);
			$this->mm->update_info('t_settings',$data,array('name'=>'E-mail us link'));}
		if(!empty($footerCopyrighttext)){$data = array();$data['value'] = trim($footerCopyrighttext);
			$this->mm->update_info('t_settings',$data,array('name'=>'Footer Copyright text'));}
		redirect("admincontroller/branding_form?sk=Updated");
	}
	public function partnerlink_form()
	{
		$data = array();
		$data['menu'] = 'partnerlink';
		$data['content'] = $this->load->view('partnerlink_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function insert_partnerlink()
	{
		$numofpartnerlink = $this->db->query('select * from t_settings where subject="partnerlink"')->result();
		$num=0;$num = count($numofpartnerlink);
		
		$p = pathinfo($_FILES['partnerlink']['name']);
		if(count($p)>2)//pic
		{
			$p = pathinfo($_FILES['partnerlink']['name']);
			$ext = strtolower($p['extension']); 
			$rand = rand(1000,10000);
			$picname = $rand.'.png';
			$imgfilename = $picname;
			$this->image_upload('./img/link/' , '3750000', '2500', '1500', $imgfilename ,'100','70','partnerlink');
			$data = array();
			$data['name'] = 'partnerlink'.($num+1);
			$data['value'] = trim($picname);
			$data['subject'] = 'partnerlink';	
			$result = $this->mm->insert_data('t_settings',$data);
			if($result=='true'){redirect('admincontroller/partnerlink_form?sk=Uploaded');}
			else{redirect('admincontroller/partnerlink_form?esk=Fail to upload');}
		}
		else{redirect('admincontroller/partnerlink_form?esk=Fail to upload');}
	}
	public function partnerlink_edit_form($partnerlinkname)
	{
		$data =array();
		$data['partnerlink'] = $this->db->query("select * from t_settings where name='".$partnerlinkname."'")->result();
		$data['menu'] = 'partnerlink';
		$data['content'] = $this->load->view('partnerlink_edit_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function upload_partnerlink($name,$value)
	{
		$p = pathinfo($_FILES['partnerlink']['name']);
		if(count($p)>2)//pic
		{
			$p = pathinfo($_FILES['partnerlink']['name']);
			$ext = strtolower($p['extension']); 
			$rand = rand(1000,10000);
			$picname = $rand.'.png';
			$imgfilename = $picname;
			$oldfile = $value;
			$this->image_upload2('./img/link/' , '3750000', '2500', '1500', $imgfilename ,'100','70','partnerlink',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$result = $this->mm->update_info('t_settings',$data,array('name'=>$name));
			if($result=='true'){redirect('admincontroller/partnerlink_form?sk=Uploaded');}
			else{redirect('admincontroller/partnerlink_form?esk=Fail to upload');}
		}
		else{redirect('admincontroller/partnerlink_form?esk=Fail to upload');}
	}
	public function partnerlink_delete_form($name, $value)
	{
		$result = $this->mm->delete_info('t_settings',array('name'=>$name));
		if($result == "true")
		{
			$oldfile = $value;
			$oldfile = './img/link/'.$oldfile;
			if(file_exists($oldfile))
			{
				unlink($oldfile);
			}
			redirect('admincontroller/partnerlink_form?sk=Deleted');
		}
		else{redirect('admincontroller/partnerlink_form?esk=Fail to delete');}
		
	}
	public function aboutusbanner()
	{
		$data =array();
		$data['menu'] = 'aboutusbanner';
		$data['content'] = $this->load->view('aboutus_banner_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_aboutusbanner()
	{
		$bannertitle = $this->input->post("bannertitle");
		if(!empty($bannertitle))
		{
			$data = array();
			$data['value'] = trim($bannertitle);
			$this->mm->update_info('t_aboutusdata',$data,array('name'=>'bannertitle'));	
		}
		$p = pathinfo($_FILES['bannerimg']['name']);
		if(count($p)>2)//pic
		{
			$ext = strtolower($p['extension']); 
			$picname = 'aboutusbanner.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/aboutus/' , '6000000', '3000', '2000', $imgfilename ,'1600','200','bannerimg',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$result = $this->mm->update_info('t_aboutusdata',$data,array('name'=>'bannerimg'));
			redirect('admincontroller/aboutusbanner?sk=Uploaded');
		}
		redirect('admincontroller/aboutusbanner?sk=Uploaded');
		
	}
	public function about_ourspeciality_form()
	{
		$data =array();
		$data['menu'] = 'aboutusspeciality';
		$data['content'] = $this->load->view('aboutus_ourspeciality_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_aboutourspeciality()
	{
		$title = $this->input->post('title');
		$speciality = $this->input->post('speciality');
		if(!empty($title)){$data = array();$data['value'] = trim($title);
			$this->mm->update_info('t_aboutusdata',$data,array('name'=>'ourspeciality'));}
		if(!empty($speciality)){$data = array();$data['value'] = trim($speciality);
			$this->mm->update_info('t_aboutusdata',$data,array('name'=>'ourspecialitybody'));}	
		$p = pathinfo($_FILES['specialitysectionimg']['name']);
		if(count($p)>2)//pic
		{
			$p = pathinfo($_FILES['specialitysectionimg']['name']);
			$ext = strtolower($p['extension']); 
			$picname = 'about.jpg';
			$imgfilename = $picname;
			$oldfile = 'about.jpg';
			$this->image_upload2('./img/aboutus/' , '15000000', '5000', '3000', $imgfilename ,'544','370','specialitysectionimg',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$result = $this->mm->update_info('t_aboutusdata',$data,array('name'=>'ourspecialityimg'));
			redirect('admincontroller/about_ourspeciality_form?sk=Uploaded');
		}
		redirect('admincontroller/about_ourspeciality_form?sk=Uploaded');
		
	}
	public function about_freedomain_form()
	{
		$data =array();
		$data['menu'] = 'aboutus_freedomain';
		$data['content'] = $this->load->view('aboutus_freedomain_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_aboutourfreedomain()
	{
		$title = $this->input->post('title');
		$describtion = $this->input->post('describtion');
		if(!empty($title)){$data = array();$data['value'] = trim($title);
			$this->mm->update_info('t_aboutusdata',$data,array('name'=>'freedomaintitle'));}
		if(!empty($describtion)){$data = array();$data['value'] = trim($describtion);
			$this->mm->update_info('t_aboutusdata',$data,array('name'=>'freedomainbody'));}	
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)>2)//pic
		{
			$p = pathinfo($_FILES['pic']['name']);
			$ext = strtolower($p['extension']); 
			$picname = 'specialty-monitor.png';
			$imgfilename = $picname;
			$oldfile = 'specialty-monitor.png';
			$this->image_upload2('./img/aboutus/' , '15000000', '5000', '3000', $imgfilename ,'301','266','pic',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$result = $this->mm->update_info('t_aboutusdata',$data,array('name'=>'freedomainimg'));
			redirect('admincontroller/about_freedomain_form?sk=Uploaded');
		}
		redirect('admincontroller/about_freedomain_form?sk=Uploaded');
	}
	public function about_ourteam()
	{
		$data =array();
		$data['menu'] = 'ourteam';
		$data['content'] = $this->load->view('about_ourteam',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function insert_aboutus_team()
	{	
		$name = trim($this->input->post('name'));
		$designation = trim($this->input->post('designation'));
		$err=0;
		$msg='';
		if($name == ""){$msg .=++$err.'. Name required<br>';}
		if($designation == ""){$msg .=++$err.'. Designation required<br>';}
		
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)<3){$msg .=++$err.'. Photo required';}
			
		if($err==0)
		{
			$rand = rand(1000,10000);
			$picname = $rand.'.png';
			
			$data = array();
			$data['name']= $name;
			$data['value1']= $designation;
			$data['value2']= $picname;
			$data['subject']= 'ourteam';
			$result = $this->mm->insert_data('t_pic',$data);
			if($result == true)
			{
				if(count($p)>2)//pic
				{
					$p = pathinfo($_FILES['pic']['name']);
					$ext = strtolower($p['extension']); 
					$imgfilename = $picname;
					$this->image_upload('./img/aboutus/' , '3750000', '2500', '1500', $imgfilename ,'238','271','pic');
					redirect('admincontroller/about_ourteam?sk=Saved Successfully');
				}
			}
			else{redirect('admincontroller/about_ourteam?esk=Error!!! try later');}
		}
		else{redirect('admincontroller/about_ourteam?esk='.$msg);}
	}
	public function about_ourteam_edit_form($pic)
	{
		$data =array();
		$data['menu'] = 'ourteam'; 
		$data['ourteam'] = $this->db->query("select * from  t_pic where subject='ourteam' and value2='".$pic."' ")->row();
		$data['content'] = $this->load->view('about_ourteam_edit',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_aboutus_team($pic)
	{
		$name = trim($this->input->post('name'));
		$designation = trim($this->input->post('designation'));
		$err=0;
		$msg='';
		if($name == ""){$msg .=++$err.'. Name required<br>';}
		if($designation == ""){$msg .=++$err.'. Designation required<br>';}
			
		if($err==0)
		{
			$picname = $pic;
			
			$data = array();
			$data['name']= $name;
			$data['value1']= $designation;
			
			$result = $this->mm->update_info('t_pic',$data, array('value2'=>$pic,'subject'=>'ourteam'));
			if($result == true)
			{
				$p = pathinfo($_FILES['pic']['name']);
				if(count($p)>2)//pic
				{
					$ext = strtolower($p['extension']); 
					$imgfilename = $picname;
					$oldfile = $picname;
					$this->image_upload2('./img/aboutus/' , '3750000', '2500', '1500', $imgfilename ,'238','271','pic',$oldfile);
				}
				redirect('admincontroller/about_ourteam?ssk=Updated Successfully');
			}
			else{redirect('admincontroller/about_ourteam/'.$pic.'?eesk=Error!!! try later');}
		}
		else{redirect('admincontroller/about_ourteam_edit_form/'.$pic.'?esk='.$msg);}
	}
	public function aboutus_member_delete($pic)
	{
		$result = $this->mm->delete_info('t_pic',array('value2'=>$pic,'subject'=>'ourteam'));
		if($result == true)
		{
			$oldfile = $pic;
			$oldfile = './img/aboutus/'.$oldfile;
			if(file_exists($oldfile))
			{
				unlink($oldfile);
			}
			redirect('admincontroller/about_ourteam?ssk=Deleted');
		}
		else{redirect('admincontroller/about_ourteam?eesk=Fail to delete');}
	}
	public function about_ourtrustedclient()
	{
		$data =array();
		$data['menu'] = 'ourtrustedclient';
		$data['content'] = $this->load->view('about_ourtrustedclient',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function insert_aboutus_trusted_client()
	{
		$msg ='';
		$err=0;
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)<3){$msg .=++$err.'. Photo required';}
			
		if($err==0)
		{
			$rand = rand(1000,10000);
			$picname = $rand.'.png';
			
			$data = array();
			$data['name']= 'client'.$rand;
			$data['value2']= $picname;
			$data['subject']= 'ourctrustedlient';
			$result = $this->mm->insert_data('t_pic',$data);
			if($result == true)
			{
				if(count($p)>2)//pic
				{
					$p = pathinfo($_FILES['pic']['name']);
					$ext = strtolower($p['extension']); 
					$imgfilename = $picname;
					$this->image_upload('./img/aboutus/' , '3750000', '2500', '1500', $imgfilename ,'209','154','pic');
					redirect('admincontroller/about_ourtrustedclient?sk=Saved Successfully');
				}
			}
			else{redirect('admincontroller/about_ourtrustedclient?esk=Error!!! try later');}
		}
		else{redirect('admincontroller/about_ourtrustedclient?esk='.$msg);}
	}
	public function aboutus_trusted_client_edit_form($pic)
	{
		$data =array();
		$data['menu'] = 'ourteam'; 
		$data['ourclient'] = $this->db->query("select * from  t_pic where subject='ourctrustedlient' and value2='".$pic."' ")->row();
		$data['content'] = $this->load->view('aboutus_trusted_client_edit_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_aboutus_trusted_client($pic)
	{
		$msg ='';
		$err=0;
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)<3){$msg .=++$err.'. Photo required';}
			
		if($err==0)
		{
			$picname = $pic;
			
			$data = array();
			$data['value2']= $picname;
			$data['subject']= 'ourctrustedlient';
			$result = $this->mm->update_info('t_pic',$data, array('value2'=>$pic,'subject'=>'ourctrustedlient'));
			if($result == true)
			{
				if(count($p)>2)//pic
				{
					$ext = strtolower($p['extension']); 
					$imgfilename = $picname;
					$oldfile = $picname;
					$this->image_upload2('./img/aboutus/' , '3750000', '2500', '1500', $imgfilename ,'209','154','pic',$oldfile);
					redirect('admincontroller/about_ourtrustedclient?ssk=Update Successfully');
				}
			}
			else{redirect('admincontroller/about_ourtrustedclient?eesk=Error!!! try later');}
		}
		else{redirect('admincontroller/aboutus_trusted_client_edit_form'.$pic.'?esk='.$msg);}
	}
	public function aboutus_trusted_client_delete($pic)
	{
		$result = $this->mm->delete_info('t_pic',array('value2'=>$pic,'subject'=>'ourctrustedlient'));
		if($result == true)
		{
			$oldfile = $pic;
			$oldfile = './img/aboutus/'.$oldfile;
			if(file_exists($oldfile))
			{
				unlink($oldfile);
			}
			redirect('admincontroller/about_ourtrustedclient?ssk=Deleted');
		}
		else{redirect('admincontroller/about_ourtrustedclient?eesk=Fail to delete');}
	}
	public function about_ourwishers()
	{
		$data =array();
		$data['menu'] = 'wishers';
		$data['content'] = $this->load->view('about_ourwishers',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function insert_aboutus_wishers()
	{
		$msg ='';
		$err=0;
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)<3){$msg .=++$err.'. Photo required';}
			
		if($err==0)
		{
			$rand = rand(1000,10000);
			$picname = $rand.'.png';
			
			$data = array();
			$data['name']= 'client'.$rand;
			$data['value2']= $picname;
			$data['subject']= 'wishers';
			$result = $this->mm->insert_data('t_pic',$data);
			if($result == true)
			{
				if(count($p)>2)//pic
				{
					$p = pathinfo($_FILES['pic']['name']);
					$ext = strtolower($p['extension']); 
					$imgfilename = $picname;
					$this->image_upload('./img/aboutus/' , '15000000', '5000', '3000', $imgfilename ,'264','265','pic');
					redirect('admincontroller/about_ourwishers?sk=Saved Successfully');
				}
			}
			else{redirect('admincontroller/about_ourwishers?esk=Error!!! try later');}
		}
		else{redirect('admincontroller/about_ourwishers?esk='.$msg);}
	}
	public function aboutus_ourwishers_edit_form($pic)
	{
		$data =array();
		$data['menu'] = 'ourteam'; 
		$data['ourclient'] = $this->db->query("select * from  t_pic where subject='wishers' and value2='".$pic."' ")->row();
		$data['content'] = $this->load->view('aboutus_ourwishers_edit_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_aboutus_wishers($pic)
	{
		$msg ='';
		$err=0;
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)<3){$msg .=++$err.'. Photo required';}
			
		if($err==0)
		{
			$picname = $pic;
			
			$data = array();
			$data['value2']= $picname;
			$data['subject']= 'wishers';
			$result = $this->mm->update_info('t_pic',$data, array('value2'=>$pic,'subject'=>'wishers'));
			if($result == true)
			{
				if(count($p)>2)//pic
				{ 
					$imgfilename = $pic;
					$oldfile = $pic;
					$this->image_upload2('./img/aboutus/' , '15000000', '5000', '3000', $imgfilename ,'264','265','pic',$oldfile);
					redirect('admincontroller/about_ourwishers?ssk=Update Successfully');
				}
			}
			else{redirect('admincontroller/about_ourwishers?eesk=Error!!! try later');}
		}
		else{redirect('admincontroller/aboutus_ourwishers_edit_form/'.$pic.'?esk='.$msg);}
	}
	
	public function aboutus_wishers_delete($pic)
	{
		$result = $this->mm->delete_info('t_pic',array('value2'=>$pic,'subject'=>'wishers'));
		if($result == true)
		{
			$oldfile = $pic;
			$oldfile = './img/aboutus/'.$oldfile;
			if(file_exists($oldfile))
			{
				unlink($oldfile);
			}
			redirect('admincontroller/about_ourwishers?ssk=Deleted');
		}
		else{redirect('admincontroller/about_ourwishers?eesk=Fail to delete');}
	}
	
	
	
	
	///////////// Product section ///////////////////////////////////////////////////////////////////////
	
	////// product 1 //////////////
	public function voip_servers_banner() //voip server
	{
		$data =array();
		$data['menu'] = 'product1banner'; 
		$data['content'] = $this->load->view('product1_banner_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_voip_servers_banner()
	{
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)>2)//pic
		{
			$ext = strtolower($p['extension']); 
			$picname = 'product1banner.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/product/' , '15000000', '5000', '3000', $imgfilename ,'1920','650','pic',$oldfile);
			$data = array();
			$data['value'] = trim($picname);
			$result = $this->mm->update_info('t_productdata',$data,array('name'=>'bannerimg'));
			redirect('admincontroller/voip_servers_banner?sk=Updated');
		}
	}
	public function voip_servers_whychoseus_form()
	{
		$data =array();
		$data['menu'] = 'whychoseus1'; 
		$data['content'] = $this->load->view('product1_whychoseus_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_voip_servers_whychoseus()
	{
		$whychosetitle= htmlspecialchars(trim($this->input->post('whychosetitle')),ENT_QUOTES);
		$whychoseusdescription= htmlspecialchars(trim($this->input->post('whychoseusdescription')),ENT_QUOTES);
		
		$section1title= htmlspecialchars(trim($this->input->post('section1title')),ENT_QUOTES);
		$section2title= htmlspecialchars(trim($this->input->post('section2title')),ENT_QUOTES);
		$section3title= htmlspecialchars(trim($this->input->post('section3title')),ENT_QUOTES);
		$section4title= htmlspecialchars(trim($this->input->post('section4title')),ENT_QUOTES); 
		
		$section1subtitle= htmlspecialchars(trim($this->input->post('section1subtitle')),ENT_QUOTES);
		$section2subtitle= htmlspecialchars(trim($this->input->post('section2subtitle')),ENT_QUOTES);
		$section3subtitle= htmlspecialchars(trim($this->input->post('section3subtitle')),ENT_QUOTES); 
		$section4subtitle= htmlspecialchars(trim($this->input->post('section4subtitle')),ENT_QUOTES); 
		
		$section1url= htmlspecialchars(trim($this->input->post('section1url')),ENT_QUOTES);
		$section2url= htmlspecialchars(trim($this->input->post('section2url')),ENT_QUOTES); 
		$section3url= htmlspecialchars(trim($this->input->post('section3url')),ENT_QUOTES);
		$section4url= htmlspecialchars(trim($this->input->post('section4url')),ENT_QUOTES);
		//pic1 pic2 pic3 pic4
		
		$result = $this->db->query("UPDATE t_productdata
   			SET value = CASE name 
               WHEN 'whychoseustitle' THEN '".$whychosetitle."' 
               WHEN 'whychoseussubtitle' THEN '".$whychoseusdescription."' 
			   
			   WHEN 'whychoseussection1title' THEN '".$section1title."'
			   WHEN 'whychoseussection2title' THEN '".$section2title."'
			   WHEN 'whychoseussection3title' THEN '".$section3title."'
			   WHEN 'whychoseussection4title' THEN '".$section4title."'
			   
			   WHEN 'whychoseussection1subtitle' THEN '".$section1subtitle."'
			   WHEN 'whychoseussection2subtitle' THEN '".$section2subtitle."'
			   WHEN 'whychoseussection3subtitle' THEN '".$section3subtitle."'
			   WHEN 'whychoseussection4subtitle' THEN '".$section4subtitle."' 
			   
			   WHEN 'whychoseussection1url' THEN '".$section1url."'
			   WHEN 'whychoseussection2url' THEN '".$section2url."'
			   WHEN 'whychoseussection3url' THEN '".$section3url."'
			   WHEN 'whychoseussection4url' THEN '".$section4url."'

               ELSE value
               END
 			WHERE name IN('whychoseustitle', 'whychoseussubtitle', 'whychoseussection1title', 'whychoseussection2title', 'whychoseussection3title','whychoseussection4title', 'whychoseussection1subtitle', 'whychoseussection2subtitle', 'whychoseussection3subtitle', 'whychoseussection4subtitle', 'whychoseussection1url', 'whychoseussection2url', 'whychoseussection3url', 'whychoseussection4url')");

		redirect("admincontroller/voip_servers_whychoseus_form?sk=Updated");
		
		
	}
	
	
	////// product 2 //////////////
	public function easy_billing_banner() //easy billing
	{
		$data =array();
		$data['menu'] = 'product2banner'; 
		$data['content'] = $this->load->view('product2_banner_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_easy_billing_banner()
	{
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)>2)//pic
		{
			$ext = strtolower($p['extension']); 
			$picname = 'product2banner.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/product/' , '15000000', '5000', '3000', $imgfilename ,'1920','650','pic',$oldfile);
			$data = array();
			$data['value'] = trim($picname);
			$result = $this->mm->update_info('t_product2data',$data,array('name'=>'bannerimg'));
			redirect('admincontroller/easy_billing_banner?sk=Updated');
		}
	}
	public function easy_billing_whychoseus_form()
	{
		$data =array();
		$data['menu'] = 'whychoseus1'; 
		$data['content'] = $this->load->view('product2_whychoseus_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_easy_billing_whychoseus()
	{
		$whychosetitle= htmlspecialchars(trim($this->input->post('whychosetitle')),ENT_QUOTES);
		$whychoseusdescription= htmlspecialchars(trim($this->input->post('whychoseusdescription')),ENT_QUOTES);
		
		$section1title= htmlspecialchars(trim($this->input->post('section1title')),ENT_QUOTES);
		$section2title= htmlspecialchars(trim($this->input->post('section2title')),ENT_QUOTES);
		$section3title= htmlspecialchars(trim($this->input->post('section3title')),ENT_QUOTES);
		$section4title= htmlspecialchars(trim($this->input->post('section4title')),ENT_QUOTES); 
		
		$section1subtitle= htmlspecialchars(trim($this->input->post('section1subtitle')),ENT_QUOTES);
		$section2subtitle= htmlspecialchars(trim($this->input->post('section2subtitle')),ENT_QUOTES);
		$section3subtitle= htmlspecialchars(trim($this->input->post('section3subtitle')),ENT_QUOTES); 
		$section4subtitle= htmlspecialchars(trim($this->input->post('section4subtitle')),ENT_QUOTES); 
		
		$section1url= htmlspecialchars(trim($this->input->post('section1url')),ENT_QUOTES);
		$section2url= htmlspecialchars(trim($this->input->post('section2url')),ENT_QUOTES); 
		$section3url= htmlspecialchars(trim($this->input->post('section3url')),ENT_QUOTES);
		$section4url= htmlspecialchars(trim($this->input->post('section4url')),ENT_QUOTES);
		//pic1 pic2 pic3 pic4
		
		$result = $this->db->query("UPDATE t_product2data
   			SET value = CASE name 
               WHEN 'whychoseustitle' THEN '".$whychosetitle."' 
               WHEN 'whychoseussubtitle' THEN '".$whychoseusdescription."' 
			   
			   WHEN 'whychoseussection1title' THEN '".$section1title."'
			   WHEN 'whychoseussection2title' THEN '".$section2title."'
			   WHEN 'whychoseussection3title' THEN '".$section3title."'
			   WHEN 'whychoseussection4title' THEN '".$section4title."'
			   
			   WHEN 'whychoseussection1subtitle' THEN '".$section1subtitle."'
			   WHEN 'whychoseussection2subtitle' THEN '".$section2subtitle."'
			   WHEN 'whychoseussection3subtitle' THEN '".$section3subtitle."'
			   WHEN 'whychoseussection4subtitle' THEN '".$section4subtitle."' 
			   
			   WHEN 'whychoseussection1url' THEN '".$section1url."'
			   WHEN 'whychoseussection2url' THEN '".$section2url."'
			   WHEN 'whychoseussection3url' THEN '".$section3url."'
			   WHEN 'whychoseussection4url' THEN '".$section4url."'

               ELSE value
               END
 			WHERE name IN('whychoseustitle', 'whychoseussubtitle', 'whychoseussection1title', 'whychoseussection2title', 'whychoseussection3title','whychoseussection4title', 'whychoseussection1subtitle', 'whychoseussection2subtitle', 'whychoseussection3subtitle', 'whychoseussection4subtitle', 'whychoseussection1url', 'whychoseussection2url', 'whychoseussection3url', 'whychoseussection4url')");

		redirect("admincontroller/easy_billing_whychoseus_form?sk=Updated");
		
		
	}
	
	////// product 3 //////////////
	public function easy_recharge_banner() //easy recharge
	{
		$data =array();
		$data['menu'] = 'product3banner'; 
		$data['content'] = $this->load->view('product3_banner_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_easy_recharge_banner()
	{
		$p = pathinfo($_FILES['pic']['name']);
		if(count($p)>2)//pic
		{
			$ext = strtolower($p['extension']); 
			$picname = 'product3banner.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/product/' , '15000000', '5000', '3000', $imgfilename ,'1920','650','pic',$oldfile);
			$data = array();
			$data['value'] = trim($picname);
			$result = $this->mm->update_info('t_product3data',$data,array('name'=>'bannerimg'));
			redirect('admincontroller/easy_recharge_banner?sk=Updated');
		}
	}
	public function easy_recharge_whychoseus_form()
	{
		$data =array();
		$data['menu'] = 'whychoseus3'; 
		$data['content'] = $this->load->view('product3_whychoseus_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_easy_recharge_whychoseus()
	{
		$whychosetitle= htmlspecialchars(trim($this->input->post('whychosetitle')),ENT_QUOTES);
		$whychoseusdescription= htmlspecialchars(trim($this->input->post('whychoseusdescription')),ENT_QUOTES);
		
		$section1title= htmlspecialchars(trim($this->input->post('section1title')),ENT_QUOTES);
		$section2title= htmlspecialchars(trim($this->input->post('section2title')),ENT_QUOTES);
		$section3title= htmlspecialchars(trim($this->input->post('section3title')),ENT_QUOTES);
		$section4title= htmlspecialchars(trim($this->input->post('section4title')),ENT_QUOTES); 
		
		$section1subtitle= htmlspecialchars(trim($this->input->post('section1subtitle')),ENT_QUOTES);
		$section2subtitle= htmlspecialchars(trim($this->input->post('section2subtitle')),ENT_QUOTES);
		$section3subtitle= htmlspecialchars(trim($this->input->post('section3subtitle')),ENT_QUOTES); 
		$section4subtitle= htmlspecialchars(trim($this->input->post('section4subtitle')),ENT_QUOTES); 
		
		$section1url= htmlspecialchars(trim($this->input->post('section1url')),ENT_QUOTES);
		$section2url= htmlspecialchars(trim($this->input->post('section2url')),ENT_QUOTES); 
		$section3url= htmlspecialchars(trim($this->input->post('section3url')),ENT_QUOTES);
		$section4url= htmlspecialchars(trim($this->input->post('section4url')),ENT_QUOTES);
		//pic1 pic2 pic3 pic4
		
		$result = $this->db->query("UPDATE t_product3data
   			SET value = CASE name 
               WHEN 'whychoseustitle' THEN '".$whychosetitle."' 
               WHEN 'whychoseussubtitle' THEN '".$whychoseusdescription."' 
			   
			   WHEN 'whychoseussection1title' THEN '".$section1title."'
			   WHEN 'whychoseussection2title' THEN '".$section2title."'
			   WHEN 'whychoseussection3title' THEN '".$section3title."'
			   WHEN 'whychoseussection4title' THEN '".$section4title."'
			   
			   WHEN 'whychoseussection1subtitle' THEN '".$section1subtitle."'
			   WHEN 'whychoseussection2subtitle' THEN '".$section2subtitle."'
			   WHEN 'whychoseussection3subtitle' THEN '".$section3subtitle."'
			   WHEN 'whychoseussection4subtitle' THEN '".$section4subtitle."' 
			   
			   WHEN 'whychoseussection1url' THEN '".$section1url."'
			   WHEN 'whychoseussection2url' THEN '".$section2url."'
			   WHEN 'whychoseussection3url' THEN '".$section3url."'
			   WHEN 'whychoseussection4url' THEN '".$section4url."'

               ELSE value
               END
 			WHERE name IN('whychoseustitle', 'whychoseussubtitle', 'whychoseussection1title', 'whychoseussection2title', 'whychoseussection3title','whychoseussection4title', 'whychoseussection1subtitle', 'whychoseussection2subtitle', 'whychoseussection3subtitle', 'whychoseussection4subtitle', 'whychoseussection1url', 'whychoseussection2url', 'whychoseussection3url', 'whychoseussection4url')");

		redirect("admincontroller/easy_recharge_whychoseus_form?sk=Updated");
		
		
	}
	
	//////////// Product section close //////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	public function service_banner_form()
	{
		$data =array();
		$data['menu'] = 'service_banner'; 
		$data['content'] = $this->load->view('service_banner_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_servicebanner()
	{
		$bannertitle="";
		$bannertitle = $this->input->post("bannertitle");
		if($bannertitle != "")
		{
			$data = array();
			$data['value'] = trim($bannertitle);
			$this->mm->update_info('t_servicedata',$data,array('name'=>'bannertitle'));	
		}
		$p = pathinfo($_FILES['bannerimg']['name']);
		if(count($p)>2)//pic
		{
			$ext = strtolower($p['extension']); 
			$picname = 'servicebanner.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'1920','500','bannerimg',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$result = $this->mm->update_info('t_servicedata',$data,array('name'=>'bannerimg'));
			redirect('admincontroller/service_banner_form?sk=Uploaded');
		}
		redirect('admincontroller/service_banner_form?sk=');
	}
	public function service_work_form()
	{
		$data =array();
		$data['menu'] = 'service_work'; 
		$data['content'] = $this->load->view('service_work_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_servicework()
	{
		$serviceworktitle = htmlspecialchars(trim($this->input->post('serviceworktitle')),ENT_QUOTES);
		$serviceworkdescribtion = htmlspecialchars(trim($this->input->post('serviceworkdescribtion')),ENT_QUOTES);
		$servicework1 = htmlspecialchars(trim($this->input->post('servicework1')),ENT_QUOTES);
		$servicework2 = htmlspecialchars(trim($this->input->post('servicework2')),ENT_QUOTES);
		$servicework3 = htmlspecialchars(trim($this->input->post('servicework3')),ENT_QUOTES);
		$servicework4 = htmlspecialchars(trim($this->input->post('servicework4')),ENT_QUOTES);
		$servicework1percent = htmlspecialchars(trim($this->input->post('servicework1percent')),ENT_QUOTES);
		$servicework2percent = htmlspecialchars(trim($this->input->post('servicework2percent')),ENT_QUOTES);
		$servicework3percent = htmlspecialchars(trim($this->input->post('servicework3percent')),ENT_QUOTES);
		$servicework4percent = htmlspecialchars(trim($this->input->post('servicework4percent')),ENT_QUOTES);
		
		$result = $this->db->query("UPDATE t_servicedata
   			SET value = CASE name 
               WHEN 'serviceworktitle' THEN '".$serviceworktitle."' 
               WHEN 'serviceworkdescribtion' THEN '".$serviceworkdescribtion."' 
			   
			   WHEN 'servicework1' THEN '".$servicework1."'
			   WHEN 'servicework2' THEN '".$servicework2."'
			   WHEN 'servicework3' THEN '".$servicework3."'
			   WHEN 'servicework4' THEN '".$servicework4."'
			   
			   WHEN 'servicework1percent' THEN '".$servicework1percent."'
			   WHEN 'servicework2percent' THEN '".$servicework2percent."'
			   WHEN 'servicework3percent' THEN '".$servicework3percent."'
			   WHEN 'servicework4percent' THEN '".$servicework4percent."' 
			   
               ELSE value
               END
 			WHERE name IN('serviceworktitle', 'serviceworkdescribtion', 'servicework1', 'servicework2', 'servicework3','servicework4', 'servicework1percent', 'servicework2percent', 'servicework3percent', 'servicework4percent')");
			
			redirect('admincontroller/service_work_form?sk=Updated');
		
	}
	public function service_hosting_section()
	{
		$data =array();
		$data['menu'] = 'service_hosting'; 
		$data['content'] = $this->load->view('service_hosting_section',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_service_hosting()
	{
		$subtitle1 = htmlspecialchars(trim($this->input->post('subtitle1')),ENT_QUOTES);
		$subtitle2 = htmlspecialchars(trim($this->input->post('subtitle2')),ENT_QUOTES);
		$subtitle3 = htmlspecialchars(trim($this->input->post('subtitle3')),ENT_QUOTES);
		
		$headertitle1 = htmlspecialchars(trim($this->input->post('headertitle1')),ENT_QUOTES);
		$headertitle2 = htmlspecialchars(trim($this->input->post('headertitle2')),ENT_QUOTES);
		$headertitle3 = htmlspecialchars(trim($this->input->post('headertitle3')),ENT_QUOTES);
		
		$comment1 = htmlspecialchars(trim($this->input->post('comment1')),ENT_QUOTES);
		$comment2 = htmlspecialchars(trim($this->input->post('comment2')),ENT_QUOTES);
		$comment3 = htmlspecialchars(trim($this->input->post('comment3')),ENT_QUOTES);
		
		$url1 = htmlspecialchars(trim($this->input->post('url1')),ENT_QUOTES);
		$url2 = htmlspecialchars(trim($this->input->post('url2')),ENT_QUOTES);
		$url3 = htmlspecialchars(trim($this->input->post('url3')),ENT_QUOTES);
		
		$p1 = pathinfo($_FILES['pic1']['name']);
		if(count($p1)>2)//pic
		{
			$ext = strtolower($p1['extension']); 
			$picname = 'servicehosting1.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'220','220','pic1',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'img1'));
		}
		$p2 = pathinfo($_FILES['pic2']['name']);
		if(count($p2)>2)//pic
		{
			$ext = strtolower($p2['extension']); 
			$picname = 'servicehosting2.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'220','220','pic2',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'img2'));
		}
		$p3 = pathinfo($_FILES['pic3']['name']);
		if(count($p3)>2)//pic
		{
			$ext = strtolower($p3['extension']); 
			$picname = 'servicehosting3.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'220','220','pic3',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'img3'));
		}
		
		$result = $this->db->query("UPDATE t_servicedata
   			SET value = CASE name 
               WHEN 'subtitle1' THEN '".$subtitle1."' 
               WHEN 'subtitle2' THEN '".$subtitle2."' 
			   WHEN 'subtitle3' THEN '".$subtitle3."'
			   
			   WHEN 'headertitle1' THEN '".$headertitle1."'
			   WHEN 'headertitle2' THEN '".$headertitle2."'
			   WHEN 'headertitle3' THEN '".$headertitle3."'
			   
			   WHEN 'comment1' THEN '".$comment1."'
			   WHEN 'comment2' THEN '".$comment2."'
			   WHEN 'comment3' THEN '".$comment3."'
			   
			   WHEN 'url1' THEN '".$url1."'
			   WHEN 'url2' THEN '".$url2."'
			   WHEN 'url3' THEN '".$url3."' 
			   
               ELSE value
               END
 			WHERE name IN('subtitle1', 'subtitle2', 'subtitle3', 'headertitle1', 'headertitle2','headertitle3', 'comment1', 'comment2', 'comment3', 'url1', 'url2', 'url3')");
			
			redirect('admincontroller/service_hosting_section?sk=Updated');
	}
	public function service_offer_section()
	{
		$data =array();
		$data['menu'] = 'service_offer'; 
		$data['content'] = $this->load->view('service_offer_section',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_service_offer_section()
	{
		$sectiontitle = htmlspecialchars(trim($this->input->post('sectiontitle')),ENT_QUOTES);
		$menutitle1 = htmlspecialchars(trim($this->input->post('menutitle1')),ENT_QUOTES);
		$menutitle2 = htmlspecialchars(trim($this->input->post('menutitle2')),ENT_QUOTES);
		$menutitle3 = htmlspecialchars(trim($this->input->post('menutitle3')),ENT_QUOTES);
		$menutitle4 = htmlspecialchars(trim($this->input->post('menutitle4')),ENT_QUOTES);
		$menutitle5 = htmlspecialchars(trim($this->input->post('menutitle5')),ENT_QUOTES);
		$header1 = htmlspecialchars(trim($this->input->post('header1')),ENT_QUOTES);
		$header2 = htmlspecialchars(trim($this->input->post('header2')),ENT_QUOTES);
		$header3 = htmlspecialchars(trim($this->input->post('header3')),ENT_QUOTES);
		$header4 = htmlspecialchars(trim($this->input->post('header4')),ENT_QUOTES);
		$header5 = htmlspecialchars(trim($this->input->post('header5')),ENT_QUOTES);
		$description1 = htmlspecialchars(trim($this->input->post('description1')),ENT_QUOTES);
		$description2 = htmlspecialchars(trim($this->input->post('description2')),ENT_QUOTES);
		$description3 = htmlspecialchars(trim($this->input->post('description3')),ENT_QUOTES);
		$description4 = htmlspecialchars(trim($this->input->post('description4')),ENT_QUOTES);
		$description5 = htmlspecialchars(trim($this->input->post('description5')),ENT_QUOTES);
		$url1 = htmlspecialchars(trim($this->input->post('url1')),ENT_QUOTES);
		$url2 = htmlspecialchars(trim($this->input->post('url2')),ENT_QUOTES);
		$url3 = htmlspecialchars(trim($this->input->post('url3')),ENT_QUOTES);
		$url4 = htmlspecialchars(trim($this->input->post('url4')),ENT_QUOTES);
		$url5 = htmlspecialchars(trim($this->input->post('url5')),ENT_QUOTES);
		
		$p1 = pathinfo($_FILES['pic1']['name']);
		if(count($p1)>2)//pic
		{
			$ext = strtolower($p1['extension']); 
			$picname = 'serviceoffer1.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'320','200','pic1',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'pic1','subject'=>'serviceoffer'));
		}
		$p2 = pathinfo($_FILES['pic2']['name']);
		if(count($p2)>2)//pic
		{
			$ext = strtolower($p2['extension']); 
			$picname = 'serviceoffer2.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'320','200','pic2',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'pic2','subject'=>'serviceoffer'));
		}
		$p3 = pathinfo($_FILES['pic3']['name']);
		if(count($p3)>2)//pic
		{
			$ext = strtolower($p3['extension']); 
			$picname = 'serviceoffer3.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'320','200','pic3',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'pic3','subject'=>'serviceoffer'));
		}
		$p4 = pathinfo($_FILES['pic4']['name']);
		if(count($p4)>2)//pic
		{
			$ext = strtolower($p4['extension']); 
			$picname = 'serviceoffer4.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'320','200','pic4',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'pic4','subject'=>'serviceoffer'));
		}
		$p5 = pathinfo($_FILES['pic5']['name']);
		if(count($p4)>2)//pic
		{
			$ext = strtolower($p5['extension']); 
			$picname = 'serviceoffer5.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/service/' , '15000000', '5000', '3000', $imgfilename ,'320','200','pic5',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_servicedata',$data,array('name'=>'pic5','subject'=>'serviceoffer'));
		}
		
		
		$result = $this->db->query("UPDATE t_servicedata
   			SET value = CASE name 
               WHEN 'sectiontitle' THEN '".$sectiontitle."'
			    
               WHEN 'menutitle1' THEN '".$menutitle1."' 
			   WHEN 'menutitle2' THEN '".$menutitle2."'
			   WHEN 'menutitle3' THEN '".$menutitle3."'
			   WHEN 'menutitle4' THEN '".$menutitle4."'
			   WHEN 'menutitle5' THEN '".$menutitle5."'
			   
			   WHEN 'header1' THEN '".$header1."' 
			   WHEN 'header2' THEN '".$header2."'
			   WHEN 'header3' THEN '".$header3."'
			   WHEN 'header4' THEN '".$header4."'
			   WHEN 'header5' THEN '".$header5."'
			   
			   WHEN 'description1' THEN '".$description1."' 
			   WHEN 'description2' THEN '".$description2."'
			   WHEN 'description3' THEN '".$description3."'
			   WHEN 'description4' THEN '".$description4."'
			   WHEN 'description5' THEN '".$description5."'
			   
			   WHEN 'url1' THEN '".$url1."' 
			   WHEN 'url2' THEN '".$url2."'
			   WHEN 'url3' THEN '".$url3."'
			   WHEN 'url4' THEN '".$url4."'
			   WHEN 'url5' THEN '".$url5."' 
			   
               ELSE value
               END
 			WHERE name IN('sectiontitle', 'menutitle1', 'menutitle2', 'menutitle3', 'menutitle4','menutitle5', 'header1', 'header2', 'header3', 'header4', 'header5', 'description1', 'description2', 'description3', 'description4', 'description5', 'url1', 'url2', 'url3', 'url4', 'url5')");
			
			redirect('admincontroller/service_offer_section?sk=Updated');
	}
	public function contact_info_form()
	{
		$data =array();
		$data['menu'] = 'contactinfo'; 
		$data['content'] = $this->load->view('contact_info_form',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_contactinfo()
	{
		$contactaddress = htmlspecialchars(trim($this->input->post('contactaddress')),ENT_QUOTES);
		$contactemail = htmlspecialchars(trim($this->input->post('contactemail')),ENT_QUOTES);
		$contactphone = htmlspecialchars(trim($this->input->post('contactphone')),ENT_QUOTES);
		$result = $this->db->query("UPDATE t_contactdata
   			SET value = CASE name 
               WHEN 'contactaddress' THEN '".$contactaddress."' 
               WHEN 'contactemail' THEN '".$contactemail."' 
			   WHEN 'contactphone' THEN '".$contactphone."'
			   
               ELSE value
               END
 			WHERE name IN('contactaddress', 'contactemail', 'contactphone')");
	
	$p = pathinfo($_FILES['pic']['name']);
	if(count($p)>2)//pic
		{
			$ext = strtolower($p['extension']); 
			$picname = 'contactmap.jpg';
			$imgfilename = $picname;
			$oldfile = $picname;
			$this->image_upload2('./img/contact/' , '15000000', '5000', '3000', $imgfilename ,'560','660','pic',$oldfile);
			$data = array();
			$data['value'] = trim($picname);	
			$this->mm->update_info('t_contactdata',$data,array('name'=>'map','subject'=>'googlemap'));
		}	
		
			
		redirect('admincontroller/contact_info_form?sk=Updated');
	}
	
	////////////// Product Hosting Plan   //////////////////////////////////////////////////////////////////////////
	
	////////////// Product Hosting Plan 1  ////////////////
	public function voip_server_hosting_plan()  ///voip_server
	{
		$data = array();
		$data['menu'] = 'hosting_plan';
		$data['content'] = $this->load->view('product1_hosting_plan',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_voip_server_hosting_plan()
	{
		
         $homeHostingPlans = htmlspecialchars(trim($this->input->post('homeHostingPlans')),ENT_QUOTES);
		 $homeHostingPlansbody  = htmlspecialchars(trim($this->input->post('homeHostingPlansbody')),ENT_QUOTES);
		 
		 $homeHostingPlans1Price = htmlspecialchars(trim($this->input->post('homeHostingPlans1Price')),ENT_QUOTES);
		 $homeHostingPlans1Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans1Name')),ENT_QUOTES);
		 $homehosting1processor  = htmlspecialchars(trim($this->input->post('homehosting1processor')),ENT_QUOTES);
		 $homehosting1RAM  = htmlspecialchars(trim($this->input->post('homehosting1RAM')),ENT_QUOTES);
		 $homehosting1HDD  = htmlspecialchars(trim($this->input->post('homehosting1HDD')),ENT_QUOTES);
		 $homehosting1OS  = htmlspecialchars(trim($this->input->post('homehosting1OS')),ENT_QUOTES);
		 $homehosting1LAN  = htmlspecialchars(trim($this->input->post('homehosting1LAN')),ENT_QUOTES);
		 $homehosting1Application = htmlspecialchars(trim($this->input->post('homehosting1Application')),ENT_QUOTES); 
		 $homehosting1ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting1ConcurrentCalls')),ENT_QUOTES);
		 $homehosting1Billing  = htmlspecialchars(trim($this->input->post('homehosting1Billing')),ENT_QUOTES);
		 $homehosting1Apps  = htmlspecialchars(trim($this->input->post('homehosting1Apps')),ENT_QUOTES);
		 $homehosting1Service = htmlspecialchars(trim($this->input->post('homehosting1Service')),ENT_QUOTES);
		 
		 $homeHostingPlans2Price = htmlspecialchars(trim($this->input->post('homeHostingPlans2Price')),ENT_QUOTES);
		 $homeHostingPlans2Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans2Name')),ENT_QUOTES);
		 $homehosting2processor  = htmlspecialchars(trim($this->input->post('homehosting2processor')),ENT_QUOTES);
		 $homehosting2RAM  = htmlspecialchars(trim($this->input->post('homehosting2RAM')),ENT_QUOTES);
		 $homehosting2HDD  = htmlspecialchars(trim($this->input->post('homehosting2HDD')),ENT_QUOTES);
		 $homehosting2OS  = htmlspecialchars(trim($this->input->post('homehosting2OS')),ENT_QUOTES);
		 $homehosting2LAN  = htmlspecialchars(trim($this->input->post('homehosting2LAN')),ENT_QUOTES);
		 $homehosting2Application = htmlspecialchars(trim($this->input->post('homehosting2Application')),ENT_QUOTES);
		 $homehosting2ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting2ConcurrentCalls')),ENT_QUOTES);
		 $homehosting2Billing  = htmlspecialchars(trim($this->input->post('homehosting2Billing')),ENT_QUOTES);
		 $homehosting2Apps  = htmlspecialchars(trim($this->input->post('homehosting2Apps')),ENT_QUOTES);
		 $homehosting2Service = htmlspecialchars(trim($this->input->post('homehosting2Service')),ENT_QUOTES);
		 
		 $homeHostingPlans3Price = htmlspecialchars(trim($this->input->post('homeHostingPlans3Price')),ENT_QUOTES);
		 $homeHostingPlans3Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans3Name')),ENT_QUOTES);
		 $homehosting3processor  = htmlspecialchars(trim($this->input->post('homehosting3processor')),ENT_QUOTES);
		 $homehosting3RAM  = htmlspecialchars(trim($this->input->post('homehosting3RAM')),ENT_QUOTES);
		 $homehosting3HDD  = htmlspecialchars(trim($this->input->post('homehosting3HDD')),ENT_QUOTES);
		 $homehosting3OS  = htmlspecialchars(trim($this->input->post('homehosting3OS')),ENT_QUOTES);
		 $homehosting3LAN  = htmlspecialchars(trim($this->input->post('homehosting3LAN')),ENT_QUOTES);
		 $homehosting3Application = htmlspecialchars(trim($this->input->post('homehosting3Application')),ENT_QUOTES); 
		 $homehosting3ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting3ConcurrentCalls')),ENT_QUOTES);
		 $homehosting3Billing  = htmlspecialchars(trim($this->input->post('homehosting3Billing')),ENT_QUOTES);
		 $homehosting3Apps  = htmlspecialchars(trim($this->input->post('homehosting3Apps')),ENT_QUOTES);
		 $homehosting3Service = htmlspecialchars(trim($this->input->post('homehosting3Service')),ENT_QUOTES);
		 
		 $homeHostingPlans4Price = htmlspecialchars(trim($this->input->post('homeHostingPlans4Price')),ENT_QUOTES); 
		 $homeHostingPlans4Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans4Name')),ENT_QUOTES);
		 $homehosting4processor  = htmlspecialchars(trim($this->input->post('homehosting4processor')),ENT_QUOTES);
		 $homehosting4RAM  = htmlspecialchars(trim($this->input->post('homehosting4RAM')),ENT_QUOTES);
		 $homehosting4HDD  = htmlspecialchars(trim($this->input->post('homehosting4HDD')),ENT_QUOTES);
		 $homehosting4OS  = htmlspecialchars(trim($this->input->post('homehosting4OS')),ENT_QUOTES);
		 $homehosting4LAN  = htmlspecialchars(trim($this->input->post('homehosting4LAN')),ENT_QUOTES);
		 $homehosting4Application = htmlspecialchars(trim($this->input->post('homehosting4Application')),ENT_QUOTES);
		 $homehosting4ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting4ConcurrentCalls')),ENT_QUOTES);
		 $homehosting4Billing  = htmlspecialchars(trim($this->input->post('homehosting4Billing')),ENT_QUOTES);
		 $homehosting4Apps  = htmlspecialchars(trim($this->input->post('homehosting4Apps')),ENT_QUOTES);
		 $homehosting4Service = htmlspecialchars(trim($this->input->post('homehosting4Service')),ENT_QUOTES);
		
		 $homehosting1buttonname = htmlspecialchars(trim($this->input->post('homehosting1buttonname')),ENT_QUOTES);
		 $homehosting2buttonname = htmlspecialchars(trim($this->input->post('homehosting2buttonname')),ENT_QUOTES);
		 $homehosting3buttonname = htmlspecialchars(trim($this->input->post('homehosting3buttonname')),ENT_QUOTES);
		 $homehosting4buttonname = htmlspecialchars(trim($this->input->post('homehosting4buttonname')),ENT_QUOTES);
		 
		 $homeHostingPlanSharedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanSharedDataUrl')),ENT_QUOTES);
		 $homeHostingPlanVPSDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanVPSDataUrl')),ENT_QUOTES);
		 $homeHostingPlanResellerDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanResellerDataUrl')),ENT_QUOTES);
		 $homeHostingPlanDedicatedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanDedicatedDataUrl')),ENT_QUOTES);
		 
		 
		 $result = $this->db->query("UPDATE t_productdata
   			SET value = CASE name 
               WHEN 'home Hosting Plans' THEN '".$homeHostingPlans."' 
               WHEN 'home Hosting Plans body' THEN '".$homeHostingPlansbody."' 
			   
			   WHEN 'home Hosting Plans1 Name' THEN '".$homeHostingPlans1Name."'
			   WHEN 'home Hosting Plans1 Price' THEN '".$homeHostingPlans1Price."'
			   WHEN 'home hosting1 processor' THEN '".$homehosting1processor."'
			   WHEN 'home hosting1 RAM' THEN '".$homehosting1RAM."'
			   WHEN 'home hosting1 HDD' THEN '".$homehosting1HDD."'
			   WHEN 'home hosting1 OS' THEN '".$homehosting1OS."'
			   WHEN 'home hosting1 LAN' THEN '".$homehosting1LAN."'
			   WHEN 'home hosting1 Application' THEN '".$homehosting1Application."' 
			   WHEN 'home hosting1 Concurrent Calls' THEN '".$homehosting1ConcurrentCalls."'
			   WHEN 'home hosting1 Billing' THEN '".$homehosting1Billing."'
			   WHEN 'home hosting1 Apps' THEN '".$homehosting1Apps."'
			   WHEN 'home hosting1 Service' THEN '".$homehosting1Service."'
			   WHEN 'homehosting1buttonname' THEN '".$homehosting1buttonname."'
			   WHEN 'homeHostingPlanSharedDataUrl' THEN '".$homeHostingPlanSharedDataUrl."'
			   
			   WHEN 'home Hosting Plans2 Name' THEN '".$homeHostingPlans2Name."'
			   WHEN 'home Hosting Plans2 Price' THEN '".$homeHostingPlans2Price."'
			   WHEN 'home hosting2 processor' THEN '".$homehosting2processor."'
			   WHEN 'home hosting2 RAM' THEN '".$homehosting2RAM."'
			   WHEN 'home hosting2 HDD' THEN '".$homehosting2HDD."'
			   WHEN 'home hosting2 OS' THEN '".$homehosting2OS."'
			   WHEN 'home hosting2 LAN' THEN '".$homehosting2LAN."'
			   WHEN 'home hosting2 Application' THEN '".$homehosting2Application."' 
			   WHEN 'home hosting2 Concurrent Calls' THEN '".$homehosting2ConcurrentCalls."'
			   WHEN 'home hosting2 Billing' THEN '".$homehosting2Billing."'
			   WHEN 'home hosting2 Apps' THEN '".$homehosting2Apps."'
			   WHEN 'home hosting2 Service' THEN '".$homehosting2Service."'
			   WHEN 'homehosting2buttonname' THEN '".$homehosting2buttonname."'
			   WHEN 'homeHostingPlanVPSDataUrl' THEN '".$homeHostingPlanVPSDataUrl."'
			   
			   WHEN 'home Hosting Plans3 Name' THEN '".$homeHostingPlans3Name."'
			   WHEN 'home Hosting Plans3 Price' THEN '".$homeHostingPlans3Price."'
			   WHEN 'home hosting3 processor' THEN '".$homehosting3processor."'
			   WHEN 'home hosting3 RAM' THEN '".$homehosting3RAM."'
			   WHEN 'home hosting3 HDD' THEN '".$homehosting3HDD."'
			   WHEN 'home hosting3 OS' THEN '".$homehosting3OS."'
			   WHEN 'home hosting3 LAN' THEN '".$homehosting3LAN."'
			   WHEN 'home hosting3 Application' THEN '".$homehosting3Application."' 
			   WHEN 'home hosting3 Concurrent Calls' THEN '".$homehosting3ConcurrentCalls."'
			   WHEN 'home hosting3 Billing' THEN '".$homehosting3Billing."'
			   WHEN 'home hosting3 Apps' THEN '".$homehosting3Apps."'
			   WHEN 'home hosting3 Service' THEN '".$homehosting3Service."'
			   WHEN 'homehosting3buttonname' THEN '".$homehosting3buttonname."'
			   WHEN 'homeHostingPlanResellerDataUrl' THEN '".$homeHostingPlanResellerDataUrl."'
			   
			   WHEN 'home Hosting Plans4 Name' THEN '".$homeHostingPlans4Name."'
			   WHEN 'home Hosting Plans4 Price' THEN '".$homeHostingPlans4Price."'
			   WHEN 'home hosting4 processor' THEN '".$homehosting4processor."'
			   WHEN 'home hosting4 RAM' THEN '".$homehosting4RAM."'
			   WHEN 'home hosting4 HDD' THEN '".$homehosting4HDD."'
			   WHEN 'home hosting4 OS' THEN '".$homehosting4OS."'
			   WHEN 'home hosting4 LAN' THEN '".$homehosting4LAN."'
			   WHEN 'home hosting4 Application' THEN '".$homehosting4Application."' 
			   WHEN 'home hosting4 Concurrent Calls' THEN '".$homehosting4ConcurrentCalls."'
			   WHEN 'home hosting4 Billing' THEN '".$homehosting4Billing."'
			   WHEN 'home hosting4 Apps' THEN '".$homehosting4Apps."'
			   WHEN 'home hosting4 Service' THEN '".$homehosting4Service."'
			   WHEN 'homehosting4buttonname' THEN '".$homehosting4buttonname."'
			   WHEN 'homeHostingPlanDedicatedDataUrl' THEN '".$homeHostingPlanDedicatedDataUrl."'
			   
               ELSE value
               END
 			WHERE name IN('home Hosting Plans', 'home Hosting Plans body', 'home Hosting Plans1 Name', 'home Hosting Plans1 Price', 'home hosting1 processor','home hosting1 RAM', 'home hosting1 HDD', 'home hosting1 OS', 'home hosting1 LAN', 'home hosting1 Application', 'home hosting1 Concurrent Calls', 'home hosting1 Billing', 'home hosting1 Apps', 'home hosting1 Service', 'homehosting1buttonname', 'homeHostingPlanSharedDataUrl', 'home Hosting Plans2 Name', 'home Hosting Plans2 Price', 'home hosting2 processor','home hosting2 RAM', 'home hosting2 HDD', 'home hosting2 OS', 'home hosting2 LAN', 'home hosting2 Application', 'home hosting2 Concurrent Calls', 'home hosting2 Billing', 'home hosting2 Apps', 'home hosting2 Service', 'homehosting2buttonname', 'homeHostingPlanVPSDataUrl', 'home Hosting Plans3 Name', 'home Hosting Plans3 Price', 'home hosting3 processor','home hosting3 RAM', 'home hosting3 HDD', 'home hosting3 OS', 'home hosting3 LAN', 'home hosting3 Application', 'home hosting3 Concurrent Calls', 'home hosting3 Billing', 'home hosting3 Apps', 'home hosting3 Service', 'homehosting3buttonname', 'homeHostingPlanResellerDataUrl', 'home Hosting Plans4 Name', 'home Hosting Plans4 Price', 'home hosting4 processor','home hosting4 RAM', 'home hosting4 HDD', 'home hosting4 OS', 'home hosting4 LAN', 'home hosting4 Application', 'home hosting4 Concurrent Calls', 'home hosting4 Billing', 'home hosting4 Apps', 'home hosting4 Service', 'homehosting4buttonname', 'homeHostingPlanDedicatedDataUrl')");
			//echo $result;exit;
		redirect("admincontroller/voip_server_hosting_plan?sk=Updated");	
		
	}
	
	////////////// Product Hosting Plan 2  ////////////////
	public function easy_billing_hosting_plan()  ///voip_server
	{
		$data = array();
		$data['menu'] = 'hosting_plan';
		$data['content'] = $this->load->view('product2_hosting_plan',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_easy_billing_hosting_plan()
	{
		
         $homeHostingPlans = htmlspecialchars(trim($this->input->post('homeHostingPlans')),ENT_QUOTES);
		 $homeHostingPlansbody  = htmlspecialchars(trim($this->input->post('homeHostingPlansbody')),ENT_QUOTES);
		 
		 $homeHostingPlans1Price = htmlspecialchars(trim($this->input->post('homeHostingPlans1Price')),ENT_QUOTES);
		 $homeHostingPlans1Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans1Name')),ENT_QUOTES);
		 $homehosting1processor  = htmlspecialchars(trim($this->input->post('homehosting1processor')),ENT_QUOTES);
		 $homehosting1RAM  = htmlspecialchars(trim($this->input->post('homehosting1RAM')),ENT_QUOTES);
		 $homehosting1HDD  = htmlspecialchars(trim($this->input->post('homehosting1HDD')),ENT_QUOTES);
		 $homehosting1OS  = htmlspecialchars(trim($this->input->post('homehosting1OS')),ENT_QUOTES);
		 $homehosting1LAN  = htmlspecialchars(trim($this->input->post('homehosting1LAN')),ENT_QUOTES);
		 $homehosting1Application = htmlspecialchars(trim($this->input->post('homehosting1Application')),ENT_QUOTES); 
		 $homehosting1ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting1ConcurrentCalls')),ENT_QUOTES);
		 $homehosting1Billing  = htmlspecialchars(trim($this->input->post('homehosting1Billing')),ENT_QUOTES);
		 $homehosting1Apps  = htmlspecialchars(trim($this->input->post('homehosting1Apps')),ENT_QUOTES);
		 $homehosting1Service = htmlspecialchars(trim($this->input->post('homehosting1Service')),ENT_QUOTES);
		 
		 $homeHostingPlans2Price = htmlspecialchars(trim($this->input->post('homeHostingPlans2Price')),ENT_QUOTES);
		 $homeHostingPlans2Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans2Name')),ENT_QUOTES);
		 $homehosting2processor  = htmlspecialchars(trim($this->input->post('homehosting2processor')),ENT_QUOTES);
		 $homehosting2RAM  = htmlspecialchars(trim($this->input->post('homehosting2RAM')),ENT_QUOTES);
		 $homehosting2HDD  = htmlspecialchars(trim($this->input->post('homehosting2HDD')),ENT_QUOTES);
		 $homehosting2OS  = htmlspecialchars(trim($this->input->post('homehosting2OS')),ENT_QUOTES);
		 $homehosting2LAN  = htmlspecialchars(trim($this->input->post('homehosting2LAN')),ENT_QUOTES);
		 $homehosting2Application = htmlspecialchars(trim($this->input->post('homehosting2Application')),ENT_QUOTES);
		 $homehosting2ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting2ConcurrentCalls')),ENT_QUOTES);
		 $homehosting2Billing  = htmlspecialchars(trim($this->input->post('homehosting2Billing')),ENT_QUOTES);
		 $homehosting2Apps  = htmlspecialchars(trim($this->input->post('homehosting2Apps')),ENT_QUOTES);
		 $homehosting2Service = htmlspecialchars(trim($this->input->post('homehosting2Service')),ENT_QUOTES);
		 
		 $homeHostingPlans3Price = htmlspecialchars(trim($this->input->post('homeHostingPlans3Price')),ENT_QUOTES);
		 $homeHostingPlans3Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans3Name')),ENT_QUOTES);
		 $homehosting3processor  = htmlspecialchars(trim($this->input->post('homehosting3processor')),ENT_QUOTES);
		 $homehosting3RAM  = htmlspecialchars(trim($this->input->post('homehosting3RAM')),ENT_QUOTES);
		 $homehosting3HDD  = htmlspecialchars(trim($this->input->post('homehosting3HDD')),ENT_QUOTES);
		 $homehosting3OS  = htmlspecialchars(trim($this->input->post('homehosting3OS')),ENT_QUOTES);
		 $homehosting3LAN  = htmlspecialchars(trim($this->input->post('homehosting3LAN')),ENT_QUOTES);
		 $homehosting3Application = htmlspecialchars(trim($this->input->post('homehosting3Application')),ENT_QUOTES); 
		 $homehosting3ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting3ConcurrentCalls')),ENT_QUOTES);
		 $homehosting3Billing  = htmlspecialchars(trim($this->input->post('homehosting3Billing')),ENT_QUOTES);
		 $homehosting3Apps  = htmlspecialchars(trim($this->input->post('homehosting3Apps')),ENT_QUOTES);
		 $homehosting3Service = htmlspecialchars(trim($this->input->post('homehosting3Service')),ENT_QUOTES);
		 
		 $homeHostingPlans4Price = htmlspecialchars(trim($this->input->post('homeHostingPlans4Price')),ENT_QUOTES); 
		 $homeHostingPlans4Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans4Name')),ENT_QUOTES);
		 $homehosting4processor  = htmlspecialchars(trim($this->input->post('homehosting4processor')),ENT_QUOTES);
		 $homehosting4RAM  = htmlspecialchars(trim($this->input->post('homehosting4RAM')),ENT_QUOTES);
		 $homehosting4HDD  = htmlspecialchars(trim($this->input->post('homehosting4HDD')),ENT_QUOTES);
		 $homehosting4OS  = htmlspecialchars(trim($this->input->post('homehosting4OS')),ENT_QUOTES);
		 $homehosting4LAN  = htmlspecialchars(trim($this->input->post('homehosting4LAN')),ENT_QUOTES);
		 $homehosting4Application = htmlspecialchars(trim($this->input->post('homehosting4Application')),ENT_QUOTES);
		 $homehosting4ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting4ConcurrentCalls')),ENT_QUOTES);
		 $homehosting4Billing  = htmlspecialchars(trim($this->input->post('homehosting4Billing')),ENT_QUOTES);
		 $homehosting4Apps  = htmlspecialchars(trim($this->input->post('homehosting4Apps')),ENT_QUOTES);
		 $homehosting4Service = htmlspecialchars(trim($this->input->post('homehosting4Service')),ENT_QUOTES);
		
		 $homehosting1buttonname = htmlspecialchars(trim($this->input->post('homehosting1buttonname')),ENT_QUOTES);
		 $homehosting2buttonname = htmlspecialchars(trim($this->input->post('homehosting2buttonname')),ENT_QUOTES);
		 $homehosting3buttonname = htmlspecialchars(trim($this->input->post('homehosting3buttonname')),ENT_QUOTES);
		 $homehosting4buttonname = htmlspecialchars(trim($this->input->post('homehosting4buttonname')),ENT_QUOTES);
		 
		 $homeHostingPlanSharedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanSharedDataUrl')),ENT_QUOTES);
		 $homeHostingPlanVPSDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanVPSDataUrl')),ENT_QUOTES);
		 $homeHostingPlanResellerDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanResellerDataUrl')),ENT_QUOTES);
		 $homeHostingPlanDedicatedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanDedicatedDataUrl')),ENT_QUOTES);
		 
		 
		 $result = $this->db->query("UPDATE t_product2data
   			SET value = CASE name 
               WHEN 'home Hosting Plans' THEN '".$homeHostingPlans."' 
               WHEN 'home Hosting Plans body' THEN '".$homeHostingPlansbody."' 
			   
			   WHEN 'home Hosting Plans1 Name' THEN '".$homeHostingPlans1Name."'
			   WHEN 'home Hosting Plans1 Price' THEN '".$homeHostingPlans1Price."'
			   WHEN 'home hosting1 processor' THEN '".$homehosting1processor."'
			   WHEN 'home hosting1 RAM' THEN '".$homehosting1RAM."'
			   WHEN 'home hosting1 HDD' THEN '".$homehosting1HDD."'
			   WHEN 'home hosting1 OS' THEN '".$homehosting1OS."'
			   WHEN 'home hosting1 LAN' THEN '".$homehosting1LAN."'
			   WHEN 'home hosting1 Application' THEN '".$homehosting1Application."' 
			   WHEN 'home hosting1 Concurrent Calls' THEN '".$homehosting1ConcurrentCalls."'
			   WHEN 'home hosting1 Billing' THEN '".$homehosting1Billing."'
			   WHEN 'home hosting1 Apps' THEN '".$homehosting1Apps."'
			   WHEN 'home hosting1 Service' THEN '".$homehosting1Service."'
			   WHEN 'homehosting1buttonname' THEN '".$homehosting1buttonname."'
			   WHEN 'homeHostingPlanSharedDataUrl' THEN '".$homeHostingPlanSharedDataUrl."'
			   
			   WHEN 'home Hosting Plans2 Name' THEN '".$homeHostingPlans2Name."'
			   WHEN 'home Hosting Plans2 Price' THEN '".$homeHostingPlans2Price."'
			   WHEN 'home hosting2 processor' THEN '".$homehosting2processor."'
			   WHEN 'home hosting2 RAM' THEN '".$homehosting2RAM."'
			   WHEN 'home hosting2 HDD' THEN '".$homehosting2HDD."'
			   WHEN 'home hosting2 OS' THEN '".$homehosting2OS."'
			   WHEN 'home hosting2 LAN' THEN '".$homehosting2LAN."'
			   WHEN 'home hosting2 Application' THEN '".$homehosting2Application."' 
			   WHEN 'home hosting2 Concurrent Calls' THEN '".$homehosting2ConcurrentCalls."'
			   WHEN 'home hosting2 Billing' THEN '".$homehosting2Billing."'
			   WHEN 'home hosting2 Apps' THEN '".$homehosting2Apps."'
			   WHEN 'home hosting2 Service' THEN '".$homehosting2Service."'
			   WHEN 'homehosting2buttonname' THEN '".$homehosting2buttonname."'
			   WHEN 'homeHostingPlanVPSDataUrl' THEN '".$homeHostingPlanVPSDataUrl."'
			   
			   WHEN 'home Hosting Plans3 Name' THEN '".$homeHostingPlans3Name."'
			   WHEN 'home Hosting Plans3 Price' THEN '".$homeHostingPlans3Price."'
			   WHEN 'home hosting3 processor' THEN '".$homehosting3processor."'
			   WHEN 'home hosting3 RAM' THEN '".$homehosting3RAM."'
			   WHEN 'home hosting3 HDD' THEN '".$homehosting3HDD."'
			   WHEN 'home hosting3 OS' THEN '".$homehosting3OS."'
			   WHEN 'home hosting3 LAN' THEN '".$homehosting3LAN."'
			   WHEN 'home hosting3 Application' THEN '".$homehosting3Application."' 
			   WHEN 'home hosting3 Concurrent Calls' THEN '".$homehosting3ConcurrentCalls."'
			   WHEN 'home hosting3 Billing' THEN '".$homehosting3Billing."'
			   WHEN 'home hosting3 Apps' THEN '".$homehosting3Apps."'
			   WHEN 'home hosting3 Service' THEN '".$homehosting3Service."'
			   WHEN 'homehosting3buttonname' THEN '".$homehosting3buttonname."'
			   WHEN 'homeHostingPlanResellerDataUrl' THEN '".$homeHostingPlanResellerDataUrl."'
			   
			   WHEN 'home Hosting Plans4 Name' THEN '".$homeHostingPlans4Name."'
			   WHEN 'home Hosting Plans4 Price' THEN '".$homeHostingPlans4Price."'
			   WHEN 'home hosting4 processor' THEN '".$homehosting4processor."'
			   WHEN 'home hosting4 RAM' THEN '".$homehosting4RAM."'
			   WHEN 'home hosting4 HDD' THEN '".$homehosting4HDD."'
			   WHEN 'home hosting4 OS' THEN '".$homehosting4OS."'
			   WHEN 'home hosting4 LAN' THEN '".$homehosting4LAN."'
			   WHEN 'home hosting4 Application' THEN '".$homehosting4Application."' 
			   WHEN 'home hosting4 Concurrent Calls' THEN '".$homehosting4ConcurrentCalls."'
			   WHEN 'home hosting4 Billing' THEN '".$homehosting4Billing."'
			   WHEN 'home hosting4 Apps' THEN '".$homehosting4Apps."'
			   WHEN 'home hosting4 Service' THEN '".$homehosting4Service."'
			   WHEN 'homehosting4buttonname' THEN '".$homehosting4buttonname."'
			   WHEN 'homeHostingPlanDedicatedDataUrl' THEN '".$homeHostingPlanDedicatedDataUrl."'
			   
               ELSE value
               END
 			WHERE name IN('home Hosting Plans', 'home Hosting Plans body', 'home Hosting Plans1 Name', 'home Hosting Plans1 Price', 'home hosting1 processor','home hosting1 RAM', 'home hosting1 HDD', 'home hosting1 OS', 'home hosting1 LAN', 'home hosting1 Application', 'home hosting1 Concurrent Calls', 'home hosting1 Billing', 'home hosting1 Apps', 'home hosting1 Service', 'homehosting1buttonname', 'homeHostingPlanSharedDataUrl', 'home Hosting Plans2 Name', 'home Hosting Plans2 Price', 'home hosting2 processor','home hosting2 RAM', 'home hosting2 HDD', 'home hosting2 OS', 'home hosting2 LAN', 'home hosting2 Application', 'home hosting2 Concurrent Calls', 'home hosting2 Billing', 'home hosting2 Apps', 'home hosting2 Service', 'homehosting2buttonname', 'homeHostingPlanVPSDataUrl', 'home Hosting Plans3 Name', 'home Hosting Plans3 Price', 'home hosting3 processor','home hosting3 RAM', 'home hosting3 HDD', 'home hosting3 OS', 'home hosting3 LAN', 'home hosting3 Application', 'home hosting3 Concurrent Calls', 'home hosting3 Billing', 'home hosting3 Apps', 'home hosting3 Service', 'homehosting3buttonname', 'homeHostingPlanResellerDataUrl', 'home Hosting Plans4 Name', 'home Hosting Plans4 Price', 'home hosting4 processor','home hosting4 RAM', 'home hosting4 HDD', 'home hosting4 OS', 'home hosting4 LAN', 'home hosting4 Application', 'home hosting4 Concurrent Calls', 'home hosting4 Billing', 'home hosting4 Apps', 'home hosting4 Service', 'homehosting4buttonname', 'homeHostingPlanDedicatedDataUrl')");
			//echo $result;exit;
		redirect("admincontroller/easy_billing_hosting_plan?sk=Updated");	
		
	}
	
	////////////// Product Hosting Plan 3  ////////////////
	public function easy_recharge_hosting_plan()  ///voip_server
	{
		$data = array();
		$data['menu'] = 'hosting_plan';
		$data['content'] = $this->load->view('product3_hosting_plan',$data,true);
		$this->load->view('masteradmin',$data);
	}
	public function update_easy_recharge_hosting_plan()
	{
		
         $homeHostingPlans = htmlspecialchars(trim($this->input->post('homeHostingPlans')),ENT_QUOTES);
		 $homeHostingPlansbody  = htmlspecialchars(trim($this->input->post('homeHostingPlansbody')),ENT_QUOTES);
		 
		 $homeHostingPlans1Price = htmlspecialchars(trim($this->input->post('homeHostingPlans1Price')),ENT_QUOTES);
		 $homeHostingPlans1Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans1Name')),ENT_QUOTES);
		 $homehosting1processor  = htmlspecialchars(trim($this->input->post('homehosting1processor')),ENT_QUOTES);
		 $homehosting1RAM  = htmlspecialchars(trim($this->input->post('homehosting1RAM')),ENT_QUOTES);
		 $homehosting1HDD  = htmlspecialchars(trim($this->input->post('homehosting1HDD')),ENT_QUOTES);
		 $homehosting1OS  = htmlspecialchars(trim($this->input->post('homehosting1OS')),ENT_QUOTES);
		 $homehosting1LAN  = htmlspecialchars(trim($this->input->post('homehosting1LAN')),ENT_QUOTES);
		 $homehosting1Application = htmlspecialchars(trim($this->input->post('homehosting1Application')),ENT_QUOTES); 
		 $homehosting1ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting1ConcurrentCalls')),ENT_QUOTES);
		 $homehosting1Billing  = htmlspecialchars(trim($this->input->post('homehosting1Billing')),ENT_QUOTES);
		 $homehosting1Apps  = htmlspecialchars(trim($this->input->post('homehosting1Apps')),ENT_QUOTES);
		 $homehosting1Service = htmlspecialchars(trim($this->input->post('homehosting1Service')),ENT_QUOTES);
		 
		 $homeHostingPlans2Price = htmlspecialchars(trim($this->input->post('homeHostingPlans2Price')),ENT_QUOTES);
		 $homeHostingPlans2Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans2Name')),ENT_QUOTES);
		 $homehosting2processor  = htmlspecialchars(trim($this->input->post('homehosting2processor')),ENT_QUOTES);
		 $homehosting2RAM  = htmlspecialchars(trim($this->input->post('homehosting2RAM')),ENT_QUOTES);
		 $homehosting2HDD  = htmlspecialchars(trim($this->input->post('homehosting2HDD')),ENT_QUOTES);
		 $homehosting2OS  = htmlspecialchars(trim($this->input->post('homehosting2OS')),ENT_QUOTES);
		 $homehosting2LAN  = htmlspecialchars(trim($this->input->post('homehosting2LAN')),ENT_QUOTES);
		 $homehosting2Application = htmlspecialchars(trim($this->input->post('homehosting2Application')),ENT_QUOTES);
		 $homehosting2ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting2ConcurrentCalls')),ENT_QUOTES);
		 $homehosting2Billing  = htmlspecialchars(trim($this->input->post('homehosting2Billing')),ENT_QUOTES);
		 $homehosting2Apps  = htmlspecialchars(trim($this->input->post('homehosting2Apps')),ENT_QUOTES);
		 $homehosting2Service = htmlspecialchars(trim($this->input->post('homehosting2Service')),ENT_QUOTES);
		 
		 $homeHostingPlans3Price = htmlspecialchars(trim($this->input->post('homeHostingPlans3Price')),ENT_QUOTES);
		 $homeHostingPlans3Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans3Name')),ENT_QUOTES);
		 $homehosting3processor  = htmlspecialchars(trim($this->input->post('homehosting3processor')),ENT_QUOTES);
		 $homehosting3RAM  = htmlspecialchars(trim($this->input->post('homehosting3RAM')),ENT_QUOTES);
		 $homehosting3HDD  = htmlspecialchars(trim($this->input->post('homehosting3HDD')),ENT_QUOTES);
		 $homehosting3OS  = htmlspecialchars(trim($this->input->post('homehosting3OS')),ENT_QUOTES);
		 $homehosting3LAN  = htmlspecialchars(trim($this->input->post('homehosting3LAN')),ENT_QUOTES);
		 $homehosting3Application = htmlspecialchars(trim($this->input->post('homehosting3Application')),ENT_QUOTES); 
		 $homehosting3ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting3ConcurrentCalls')),ENT_QUOTES);
		 $homehosting3Billing  = htmlspecialchars(trim($this->input->post('homehosting3Billing')),ENT_QUOTES);
		 $homehosting3Apps  = htmlspecialchars(trim($this->input->post('homehosting3Apps')),ENT_QUOTES);
		 $homehosting3Service = htmlspecialchars(trim($this->input->post('homehosting3Service')),ENT_QUOTES);
		 
		 $homeHostingPlans4Price = htmlspecialchars(trim($this->input->post('homeHostingPlans4Price')),ENT_QUOTES); 
		 $homeHostingPlans4Name  = htmlspecialchars(trim($this->input->post('homeHostingPlans4Name')),ENT_QUOTES);
		 $homehosting4processor  = htmlspecialchars(trim($this->input->post('homehosting4processor')),ENT_QUOTES);
		 $homehosting4RAM  = htmlspecialchars(trim($this->input->post('homehosting4RAM')),ENT_QUOTES);
		 $homehosting4HDD  = htmlspecialchars(trim($this->input->post('homehosting4HDD')),ENT_QUOTES);
		 $homehosting4OS  = htmlspecialchars(trim($this->input->post('homehosting4OS')),ENT_QUOTES);
		 $homehosting4LAN  = htmlspecialchars(trim($this->input->post('homehosting4LAN')),ENT_QUOTES);
		 $homehosting4Application = htmlspecialchars(trim($this->input->post('homehosting4Application')),ENT_QUOTES);
		 $homehosting4ConcurrentCalls  = htmlspecialchars(trim($this->input->post('homehosting4ConcurrentCalls')),ENT_QUOTES);
		 $homehosting4Billing  = htmlspecialchars(trim($this->input->post('homehosting4Billing')),ENT_QUOTES);
		 $homehosting4Apps  = htmlspecialchars(trim($this->input->post('homehosting4Apps')),ENT_QUOTES);
		 $homehosting4Service = htmlspecialchars(trim($this->input->post('homehosting4Service')),ENT_QUOTES);
		
		 $homehosting1buttonname = htmlspecialchars(trim($this->input->post('homehosting1buttonname')),ENT_QUOTES);
		 $homehosting2buttonname = htmlspecialchars(trim($this->input->post('homehosting2buttonname')),ENT_QUOTES);
		 $homehosting3buttonname = htmlspecialchars(trim($this->input->post('homehosting3buttonname')),ENT_QUOTES);
		 $homehosting4buttonname = htmlspecialchars(trim($this->input->post('homehosting4buttonname')),ENT_QUOTES);
		 
		 $homeHostingPlanSharedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanSharedDataUrl')),ENT_QUOTES);
		 $homeHostingPlanVPSDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanVPSDataUrl')),ENT_QUOTES);
		 $homeHostingPlanResellerDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanResellerDataUrl')),ENT_QUOTES);
		 $homeHostingPlanDedicatedDataUrl = htmlspecialchars(trim($this->input->post('homeHostingPlanDedicatedDataUrl')),ENT_QUOTES);
		 
		 
		 $result = $this->db->query("UPDATE t_product3data
   			SET value = CASE name 
               WHEN 'home Hosting Plans' THEN '".$homeHostingPlans."' 
               WHEN 'home Hosting Plans body' THEN '".$homeHostingPlansbody."' 
			   
			   WHEN 'home Hosting Plans1 Name' THEN '".$homeHostingPlans1Name."'
			   WHEN 'home Hosting Plans1 Price' THEN '".$homeHostingPlans1Price."'
			   WHEN 'home hosting1 processor' THEN '".$homehosting1processor."'
			   WHEN 'home hosting1 RAM' THEN '".$homehosting1RAM."'
			   WHEN 'home hosting1 HDD' THEN '".$homehosting1HDD."'
			   WHEN 'home hosting1 OS' THEN '".$homehosting1OS."'
			   WHEN 'home hosting1 LAN' THEN '".$homehosting1LAN."'
			   WHEN 'home hosting1 Application' THEN '".$homehosting1Application."' 
			   WHEN 'home hosting1 Concurrent Calls' THEN '".$homehosting1ConcurrentCalls."'
			   WHEN 'home hosting1 Billing' THEN '".$homehosting1Billing."'
			   WHEN 'home hosting1 Apps' THEN '".$homehosting1Apps."'
			   WHEN 'home hosting1 Service' THEN '".$homehosting1Service."'
			   WHEN 'homehosting1buttonname' THEN '".$homehosting1buttonname."'
			   WHEN 'homeHostingPlanSharedDataUrl' THEN '".$homeHostingPlanSharedDataUrl."'
			   
			   WHEN 'home Hosting Plans2 Name' THEN '".$homeHostingPlans2Name."'
			   WHEN 'home Hosting Plans2 Price' THEN '".$homeHostingPlans2Price."'
			   WHEN 'home hosting2 processor' THEN '".$homehosting2processor."'
			   WHEN 'home hosting2 RAM' THEN '".$homehosting2RAM."'
			   WHEN 'home hosting2 HDD' THEN '".$homehosting2HDD."'

			   WHEN 'home hosting2 OS' THEN '".$homehosting2OS."'
			   WHEN 'home hosting2 LAN' THEN '".$homehosting2LAN."'
			   WHEN 'home hosting2 Application' THEN '".$homehosting2Application."' 
			   WHEN 'home hosting2 Concurrent Calls' THEN '".$homehosting2ConcurrentCalls."'
			   WHEN 'home hosting2 Billing' THEN '".$homehosting2Billing."'
			   WHEN 'home hosting2 Apps' THEN '".$homehosting2Apps."'
			   WHEN 'home hosting2 Service' THEN '".$homehosting2Service."'
			   WHEN 'homehosting2buttonname' THEN '".$homehosting2buttonname."'
			   WHEN 'homeHostingPlanVPSDataUrl' THEN '".$homeHostingPlanVPSDataUrl."'
			   
			   WHEN 'home Hosting Plans3 Name' THEN '".$homeHostingPlans3Name."'
			   WHEN 'home Hosting Plans3 Price' THEN '".$homeHostingPlans3Price."'
			   WHEN 'home hosting3 processor' THEN '".$homehosting3processor."'
			   WHEN 'home hosting3 RAM' THEN '".$homehosting3RAM."'
			   WHEN 'home hosting3 HDD' THEN '".$homehosting3HDD."'
			   WHEN 'home hosting3 OS' THEN '".$homehosting3OS."'
			   WHEN 'home hosting3 LAN' THEN '".$homehosting3LAN."'
			   WHEN 'home hosting3 Application' THEN '".$homehosting3Application."' 
			   WHEN 'home hosting3 Concurrent Calls' THEN '".$homehosting3ConcurrentCalls."'
			   WHEN 'home hosting3 Billing' THEN '".$homehosting3Billing."'
			   WHEN 'home hosting3 Apps' THEN '".$homehosting3Apps."'
			   WHEN 'home hosting3 Service' THEN '".$homehosting3Service."'
			   WHEN 'homehosting3buttonname' THEN '".$homehosting3buttonname."'
			   WHEN 'homeHostingPlanResellerDataUrl' THEN '".$homeHostingPlanResellerDataUrl."'
			   
			   WHEN 'home Hosting Plans4 Name' THEN '".$homeHostingPlans4Name."'
			   WHEN 'home Hosting Plans4 Price' THEN '".$homeHostingPlans4Price."'
			   WHEN 'home hosting4 processor' THEN '".$homehosting4processor."'
			   WHEN 'home hosting4 RAM' THEN '".$homehosting4RAM."'
			   WHEN 'home hosting4 HDD' THEN '".$homehosting4HDD."'
			   WHEN 'home hosting4 OS' THEN '".$homehosting4OS."'
			   WHEN 'home hosting4 LAN' THEN '".$homehosting4LAN."'
			   WHEN 'home hosting4 Application' THEN '".$homehosting4Application."' 
			   WHEN 'home hosting4 Concurrent Calls' THEN '".$homehosting4ConcurrentCalls."'
			   WHEN 'home hosting4 Billing' THEN '".$homehosting4Billing."'
			   WHEN 'home hosting4 Apps' THEN '".$homehosting4Apps."'
			   WHEN 'home hosting4 Service' THEN '".$homehosting4Service."'
			   WHEN 'homehosting4buttonname' THEN '".$homehosting4buttonname."'
			   WHEN 'homeHostingPlanDedicatedDataUrl' THEN '".$homeHostingPlanDedicatedDataUrl."'
			   
               ELSE value
               END
 			WHERE name IN('home Hosting Plans', 'home Hosting Plans body', 'home Hosting Plans1 Name', 'home Hosting Plans1 Price', 'home hosting1 processor','home hosting1 RAM', 'home hosting1 HDD', 'home hosting1 OS', 'home hosting1 LAN', 'home hosting1 Application', 'home hosting1 Concurrent Calls', 'home hosting1 Billing', 'home hosting1 Apps', 'home hosting1 Service', 'homehosting1buttonname', 'homeHostingPlanSharedDataUrl', 'home Hosting Plans2 Name', 'home Hosting Plans2 Price', 'home hosting2 processor','home hosting2 RAM', 'home hosting2 HDD', 'home hosting2 OS', 'home hosting2 LAN', 'home hosting2 Application', 'home hosting2 Concurrent Calls', 'home hosting2 Billing', 'home hosting2 Apps', 'home hosting2 Service', 'homehosting2buttonname', 'homeHostingPlanVPSDataUrl', 'home Hosting Plans3 Name', 'home Hosting Plans3 Price', 'home hosting3 processor','home hosting3 RAM', 'home hosting3 HDD', 'home hosting3 OS', 'home hosting3 LAN', 'home hosting3 Application', 'home hosting3 Concurrent Calls', 'home hosting3 Billing', 'home hosting3 Apps', 'home hosting3 Service', 'homehosting3buttonname', 'homeHostingPlanResellerDataUrl', 'home Hosting Plans4 Name', 'home Hosting Plans4 Price', 'home hosting4 processor','home hosting4 RAM', 'home hosting4 HDD', 'home hosting4 OS', 'home hosting4 LAN', 'home hosting4 Application', 'home hosting4 Concurrent Calls', 'home hosting4 Billing', 'home hosting4 Apps', 'home hosting4 Service', 'homehosting4buttonname', 'homeHostingPlanDedicatedDataUrl')");
			//echo $result;exit;
		redirect("admincontroller/easy_recharge_hosting_plan?sk=Updated");	
		
	}
	////////////////////////////////////////////////////////////////////////////////////////
	
}//close controller
