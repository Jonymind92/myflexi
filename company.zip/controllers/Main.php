<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
		$this->output->set_header("Cache-Control: post-check=0, pre-check=0", false);
		$this->output->set_header("Pragma: no-cache");
		date_default_timezone_set("Asia/Dhaka");
		
	}
	public function index()
	{
		$data = array();
		$data['menu'] = 'home';
		$data['content'] = $this->load->view('home',$data,true);
		$this->load->view('master',$data);
	}
	public function aboutus()
	{
		$data = array();
		$data['menu'] = 'aboutus';
		$data['content'] = $this->load->view('aboutus',$data,true);
		$this->load->view('master',$data);
	}
	
	//////// Product 1 ////////////
	public function voip_server()
	{
		$data = array();
		$data['menu'] = 'products1';
		$data['content'] = $this->load->view('products',$data,true);
		$this->load->view('master',$data);
	}
	//////// Product 2 ////////////
	public function easy_billing()
	{
		$data = array();
		$data['menu'] = 'products2';
		$data['content'] = $this->load->view('products2',$data,true);
		$this->load->view('master',$data);
	}
	//////// Product 3 ////////////
	public function easy_recharge()
	{
		$data = array();
		$data['menu'] = 'products3';
		$data['content'] = $this->load->view('products3',$data,true);
		$this->load->view('master',$data);
	}
	
	
	public function contact_page()
	{
		$data = array();
		$data['menu'] = 'contact';
		$data['content'] = $this->load->view('contact_page',$data,true);
		$this->load->view('master',$data);
	}
	public function service_page()
	{
		$data = array();
		$data['menu'] = 'service';
		$data['content'] = $this->load->view('service_page',$data,true);
		$this->load->view('master',$data);
	}
	public function contactmail()
	{
		$name = trim($this->input->post('name'));
		$email = trim($this->input->post('email'));
		$subject = trim($this->input->post('subject'));
		$message = trim($this->input->post('message'));
		
		$err=0;
		$msg = "";
		if(empty($name)){$msg .=++$err.". Name requiered<br>";}
		if(empty($email)){$msg .=++$err.". Email requiered<br>";}
		else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){$msg .=++$err.". Email invalid<br>";}
		if(empty($subject)){$msg .=++$err.". Subject requiered<br>";}
		
		$to =  $this->db->query("select value from t_settings where name='servermail'")->row()->value;  
		
		// To send HTML mail, the Content-type header must be set
		$headers[] = 'Content-type: text/html; charset=iso-8859-1';
		
		$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
		$headers[] = 'From: <'.$email.'>'.$name;
		
		if($err==0)
		{
			mail($to, $subject, $message, implode("\r\n", $headers));
			redirect('main/contact_page?sk=Mail Sent');
		}
		else
		{
			redirect('main/contact_page?esk='.$msg);
		}
	}
	public function contactmail2()
	{
		$name = trim($this->input->post('name'));
		$email = trim($this->input->post('email'));
		$subject = trim($this->input->post('subject'));
		$message = trim($this->input->post('message'));
		
		$err=0;
		$msg = "";
		if(empty($name)){$msg .=++$err.". Name requiered<br>";}
		if(empty($email)){$msg .=++$err.". Email requiered<br>";}
		else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){$msg .=++$err.". Email invalid<br>";}
		if(empty($subject)){$msg .=++$err.". Subject requiered<br>";}
		if(empty($message)){$msg .=++$err.". Message requiered<br>";}
		$to =  $this->db->query("select value from t_settings where name='servermail'")->row()->value;  
		
		// To send HTML mail, the Content-type header must be set
		$headers[] = 'Content-type: text/html; charset=iso-8859-1';
		
		$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
		$headers[] = 'From: <'.$email.'>'.$name;
		
		if($err==0)
		{
			mail($to, $subject, $message, implode("\r\n", $headers));
			redirect('main/index?sk=Mail Sent');
		}
		else
		{
			redirect('main/index?esk='.$msg);
		}
	}
	
	
	
	
}
