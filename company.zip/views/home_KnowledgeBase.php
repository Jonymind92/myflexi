<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$knowledge = $this->db->query("select * from t_homedata where subject='Knowledge Base'")->result();
	$header='';
	$des='';
	foreach($knowledge as $k)
	{
		if($k->name=='home Knowledge Base Header')
		{
			$header=$k->value;
		}
		if($k->name=='home Knowledge Base body')
		{
			$des=$k->value;
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
        <form action="<?php echo 'admincontroller/update_homeKnowledge'?>" method="post">
          <table style="width:100%;">
            <tr>
              <td>KnowledgeBase Header
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="header" value="<?php if(isset($header)&& !empty($header))echo $header;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
              
            <tr>   
              <td>KnowledgeBase Describtion
              <br> 
                <textarea  name="des" value="<?php if(isset($des)&& !empty($des))echo $des;?> " style="width:100%;min-height:150px;height:auto;font-size:16px;"><?php if(isset($des)&& !empty($des))echo $des;?></textarea></td>
            </tr>
            
            
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
