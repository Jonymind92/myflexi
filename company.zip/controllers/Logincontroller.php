<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logincontroller extends CI_Controller {

	public function index()
	{
		$data = array();
		$data['content'] = $this->load->view('index','',true);
		$this->load->view('master',$data);
	}
	
	
	
	
	
	
	
}
