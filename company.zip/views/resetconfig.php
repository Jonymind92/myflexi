<!DOCTYPE html>
<html>
  <head>
   <base href="<?php echo base_url();?>">
	<title> <?php echo $brand=$this->mm->getSet('brand');?> | Reset Configuration</title>
	<meta name="author" content="DhakaSoft Network">
	<meta name="copyright" content="Copyright &copy; 2009 dhaka-soft.net" />
	<meta name="rating" content="general" />
	<meta name="distribution" content="global" />
	<meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.css" rel="stylesheet">
  </head>
  <body>
	<div id="wrap">
	<!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="main"><?php echo $brand=$this->mm->getSet('brand');?> Reset</a>
        </div>
      </div>
    </div>
	<div class="clrGap">&nbsp;</div>
	<div class="container mybody">
		<div class="install">
		<?php echo form_open("_reSet/settings",'role="form" class="inform" style="width:300px;background:#fff;padding:0px;"');?>
			  <h4 style="color:blue">Basic Settings:</h4>
			  <div class="form-group <?php if (form_error('brandname')) echo "has-error";?>">
				<label class="control-label" for="brandname">Brand Name</label>
				<input type="text" name="brandname" id="brandname" class="form-control input-sm" value="<?php echo $this->mm->getSet('brand');?>">
			  </div>		
			 <div class="form-group <?php if (form_error('tagline')) echo "has-error";?>">
				<label class="control-label" for="tagline">Tag Line</label>
				<input type="text" name="tagline" id="tagline" class="form-control input-sm" value="<?php echo $this->mm->getSet('toptitle');?>">
			  </div>		
			  	  <div class="form-group <?php if (form_error('site_logo_url')) echo "has-error";?>">
				<label class="control-label" for="site_logo_url">Logo URL</label>
				<input type="text" name="site_logo_url" id="site_logo_url" class="form-control input-sm" value="<?php echo $this->mm->getSet('logourl');?>">
			  </div>

<?php $query=$this->db->query("Select * from t_admin  WHERE id='1'");
	if ($query->num_rows()==1){
	$sAdmin=$query->row();
	} ?>
			  
			   <h4 style="margin-top:30px;color:blue">Admin Settings:</h4>
			    <div class="form-group <?php if (form_error('username')) echo "has-error";?>">
				<label class="control-label" for="username">Username</label>
				<input type="text" name="username" id="username" class="form-control input-sm" value="<?php echo $sAdmin->username ?>">
			  </div>
			  <div class="form-group <?php if (form_error('password')) echo "has-error";?>">
				<label class="control-label" for="password">Password</label>
				<input type="text" name="password" id="password" class="form-control input-sm" value="<?php echo $newpass?>">
			  </div>
			 
			  
			  
			  <div class="form-group <?php if (form_error('email')) echo "has-error";?>">
				<label class="control-label" for="email">Email <span class="" style="color:red;font-weight:normal;font-size:11px">(required)</span></label>
				<input type="text" name="email" id="email" class="form-control input-sm" value="<?php echo $this->mm->getSet('servermail') ?>">
			  </div>
			 <div class="form-group <?php if (form_error('inputpin')) echo "has-error";?>">
			 <label for="inputpin">Verification Key</label>
			<input type="password" class="form-control input-sm" id="inputpin" name="inputpin" placeholder="Enter a verification key to continue" style="width:300px;"><br/>
			 </div>
			  <button type="submit" class="btn btn-primary btn-sm" ><span class="glyphicon glyphicon-ok"></span> &nbsp;Submit</button>
			  
			<?php echo form_close();?>
		</div>
	<div id="footer" style="margin-top:30px;">
	<p>Powered By <?php echo $brand=$this->mm->getSet('brand');?> Networks</p>
	</div>
	</div>

	</div><!--/end Wrap-->

  </body>
</html>