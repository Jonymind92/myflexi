
<?php

	$settingdata = $this->db->query("select * from t_settings")->result();
	$homebannertitle ='';
	$homeyourdomain='';
	$homebannersubtitle='';
	$homeyourdomain='';
	$homesearchtext='';
	$homesiteuniq='';
	$homesiteuniqsubtext='';
	$homePARALLAXEFFECT='';
	$homeFOCUSHEADING='';
	$homeMOVABLESECTIONS='';
	$homeWOOCOMMERCE='';
	$homeCUSTOMCONTENTBLOCKS='';
	$homePARALLAXEFFECTbody='';
	$homeMOVABLESECTIONSbody='';
	$homeWOOCOMMERCEbody='';
	$homeCUSTOMCONTENTBLOCKSbody='';
	$homeHostingPlans='';
	$homeHostingPlansbody='';
	$homeHostingPlans1Name='';
	$homeHostingPlans1Price=0;
	$homeHostingPlans2Name='';
	$homeHostingPlans2Price=0;
	$homeHostingPlans3Name='';
	$homeHostingPlans3Price=0;
	$homeHostingPlans4Name='';
	$homeHostingPlans4Price=0;
	$homeKnowledgeBaseHeader='';
	$homeKnowledgeBasebody='';
	$domainname1='';
	$domainname2='';
	$domainname3='';
	$domainname4='';
	
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home banner title'){$homebannertitle = $set->value;}
			if($set->name == 'home banner sub title'){$homebannersubtitle = $set->value;}
			if($set->name == 'home yourdomain'){$homeyourdomain = $set->value;}
			if($set->name == 'home searchtext'){$homesearchtext = $set->value;}
			if($set->name == 'home siteuniq'){$homesiteuniq = $set->value;}
			if($set->name == 'home siteuniq subtext'){$homesiteuniqsubtext = $set->value;}
			if($set->name == 'home PARALLAX EFFECT'){$homePARALLAXEFFECT = $set->value;}
			if($set->name == 'home FOCUS HEADING'){$homeFOCUSHEADING = $set->value;}
			if($set->name == 'home MOVABLE SECTIONS'){$homeMOVABLESECTIONS = $set->value;}
			if($set->name == 'home WOOCOMMERCE'){$homeWOOCOMMERCE = $set->value;}
			if($set->name == 'home CUSTOM CONTENT BLOCKS'){$homeCUSTOMCONTENTBLOCKS = $set->value;}
			if($set->name == 'home PARALLAX EFFECT body'){$homePARALLAXEFFECTbody = $set->value;}
			if($set->name == 'home MOVABLE SECTIONS body'){$homeMOVABLESECTIONSbody = $set->value;}
			if($set->name == 'home WOOCOMMERCE body'){$homeWOOCOMMERCEbody = $set->value;}
			if($set->name == 'home CUSTOM CONTENT BLOCKS body'){$homeCUSTOMCONTENTBLOCKSbody = $set->value;}
			if($set->name == 'home Hosting Plans'){$homeHostingPlans = $set->value;}
			if($set->name == 'home Hosting Plans body'){$homeHostingPlansbody = $set->value;}
			if($set->name == 'home Hosting Plans1 Name'){$homeHostingPlans1Name = $set->value;}
			if($set->name == 'home Hosting Plans1 Price'){$homeHostingPlans1Price = $set->value;}
			if($set->name == 'home Hosting Plans2 Name'){$homeHostingPlans2Name = $set->value;}
			if($set->name == 'home Hosting Plans2 Price'){$homeHostingPlans2Price = $set->value;}
			if($set->name == 'home Hosting Plans3 Name'){$homeHostingPlans3Name = $set->value;}
			if($set->name == 'home Hosting Plans3 Price'){$homeHostingPlans3Price = $set->value;}
			if($set->name == 'home Hosting Plans4 Name'){$homeHostingPlans4Name = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$homeHostingPlans4Price = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$homeHostingPlans4Price = $set->value;}
			if($set->name == 'home Knowledge Base Header'){$homeKnowledgeBaseHeader = $set->value;}
			if($set->name == 'home Knowledge Base body'){$homeKnowledgeBasebody = $set->value;}
			if($set->id == 5){$domainname1= $set->name;}
			if($set->id == 6){$domainname2= $set->name;}
			if($set->id == 7){$domainname3= $set->name;}
			if($set->id == 8){$domainname4= $set->name;}
			
			//if($set->name == 'home yourdomain'){ $homeyourdomain = $set->value;}
			
		}
	}
	
?>



<div class="container">




<!------- Slide show start ------------------------------------------------------------------------------>
    <div class="vc_row wpb_row vc_row-fluid " style=" ">
      <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
		<div class="wpb_wrapper">
            <div class="wpb_raw_code wpb_content_element wpb_raw_html">
              <div class="wpb_wrapper">
                <div style="position:relative;width:100%;height:auto;margin-top:0px;margin-bottom:0px" class="forcefullwidth_wrapper_tp_banner">
                  <div class="tp-banner-container" style="left: -46.5px; position: absolute; width: 1263px; overflow: visible;">
                    <div class="tp-banner4 revslider-initialised tp-simpleresponsive" style="max-height: 650px; background-color: transparent; background-image: none; height: 650px;" id="revslider-300">
                      
                      
                      <ul style="display: block; overflow: hidden; width: 100%; height: 100%; max-height: none;">

                        
                        <li data-transition="fade" data-slotamount="1" data-masterspeed="1500" data-thumb="" data-delay="13000" data-saveperformance="off" data-title="Slide 2" style="width: 100%; height: 100%; overflow: hidden; z-index: 20; visibility: inherit; opacity: 1;" class="active-revslide current-sr-slide-visible">
                          <div class="slotholder" style="width:100%;height:100%;" data-duration="14000" data-zoomstart="undefined" data-zoomend="undefined" data-rotationstart="undefined" data-rotationend="undefined" data-ease="Linear.easeNone" data-bgpositionend="right center" data-bgposition="left center" data-kenburns="on" data-easeme="Linear.easeNone" data-bgfit="100" data-bgfitend="130" data-owidth="undefined" data-oheight="undefined">
                            <div class="tp-bgimg defaultimg" data-lazyload="undefined" data-bgfit="100" data-bgposition="left center" data-bgrepeat="no-repeat" data-lazydone="undefined" src="http://fluentthemes.com/wp/zionhost/wp-content/themes/zionhost/images/sliders/slide_bg8.jpg" data-src="http://fluentthemes.com/wp/zionhost/wp-content/themes/zionhost/images/sliders/slide_bg8.jpg" style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://fluentthemes.com/wp/zionhost/wp-content/themes/zionhost/images/sliders/slide_bg8.jpg&quot;); background-position: 0% 0%; width: 100%; height: 100%; opacity: 1; visibility: inherit; background-size: 191.157% 125.761%;"></div>
                            <div class="kenburnimg" style="position:absolute;z-index:1;width:100%;height:100%;top:0px;left:0px;">
                            <img src="img/slide_bg8.jpg" style="-moz-user-select: none; position: absolute; width: 152%; height: 100%; left: 0px; top: 0px; visibility: inherit; opacity: 1; transform: matrix(1.24482, 0, 0, 1.24482, 0, 0); transform-origin: 0% 0% 0px;"></div>
                          </div>
                           <form action="<?php echo 'mainadmin/update_homebanner'?>" method="post">
                          <div class="tp-caption text5 randomrotate start splitted" data-x="center" data-y="220" data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" data-speed="500" data-start="1500" data-easing="Power3.easeInOut" data-splitin="chars" data-splitout="chars" data-elementdelay="0.08" data-endelementdelay="0.08" data-endspeed="300" style="z-index: 7; white-space: nowrap; min-height: 0px; min-width: 0px; line-height: 23px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-size: 80px; left: 220.5px; top: 220px; visibility: visible; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                          
                         
                            <div style="display: block; text-align: left; position: relative;" class="tp-splitted">
                              <div style="position:relative;display:inline-block;" class="tp-splitted">
                                <div style="position: relative; display: inline-block; visibility: visible; opacity: 1; transform: translate3d(0px, 0px, 0px);letter-spacing:7px;" class="tp-splitted" >
                                
								<textarea  name="homebannertitle" value="<?php if(isset($homebannertitle)&& !empty($homebannertitle))echo $homebannertitle;?> " style="width:100%;max-height:50px;font-size:46px;"><?php if(isset($homebannertitle)&& !empty($homebannertitle))echo $homebannertitle;?></textarea>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="tp-caption smalltext_two sft start" data-x="center" data-hoffset="0" data-voffset="-10" data-y="295" data-speed="800" data-start="1800" data-easing="Power4.easeOut" data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6; min-height: 0px; min-width: 0px; line-height: 35px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-size: 18px; left: 352.5px; top: 295px; visibility: visible; opacity: 1; transform: translate3d(0px, 0px, 0px);">
                          <textarea name="homebannersubtitle" value="<?php if(isset($homebannersubtitle)&& !empty($homebannersubtitle))echo $homebannersubtitle;?>" style="width:100%;max-height:35px;font-size:26px;" ><?php if(isset($homebannersubtitle)&& !empty($homebannersubtitle))echo $homebannersubtitle;?></textarea>
                          <br />
                         <input type="submit" value="Update" style="float:right;margin-right:100px;background:#008040;color:#FFF"/>
                          </div>
                          	
                          </form>
                          <!--<div class="tp-caption btns sfb start" data-x="center" data-hoffset="0" data-voffset="-10" data-y="395" data-speed="800" data-start="2000" data-easing="Power4.easeOut" data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" style="z-index: 6; min-height: 0px; min-width: 0px; line-height: 23px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-size: 14px; left: 540.5px; top: 395px; visibility: visible; opacity: 1; transform: translate3d(0px, 0px, 0px);"><a href="" class="btn whitebox">Purchase Now</a></div>-->
                        </li>
                        

                      </ul>
                      
                      
                      <div class="tp-bannertimer" style="width: 95.0462%; visibility: hidden; transform: translate3d(0px, 0px, 0px);"></div>
                      <div class="tp-loader spinner0" style="display: none;">
                        <div class="dot1"></div>
                        <div class="dot2"></div>
                        <div class="bounce1"></div>
                        <div class="bounce2"></div>
                        <div class="bounce3"></div>
                      </div>
                    </div>
                    <div style="position: absolute; top: 325px; margin-top: -30px; left: 20px; width: 60px;" class="tp-leftarrow tparrows default preview2 hashoveralready hidearrows">
                      <div class="tp-arr-allwrapper">
                        <div class="tp-arr-iwrapper">
                          <div class="tp-arr-imgholder" style="visibility: inherit; opacity: 1; background-image: url(&quot;&quot;);"></div>
                          <div class="tp-arr-imgholder2"></div>
                          <div class="tp-arr-titleholder" style="">Slide 1</div>
                          <div class="tp-arr-subtitleholder"></div>
                        </div>
                      </div>
                    </div>
                    <div style="position: absolute; top: 325px; margin-top: -30px; right: 20px; width: 60px;" class="tp-rightarrow tparrows default preview2 hashoveralready hidearrows">
                      <div class="tp-arr-allwrapper">
                        <div class="tp-arr-iwrapper">
                          <div class="tp-arr-imgholder" style="visibility: inherit; opacity: 1; background-image: url(&quot;&quot;);"></div>
                          <div class="tp-arr-imgholder2"></div>
                          <div class="tp-arr-titleholder" style="">Slide 3</div>
                          <div class="tp-arr-subtitleholder"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tp-fullwidth-forcer" style="width:100%;height:650px"></div>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
<!------- Slide show End ------------------------------------------------------------------------------>    
    
    
    
    
<!------- Domain Search Start ------------------------------------------------------------------------->     
    <div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding" style="position: relative; left: -31.5px; box-sizing: border-box; width: 1263px;">
      <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section1 six" style=" background:  " data-anim-type="fade-in" data-anim-delay="100">
              <div class="container domain_search_home">
                <div class="title1">
                  <h2><span class="line"></span><span class="text">Search Here</span><br>
                  
                    <textarea name="homebannersubtitle" value="<?php if(isset($homeyourdomain)&& !empty($homeyourdomain))echo $homeyourdomain;?> " style="max-height:35px;font-size:26px;" ><?php if(isset($homeyourdomain)&& !empty($homeyourdomain))echo $homeyourdomain;?></textarea><em> 
					<textarea name="homebannersubtitle" value="<?php if(isset($homesearchtext)&& !empty($homesearchtext))echo $homesearchtext;?>" style="width:100%;max-height:35px;font-size:16px;" ><?php if(isset($homesearchtext)&& !empty($homesearchtext))echo $homesearchtext;?></textarea></em></h2>
                </div>
                
                <div class="one_third last">
                  <table>
                  	<tr>
                    	<td style="color:#000;"><?php if(isset($domainname1)&& !empty($domainname1))echo $domainname1;?>&nbsp;<input type="text" name="comprice" /></td>
                    	<td style="color:#000;"><?php if(isset($domainname2)&& !empty($domainname2))echo $domainname2;?>&nbsp;<input type="text" name="netprice" /></td>
                    	<td style="color:#000;"><?php if(isset($domainname3)&& !empty($domainname3))echo $domainname3;?>&nbsp;<input type="text" name="bizprice" /></td>
                    	<td style="color:#000;"><?php if(isset($domainname4)&& !empty($domainname4))echo $domainname4;?>&nbsp;<input type="text" name="inprice" /></td>
                        <td>&nbsp;&nbsp;&nbsp;<input type="submit" value="Update" style="background:#008040;color:#FFF"/></td>
                    </tr>
                  </table>
                </div>
              </div>
              <div class="crossed_shape two"></div>
            </section>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="vc_row-full-width"></div>
    
<!------- Domain Search End ----------------------------------------------------------------->    
    
    
    
    
    
    
    
    
    
    
 <!--- Service Section ------------------------------------------------------------------------>   
 
 
    <div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding" style="position: relative; left: -31.5px; box-sizing: border-box; width: 1263px;">
      <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section2 one">
              <div class="container">
                <div class="section-header"><h2 class="dark-text">
                	<?php if(isset($homesiteuniq)&& !empty($homesiteuniq))echo $homesiteuniq;?>
                </h2>
                <h6>
                	<?php if(isset($homesiteuniqsubtext)&& !empty($homesiteuniqsubtext))echo $homesiteuniqsubtext;?>
					
                </h6></div>
                
                 <!-------section-header -------------->
                
                
                
                <div class="row">
           




<span id="ctup-ads-widget-3">
		<div class="col-lg-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon gc">
								
					<a target="_self" href="#"><i class="pixeden our-focus-widget-image" style="background:url(https://demot-vertigostudio.netdna-ssl.com/zerif-pro/wp-content/uploads/sites/53/2014/07/Unknown-9.png) no-repeat center;"></i></a>

			</div>
                                            
                                            
<center>                                                                        
		<h5>
        	<?php if(isset($homePARALLAXEFFECT)&& !empty($homePARALLAXEFFECT))echo $homePARALLAXEFFECT;?>
        </h5> 
        <?php if(isset($homeFOCUSHEADING)&& !empty($homeFOCUSHEADING))echo $homeFOCUSHEADING;?>
        
        <hr class="gcl"></hr>
			<p>
				<?php if(isset($homePARALLAXEFFECTbody)&& !empty($homePARALLAXEFFECTbody))echo $homePARALLAXEFFECTbody;?>
			</p>
</center>

		</div>
</span>



<!----------------------------------------->



<span id="ctup-ads-widget-4">
		<div class="col-lg-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon bc">
								
					<a target="_self" href="#"><i class="pixeden our-focus-widget-image" style="background:url(https://demot-vertigostudio.netdna-ssl.com/zerif-pro/wp-content/uploads/sites/53/2015/06/Unknown-8.png) no-repeat center;"></i>  </a>

											</div>
                                            
                                            
<center>                                             
			<h5 class="red-border-bottom"><?php if(isset($homeMOVABLESECTIONS)&& !empty($homeMOVABLESECTIONS))echo $homeMOVABLESECTIONS;?><!--MOVABLE SECTIONS--></h5>  
            <?php if(isset($homeFOCUSHEADING)&& !empty($homeFOCUSHEADING))echo $homeFOCUSHEADING;?> 
			<hr class="bcl"></hr>
            <p>
            	<?php if(isset($homeMOVABLESECTIONSbody)&& !empty($homeMOVABLESECTIONSbody))echo $homeMOVABLESECTIONSbody;?>
			</p>
</center>            
		</div>
</span>


<!----------------------------->

<span id="ctup-ads-widget-5">
		<div class="col-lg-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon yc">
								
					<a target="_self" href="#"><i class="pixeden our-focus-widget-image" style="background:url(https://demot-vertigostudio.netdna-ssl.com/zerif-pro/wp-content/uploads/sites/53/2015/04/woo.png) no-repeat center;"></i>  </a>

			</div>
<center> 
			<h5 class="red-border-bottom"><?php if(isset($homeWOOCOMMERCE)&& !empty($homeWOOCOMMERCE))echo $homeWOOCOMMERCE;?><!---WOOCOMMERCE--></h5>  
            <?php if(isset($homeFOCUSHEADING)&& !empty($homeFOCUSHEADING))echo $homeFOCUSHEADING;?> 
			<hr class="ycl"></hr>
            <p>
            	<?php if(isset($homeWOOCOMMERCEbody)&& !empty($homeWOOCOMMERCEbody))echo $homeWOOCOMMERCEbody;?>
			</p>
</center>
		</div>
</span>


<!----------------------------->

<span id="ctup-ads-widget-6">
		<div class="col-lg-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon rc">
								
					<a target="_self" href="#"><i class="pixeden our-focus-widget-image" style="background:url(https://demot-vertigostudio.netdna-ssl.com/zerif-pro/wp-content/uploads/sites/53/2014/07/Unknown-10.png) no-repeat center;"></i>  </a>

			</div>
<center>
			<h5 class="red-border-bottom"><?php if(isset($homeCUSTOMCONTENTBLOCKS)&& !empty($homeCUSTOMCONTENTBLOCKS))echo $homeCUSTOMCONTENTBLOCKS;?><!----CUSTOM CONTENT BLOCKS---></h5>  
             <?php if(isset($homeFOCUSHEADING)&& !empty($homeFOCUSHEADING))echo $homeFOCUSHEADING;?> 
			<hr class="rcl"></hr>
            <p>
            	<?php if(isset($homeCUSTOMCONTENTBLOCKSbody)&& !empty($homeCUSTOMCONTENTBLOCKSbody))echo $homeCUSTOMCONTENTBLOCKSbody;?>
			</p>
</center>
		</div>
</span>

</div>



      </div>
     </section>

            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
    <div class="vc_row-full-width"></div>
    <div class="vc_row wpb_row vc_row-fluid " style=" ">
      <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper" style="margin-top:80px;">
            <div class="title">
              <h2 style="color: ;"><span style="background: ;" class="line blueline"></span><span style="color: ;" class="text">Our Best</span><br>
              
                <?php if(isset($homeHostingPlans)&& !empty($homeHostingPlans))echo $homeHostingPlans;?>
                
                <em style="color: ;">
                <?php if(isset($homeHostingPlansbody)&& !empty($homeHostingPlansbody))echo $homeHostingPlansbody;?>
                </em></h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="vc_row wpb_row vc_row-fluid " style=" padding-bottom: 100px; ">
      <div class="wpb_column vc_column_container vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans1Price)&& !empty($homeHostingPlans1Price))echo $homeHostingPlans1Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans1Name)&& !empty($homeHostingPlans1Name))echo $homeHostingPlans1Name;?></h2>
                </div>
                <ul class="plan-list">
                
                	<?php
                    	if(isset($homeHostingPlanSharedData)&& !empty($homeHostingPlanSharedData))
						{
							echo $homeHostingPlanSharedData;
						}
						else
						{
					?>	
                      <li class="light">10 GB Disk Space<br>
                      </li>
                      <li class="dark">256 MB Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">5 Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
                  <?php
						}
				  ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanSharedDataUrl)) echo $homeHostingPlanSharedDataUrl;?>" class="btn darkbox ">Get Started</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col active">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans2Price)&& !empty($homeHostingPlans2Price))echo $homeHostingPlans2Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans2Name)&& !empty($homeHostingPlans2Name))echo $homeHostingPlans2Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($homeHostingPlanVPSData)&& !empty($homeHostingPlanVPSData))
						{
							echo $homeHostingPlanVPSData;
						}
						else
						{
					?>	
                      <li class="light">15 GB Disk Space<br>
                      </li>
                      <li class="dark">512 MB Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">10 Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
				  <?php
						}
                  ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanVPSDataUrl)) echo $homeHostingPlanVPSDataUrl;?>" class="btn darkbox active">Get Started</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans3Price)&& !empty($homeHostingPlans3Price))echo $homeHostingPlans3Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans3Name)&& !empty($homeHostingPlans3Name))echo $homeHostingPlans3Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($homeHostingPlanResellerData)&& !empty($homeHostingPlanResellerData))
						{
							echo $homeHostingPlanResellerData;
						}
						else
						{
					?>	
                      <li class="light">20 GB Disk Space<br>
                      </li>
                      <li class="dark">1 GB Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">15 Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
                     <?php
						}
					 ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanResellerDataUrl)) echo $homeHostingPlanResellerDataUrl;?>" class="btn darkbox ">Get Started</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans4Price)&& !empty($homeHostingPlans4Price))echo $homeHostingPlans4Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans4Name)&& !empty($homeHostingPlans4Name))echo $homeHostingPlans4Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($homeHostingPlanDedicatedData)&& !empty($homeHostingPlanDedicatedData))
						{
							echo $homeHostingPlanDedicatedData;
						}
						else
						{
					?>
                      <li class="light">Unlimited Disk Space<br>
                      </li>
                      <li class="dark">Unlimited Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">Unlimited Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
                     <?php
						}
					 ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanDedicatedDataUrl))  echo $homeHostingPlanDedicatedDataUrl;?>" class="btn darkbox ">Get Started</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    
    
    
    
    
    

  <!----------------- Testimonial and Akno-------------------------------------------------------------------------->  
  
  
  
  
     <div class="vc_row-full-width"></div>
    <div class="vc_row wpb_row vc_row-fluid " style="height:500px;overflow:hidden ">
      <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section9">
              <div class="container">
              	
                <!------------- Testimonial slide start--------------------->
                	<div class="vc_col-sm-6" style="min-height:300px;float:left;">
 					
                	<h2 style="color:#252525;font-size:30px;">Testimonial</h2>
                    
                    <!------------------------------------------->
                    
                    <script src="http://code.jquery.com/jquery-latest.js"></script>

					<script language="javascript">'use strict';$(function() {var width = 700; var animationSpeed = 1250; var pause = 5500; var currentSlide = 1;var $slider = $('#slider'); var $slideContainer = $('.slides', $slider); var $slides = $('.slide', $slider); var interval; function startSlider() { interval = setInterval(function() { $slideContainer.animate({'margin-left': '-='+width}, animationSpeed, function() {if (++currentSlide === $slides.length) {currentSlide = 1; $slideContainer.css('margin-left', 0); }});}, pause);} function pauseSlider() {clearInterval(interval);}$slideContainer.on('mouseenter', pauseSlider).on('mouseleave', startSlider);startSlider();});</script>
                    
                    
                    <style type="text/css">#slider {width: 100%; height: 400px; border: 3px solid #FFFFFF; border-radius: 0px; overflow: hidden; position: relative;  cursor: hand; cursor: pointer}#slider .slides {width: 2800px; height: 400px;  display: block; margin: 0; padding: 0;}#slider .slide {width: 700px; height: 400px; float: left; list-style-type: none;}.DOT161208 {position: absolute; max-width: 700px; margin: 0px;}.c39285  {position: absolute; bottom: 0px; width:100%;  padding: 12px; background-color: rgba(0, 0, 0, 0.7); color: #FFFFF; font-size:24pt; font-family:Tahoma; text-align:center; line-height:48px; z-index:33; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box;}
                    .info-testimonial img{float:left;margin:10px 0 0 20px;}
					info-testimonial span{float:left;}
                    </style>
                    
                    <div id="slider">
                    <ul class="slides">
                    	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							foreach($settingdata as $tm)
							{
								if($tm->subject == 'testimonial')
								{
					?>
                    
                    <li class="slide slide1">
                     <div style="width: 100%;opacity: 1;display: block;position: relative;">
                                    <div id="testdiv1">
                                        <div class="owl-item" style="width: 555px;">
                                            <div class="ts-item-testimonial-1">
                                              <div class="client-quote"> <i class="fa fa-quote-left"></i>
                                                <blockquote>
                                                  <p>
                                                  <?php if(isset($tm->value))  echo $tm->value;?>
                                                  </p>
                                                </blockquote>
                                              </div>
                                              <div class="info-testimonial">
                                                <div class="client-avatar">
                                                  <figure><img alt="" src="http://alaska2.themestudio.net/wp-content/uploads/2016/07/client-avatar-95x95.png"></figure>
                                                </div>
                                                <div class="client-info"> <span class="client-name">Lucia Penelope</span> <span class="client-position">CEO &amp; Founder Geckoos</span> <span class="client-website"><a href="http://themestudio.net">http://themestudio.net</a></span> </div>
                                              </div>
                                            </div>
                                          </div>
                                    </div>
                            </div>
                     </li>  

                    <?php
								}
							}
						}
					?>  


                    </ul>
                    </div>
                    </div>
                   

                    
                    
                    
                    <!---------- Testimonial slide End ---------------------------------->
                    
                    
                    
                    <!----------- Knowledge Base Start ---------------------------------->
                    
                    
                    <div class="vc_col-sm-6" style="min-height:200px;float:right;">
 
                	<h2 style="color:#252525;font-size:30px;">Knowledge Base</h2>
                    
                    
                    <style>
						.ui-widget {font-family: Verdana,Arial,sans-serif;font-size: 1.1em;}
						.ui-helper-reset {margin: 0;padding: 0;border: 0;outline: 0;line-height: 1.3;text-decoration: none;font-size: 100%;list-style: none;}
						.ts-acordion.ui-accordion .ui-accordion-header {background: #f3f3f3;font-size: 14px;font-weight: 300;line-height: 26px;border: none;-webkit-border-radius: 3px;-moz-border-radius: 3px;-ms-border-radius: 3px;-o-border-radius: 3px;border-radius: 3px;margin: 0 0 18px 0;padding: 13px 32px 13px 15px;outline: none;}
						.ui-accordion .ui-accordion-icons {padding-left: 2.2em;}
						.ui-accordion .ui-accordion-header {display: block;cursor: pointer;position: relative;margin: 2px 0 0 0;padding: .5em .5em .5em .7em;min-height: 0;font-size: 100%;}
						.ui-corner-all, .ui-corner-bottom, .ui-corner-right, .ui-corner-br {border-bottom-right-radius: 4px;}
						.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {border: 1px solid #d3d3d3;background: #e6e6e6 url("../images/ui-bg_glass_75_e6e6e6_1x400.png") 50% 50% repeat-x;font-weight: normal;color: #555555;}
					</style>
                    <!--------------------------------------------->
                    
                    <div class="ts-acordion ts-acordion-720 ui-accordion ui-widget ui-helper-reset" role="tablist">
                        <h2 class="ui-accordion-header ui-state-default ui-accordion-icons ui-corner-all" role="tab" id="ui-id-1" aria-controls="ui-id-2" aria-selected="false" aria-expanded="false" tabindex="0"><span class="ui-accordion-header-icon ui-icon ts-header"></span>
                        <?php if(isset($homeKnowledgeBaseHeader))  echo $homeKnowledgeBaseHeader;?>
                        </h2>
                  <div class="acordion-content ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" style="display: block; height: 146px;" id="ui-id-2" aria-labelledby="ui-id-1" role="tabpanel" aria-hidden="true">
                            
                		<div class="wpb_text_column wpb_content_element ">
                    		<div class="wpb_wrapper">
                        <p>
                        <?php if(isset($homeKnowledgeBasebody))  echo $homeKnowledgeBasebody;?>
                        </p>
            
                    		</div>
                		</div>
            		</div>

                    </div>
                    </div>
                <!------ Knowledge Base End ---------------------------->
                
              </div> <!------ Close Container ---------->
             </section>
           </div>
         </div>
       </div>
     </div>
    

                
                
                
                
                
    
    
    <!--==============================================================================-->
    
    <div class="vc_row-full-width"></div>
    <div class="vc_row wpb_row vc_row-fluid " style=" ">
      <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section10">
              <div class="container">
              		<style>
						.imgspace{width:11%;min-height:40px;}
					</style>
              		<center>
                        <img src="img/link/hostingpanel-icon1.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon2.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon3.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon4.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon5.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon6.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon7.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon8.jpg" alt="" class="imgspace">
                    </center>
                
              </div>
            </section>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
    
    
  </div>