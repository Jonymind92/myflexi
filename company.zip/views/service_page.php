

<?php
$servicedata = $this->db->query("select * from t_servicedata")->result();
$bannertitle='';

$serviceworktitle='';
$serviceworkdescribtion='';

$servicework1='';
$bannertitle='';
$bannertitle='';
$bannertitle='';

$servicework1percent='';
$servicework2percent='';
$servicework3percent='';
$servicework4percent='';

$headertitle1='';
$headertitle2='';
$headertitle3='';

$subtitle1='';
$subtitle2='';
$subtitle3='';

$comment1='';
$comment2='';
$comment3='';

$url1='';
$url2='';
$url3='';

//service offer

$sectiontitle='';
$menutitle1='';
$menutitle2='';
$menutitle3='';
$menutitle4='';
$menutitle5='';

$header1='';
$header2='';
$header3='';
$header4='';
$header5='';

$description1='';
$description2='';
$description3='';
$description4='';
$description5='';

$surl1='';
$surl2='';
$surl3='';
$surl4='';
$surl5='';


foreach($servicedata as $s)
{
	if($s->name =="bannertitle"){$bannertitle=$s->value;}
	
	if($s->name =="serviceworktitle"){$serviceworktitle=$s->value;}
	if($s->name =="serviceworkdescribtion"){$serviceworkdescribtion=$s->value;}
	
	if($s->name =="servicework1"){$servicework1=$s->value;}
	if($s->name =="servicework2"){$servicework2=$s->value;}
	if($s->name =="servicework3"){$servicework3=$s->value;}
	if($s->name =="servicework4"){$servicework4=$s->value;}
	
	if($s->name =="servicework1percent"){$servicework1percent=$s->value;}
	if($s->name =="servicework2percent"){$servicework2percent=$s->value;}
	if($s->name =="servicework3percent"){$servicework3percent=$s->value;}
	if($s->name =="servicework4percent"){$servicework4percent=$s->value;}
	
	if($s->name =="headertitle1"){$headertitle1=$s->value;}
	if($s->name =="headertitle2"){$headertitle2=$s->value;}
	if($s->name =="headertitle3"){$headertitle3=$s->value;}
	
	if($s->name =="subtitle1"){$subtitle1=$s->value;}
	if($s->name =="subtitle2"){$subtitle2=$s->value;}
	if($s->name =="subtitle3"){$subtitle3=$s->value;}
	
	if($s->name =="comment1"){$comment1=$s->value;}
	if($s->name =="comment2"){$comment2=$s->value;}
	if($s->name =="comment3"){$comment3=$s->value;}
	
	if($s->name =="url1"){$url1=$s->value;}
	if($s->name =="url2"){$url2=$s->value;}
	if($s->name =="url3"){$url3=$s->value;}
	
	//service offer
	if($s->name =="sectiontitle" && $s->subject =="serviceoffer"){$sectiontitle=$s->value;}
	
	if($s->name =="menutitle1" && $s->subject =="serviceoffer"){$menutitle1=$s->value;}
	if($s->name =="menutitle2" && $s->subject =="serviceoffer"){$menutitle2=$s->value;}
	if($s->name =="menutitle3" && $s->subject =="serviceoffer"){$menutitle3=$s->value;}
	if($s->name =="menutitle4" && $s->subject =="serviceoffer"){$menutitle4=$s->value;}
	if($s->name =="menutitle5" && $s->subject =="serviceoffer"){$menutitle5=$s->value;}
	
	if($s->name =="header1" && $s->subject =="serviceoffer"){$header1=$s->value;}
	if($s->name =="header2" && $s->subject =="serviceoffer"){$header2=$s->value;}
	if($s->name =="header3" && $s->subject =="serviceoffer"){$header3=$s->value;}
	if($s->name =="header4" && $s->subject =="serviceoffer"){$header4=$s->value;}
	if($s->name =="header5" && $s->subject =="serviceoffer"){$header5=$s->value;}
	
	if($s->name =="description1" && $s->subject =="serviceoffer"){$description1=$s->value;}
	if($s->name =="description2" && $s->subject =="serviceoffer"){$description2=$s->value;}
	if($s->name =="description3" && $s->subject =="serviceoffer"){$description3=$s->value;}
	if($s->name =="description4" && $s->subject =="serviceoffer"){$description4=$s->value;}
	if($s->name =="description5" && $s->subject =="serviceoffer"){$description5=$s->value;}
	
	if($s->name =="url1" && $s->subject =="serviceoffer"){$surl1=$s->value;}
	if($s->name =="url2" && $s->subject =="serviceoffer"){$surl2=$s->value;}
	if($s->name =="url3" && $s->subject =="serviceoffer"){$surl3=$s->value;}
	if($s->name =="url4" && $s->subject =="serviceoffer"){$surl4=$s->value;}
	if($s->name =="url5" && $s->subject =="serviceoffer"){$surl5=$s->value;}
}

?>




<link rel="stylesheet" href="css/service.css" />
<link rel="stylesheet" href="css/service2.css" />

<style>
.page_title1.sty13 {text-align: left;padding: 58px 0px 45px 0px;background: #999 url(img/service/servicebanner.jpg) no-repeat center center;}
.page_title1.sty13 h1 {float: left;font-size: 30px;color: #fff;margin-bottom: 12px;}
.page_title1 h1 {color: #fff;font-size: 45px;font-weight: 700;line-height: 45px;text-transform: uppercase;}
.feature_section4 .left {background: #2a363f;text-align:center;}
.feature_section4 .center {background: #86c724;text-align:center;}
.feature_section4 .right {background: #f3f3f3;text-align:center;}
h1.light, h2.light, h3.light, h4.light, h5.light, h6.light {font-weight: 300;}
h3 {font-size: 21px;line-height: 28px;margin-bottom: 18px;}
h1, h2, h3, h4, h5, h6 {font-family: 'Roboto', sans-serif;font-weight: 500;color: #2a363f;letter-spacing: 0.5px;}
.wpb_wrapper{padding:40px 0;}
.white {color: #fff;}
h4 {font-size: 16px;line-height: 25px;margin-bottom: 10px;font-style: normal;}
.feature_section4 strong {color: #fff;font-size: 27px;font-weight: 700;letter-spacing: 0.5px;text-transform: uppercase;font-family: 'Roboto', sans-serif;
}
.feature_section4 strong em { color: #fff;font-size: 21px;font-weight: 300;font-style: normal;display: block;text-transform: none;margin-bottom: 9px;}
.button.three {color: #86c724;font-size: 14px;font-weight: bold;text-transform: uppercase;background: #fff;padding: 10px 25px;border-radius: 20px;white-space: nowrap;transition: all 0.3s ease;font-family: 'Roboto', sans-serif;}
.button.three:hover {color: #FFF;font-size: 14px;font-weight: bold;text-transform: uppercase;background: #86C724;padding: 10px 25px;border-radius: 20px;white-space: nowrap;transition: all 0.3s ease;font-family: 'Roboto', sans-serif;}
.parallax_section5{float:left;width:100%;text-align:center;padding:90px 0 70px;background:#eee url(img/site-img31.jpg);background-attachment:fixed;background-origin:initial;background-clip:initial;background-size:cover;background-repeat:no-repeat;background-position:100% 0;background-position:center}
.feature_section4 {float: left;width: 100%;padding: 90px 0px;}
#page1{background: #86C724; color: #FFF;}
</style>


 <script>
	   		function page1()
			{
				document.getElementById('page1body').style.display="block";
				
				document.getElementById("page1").setAttribute("style", "background: #86C724; color: #FFF;");
				var myElements = document.querySelectorAll("#page2,#page3,#page4,#page5");
				for (var i = 0; i < myElements.length; i++) 
				{
    				myElements[i].setAttribute("style", "background: #FFF; color: #272727;");
				}
				
				document.getElementById('page2body').style.display="none";
				document.getElementById('page3body').style.display="none";
				document.getElementById('page4body').style.display="none";
				document.getElementById('page5body').style.display="none";
			}
			function page2()
			{
				document.getElementById('page1body').style.display="none";
				document.getElementById('page2body').style.display="block";
				document.getElementById("page2").setAttribute("style", "background: #86C724; color: #FFF;");
				var myElements = document.querySelectorAll("#page1,#page3,#page4,#page5");
				for (var i = 0; i < myElements.length; i++) 
				{
    				myElements[i].setAttribute("style", "background: #FFF; color: #272727;");
				}
				
				document.getElementById('page3body').style.display="none";
				document.getElementById('page4body').style.display="none";
				document.getElementById('page5body').style.display="none";
			}
			function page3()
			{
				document.getElementById('page1body').style.display="none";
				document.getElementById('page2body').style.display="none";
				document.getElementById('page3body').style.display="block";
				document.getElementById("page3").setAttribute("style", "background: #86C724; color: #FFF;");
				var myElements = document.querySelectorAll("#page1,#page2,#page4,#page5");
				for (var i = 0; i < myElements.length; i++) 
				{
    				myElements[i].setAttribute("style", "background: #FFF; color: #272727;");
				}
				document.getElementById('page4body').style.display="none";
				document.getElementById('page5body').style.display="none";
			}
			function page4()
			{
				document.getElementById('page1body').style.display="none";
				document.getElementById('page2body').style.display="none";
				document.getElementById('page3body').style.display="none";
				document.getElementById('page4body').style.display="block";
				document.getElementById("page4").setAttribute("style", "background: #86C724; color: #FFF;");
				var myElements = document.querySelectorAll("#page1,#page2,#page3,#page5");
				for (var i = 0; i < myElements.length; i++) 
				{
    				myElements[i].setAttribute("style", "background: #FFF; color: #272727;");
				}
				document.getElementById('page5body').style.display="none";
			}
			function page5()
			{
				document.getElementById('page1body').style.display="none";
				document.getElementById('page2body').style.display="none";
				document.getElementById('page3body').style.display="none";
				document.getElementById('page4body').style.display="none";
				document.getElementById('page5body').style.display="block";
				document.getElementById("page5").setAttribute("style", "background: #86C724; color: #FFF;");
				var myElements = document.querySelectorAll("#page1,#page2,#page3,#page4");
				for (var i = 0; i < myElements.length; i++) 
				{
    				myElements[i].setAttribute("style", "background: #FFF; color: #272727;");
				}
			}
	   
	   </script> 







<body onLoad="page1()">


<div id="breadcrumb" class="page_title1 sty13"><div class="container-fuid" style="width:90%;margin:0 auto;padding-bottom:50px;"><h1><?php if(isset($bannertitle))echo $bannertitle;?></h1></div></div>

      
      
      
        <div id="king-216618" class="wpb_row vc_row-fluid  ">
          <div class="container-fuid" style="width:90%;margin:auto;">
            <div class="vc_col-sm-12 wpb_column vc_column_container ">
              <div class="wpb_wrapper">
                <div class="clearfix margin_top7"></div>
              </div>
            </div>
            <div class="clear"></div>
          </div>
        </div>
        
        
        
        
        
        
        
        
        
        
        
        
        <div id="king-891531" class="wpb_row vc_row-fluid  ">
          <div class="container-fluid" style="width:90%;margin:auto;">

            <div class="vc_col-sm-6" style="animation-delay: 250ms;">
              <div class="wpb_wrapper">
                <h3 class="light"><?php if(isset($serviceworktitle))echo $serviceworktitle;?></h3>
                <div class="wpb_text_column wpb_content_element ">
                  <div class="wpb_wrapper">
                    <p><?php if(isset($serviceworkdescribtion))echo $serviceworkdescribtion;?></p>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="vc_col-sm-6" style="animation-delay: 250ms;">
              <div class="wpb_wrapper">
                <h5><?php if(isset($servicework1))echo $servicework1;?></h5>
                <div class="ui-progress-bar ui-progress-bar1 king-progress-bar ui-container ">
                  <div class="ui-progress ui-progress1" style="border-bottom: 10px solid rgb(138, 191, 237); width: 95%;"> <span class="ui-label" style="display: block;"> <b class="value"><?php if(isset($servicework1percent))echo $servicework1percent;?></b> </span> </div>
                </div>
                <br>
                <h5><?php if(isset($servicework2))echo $servicework2;?></h5>
                <div class="ui-progress-bar ui-progress-bar1 king-progress-bar ui-container ">
                  <div class="ui-progress ui-progress1" style="border-bottom: 10px solid rgb(177, 146, 208); width: 80%;"> <span class="ui-label" style="display: block;"> <b class="value"><?php if(isset($servicework2percent))echo $servicework2percent;?></b> </span> </div>
                </div>
                <br>
                <h5><?php if(isset($servicework3))echo $servicework3;?></h5>
                <div class="ui-progress-bar ui-progress-bar1 king-progress-bar ui-container ">
                  <div class="ui-progress ui-progress1" style="border-bottom: 10px solid rgb(231, 209, 141); width: 92%;"> <span class="ui-label" style="display: block;"> <b class="value"><?php if(isset($servicework3percent))echo $servicework3percent;?></b> </span> </div>
                </div>
                <br>
                <h5><?php if(isset($servicework4))echo $servicework4;?></h5>
                <div class="ui-progress-bar ui-progress-bar1 king-progress-bar ui-container ">
                  <div class="ui-progress ui-progress1" style="border-bottom: 10px solid rgb(243, 145, 145); width: 84%;"> <span class="ui-label" style="display: block;"> <b class="value"><?php if(isset($servicework4percent))echo $servicework4percent;?></b> </span> </div>
                </div>
                <br>
              </div>
            </div>
            <div class="clear"></div>
          </div>
        </div>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <!--------------- Secure-Fast-Reliable ----------------------------------------------------------------------------------->
        
        <div id="king-154353" class="wpb_row vc_row-fluid feature_section4  ">
          <div class="container-fluid" style="width:90%;margin:auto;">
            <div class="vc_col-sm-4 left delay-200ms wpb_column vc_column_container" style="animation-delay: 200ms;">
              <div class="wpb_wrapper"> <strong><em><?php if(isset($subtitle1)) echo $subtitle1?></em> <?php if(isset($headertitle1)) echo $headertitle1?></strong>
                <div class="king-elements ">
                  <div class="king-elements-inner"> <img src="img/service/servicehosting1.jpg" class="element-icon " alt="">
                    <h4 class="white light"><?php if(isset($comment1)) echo $comment1?></h4>
                    <br>
                    <a href="<?php if(isset($url1)) echo $url1?>" class="button three"><i class="fa fa-caret-right"></i> Read More</a> </div>
                </div>
              </div>
            </div>
            
            <div class="vc_col-sm-4 center delay-200ms wpb_column vc_column_container" style="animation-delay: 200ms;">
              <div class="wpb_wrapper"> <strong><em><?php if(isset($subtitle2)) echo $subtitle2?></em> <?php if(isset($headertitle2)) echo $headertitle2?></strong>
                <div class="king-elements ">
                  <div class="king-elements-inner"> <img src="img/service/servicehosting2.jpg" class="element-icon " alt="">
                    <h4 class="white light"><?php if(isset($comment2)) echo $comment2?></h4>
                    <br>
                    <a href="<?php if(isset($url2)) echo $url2?>" class="button three"><i class="fa fa-caret-right"></i> Read More</a> </div>
                </div>
              </div>
            </div>
            
            <div class="vc_col-sm-4 right delay-200ms wpb_column vc_column_container" style="animation-delay: 200ms;">
              <div class="wpb_wrapper"> <strong style="color:#25333D"><em style="color:#25333D"><?php if(isset($subtitle3)) echo $subtitle3?></em> <?php if(isset($headertitle3)) echo $headertitle3?></strong>
                <div class="king-elements ">
                  <div class="king-elements-inner"> <img src="img/service/servicehosting3.jpg" class="element-icon " alt="">
                    <h4 class="light"><?php if(isset($comment3)) echo $comment3?></h4>
                    <br>
                    <a href="<?php if(isset($url3)) echo $url3?>" class="button three"><i class="fa fa-caret-right"></i> Read More</a> </div>
                </div>
              </div>
            </div>
            <div class="clear"></div>
          </div>
        </div>
        
        
        
        
        
    <!--------------- What more we offer --------------------------------------------------------------------------->    
        
      
        
        
        
        <div id="king-430949" class="wpb_row vc_row-fluid parallax_section5  ">
          <div class="container-fluid" style="width:90%;margin:auto;">
            <div class="vc_col-sm-12 wpb_column vc_column_container ">
              <div class="wpb_wrapper">
                <h1 class="caps white delay-200ms" style="animation-delay: 200ms;"><center><strong>What more we offer</strong></center></h1>
                <div class="clearfix margin_top1"></div>
                <div class="king-tabs king-tabs-ipad-sliders wpb_tabs wpb_content_element  detached delay-250ms" data-interval="0" style="animation-delay: 250ms;">
                  <div class="wpb_wrapper wpb_tour_tabs_wrapper ui-tabs vc_clearfix ui-widget ui-widget-content ui-corner-all">
                    
                    <ul class="ui-tabs-nav king-tabs-nav vc_clearfix ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">
                      <li class="ui-state-default ui-corner-top" role="tab" tabindex="0" aria-controls="tab-1438590307034-1-1" aria-labelledby="ui-id-2" aria-selected="false" aria-expanded="false">
                      <a href="javascript:void(0)" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="page1" onClick="return page1()"><?php if(isset($menutitle1)) echo $menutitle1?></a>
                      </li>
                      
                      <li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tab-1438590307034-1-2" aria-labelledby="ui-id-2" aria-selected="false" aria-expanded="false">
                      <a href="javascript:void(0)" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="page2" onClick="return page2()"><?php if(isset($menutitle2)) echo $menutitle2?></a>
                      </li>
                      
                      <li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tab-1438590370593-2-2" aria-labelledby="ui-id-3" aria-selected="false" aria-expanded="false">
                      <a href="javascript:void(0)" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="page3" onClick="return page3()"><?php if(isset($menutitle3)) echo $menutitle3?></a>
                      </li>
                      
                      <li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tab-1438590411922-3-8" aria-labelledby="ui-id-4" aria-selected="false" aria-expanded="false">
                      <a href="javascript:void(0)" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="page4" onClick="return page4()"><?php if(isset($menutitle4)) echo $menutitle4?></a>
                      </li>
                      
                      <li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tab-1438590447242-4-6" aria-labelledby="ui-id-5" aria-selected="false" aria-expanded="false">
                      <a href="javascript:void(0)" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="page5" onClick="return page5()"><?php if(isset($menutitle5)) echo $menutitle5?></a>
                      </li>
                      
                    </ul>
                    
                    
                    
                    
                    <div class="king-tabs-panes">
                    
                    <!----- 1 ------------->
                      <div id="page1body" class="king-tabs-pane king-clearfix ui-tabs-panel wpb_ui-tabs-hide  ui-widget-content ui-corner-bottom" aria-labelledby="ui-id-1" role="tabpanel" style="display:block;" aria-hidden="false">
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                          <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="wpb_wrapper">
                              <div class="wpb_single_image wpb_content_element vc_align_left">
                                <div class="wpb_wrapper">
                                  <div class="vc_single_image-wrapper   vc_box_border_grey">
                                  <img src="img/service/serviceoffer1.jpg" class="vc_single_image-img attachment-full" alt=""  sizes="(max-width: 320px) 100vw, 320px" width="320" height="200">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="wpb_column vc_column_container vc_col-sm-8">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element ">
                                <div class="wpb_wrapper">
                                  <h2><?php if(isset($header1)) echo $header1?></h2>
                                  <p class="bigtfont dark">
                                  <?php if(isset($description1)) echo $description1?>
                                  </p>
                                  <p>&nbsp;</p>
                                  <p><a class="button two" href="<?php if(isset($surl1)) echo $surl1?>">Learn More</a></p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                       <!----- 2 ------------->
                      
                      <div id="page2body" class="king-tabs-pane king-clearfix ui-tabs-panel wpb_ui-tabs-hide  ui-widget-content ui-corner-bottom" aria-labelledby="ui-id-2" role="tabpanel" style="display: none;" aria-hidden="false">
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                          <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="wpb_wrapper">
                              <div class="wpb_single_image wpb_content_element vc_align_left">
                                <div class="wpb_wrapper">
                                  <div class="vc_single_image-wrapper   vc_box_border_grey">
                                 	<img src="img/service/serviceoffer2.jpg" class="vc_single_image-img attachment-full" alt=""  sizes="(max-width: 320px) 100vw, 320px" width="320" height="200">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="wpb_column vc_column_container vc_col-sm-8">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element ">
                                <div class="wpb_wrapper">
                                  <h2><?php if(isset($header2)) echo $header2?></h2>
                                  <p class="bigtfont dark">
                                  <?php if(isset($description2)) echo $description2?>
                                  </p>
                                  <p>&nbsp;</p>
                                  <p><a class="button two" href="<?php if(isset($surl2)) echo $surl2?>">Learn More</a></p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                       <!----- 3 ------------->
                      
                      <div id="page3body" class="king-tabs-pane king-clearfix ui-tabs-panel wpb_ui-tabs-hide  ui-widget-content ui-corner-bottom" aria-labelledby="ui-id-3" role="tabpanel" style="display: none;" aria-hidden="false">
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                          <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="wpb_wrapper">
                              <div class="wpb_single_image wpb_content_element vc_align_left">
                                <div class="wpb_wrapper">
                                  <div class="vc_single_image-wrapper   vc_box_border_grey">
                                  <img src="img/service/serviceoffer3.jpg" class="vc_single_image-img attachment-full" alt=""  sizes="(max-width: 320px) 100vw, 320px" width="320" height="200">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="wpb_column vc_column_container vc_col-sm-8">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element ">
                                <div class="wpb_wrapper">
                                  <h2><?php if(isset($header3)) echo $header3?></h2>
                                  <p class="bigtfont dark">
                                  <?php if(isset($description3)) echo $description3?>
                                  </p>
                                  <p>&nbsp;</p>
                                  <p><a class="button two" href="<?php if(isset($surl3)) echo $surl3?>">Learn More</a></p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                       <!----- 4 ------------->
                      
                      <div id="page4body" class="king-tabs-pane king-clearfix ui-tabs-panel wpb_ui-tabs-hide  ui-widget-content ui-corner-bottom" aria-labelledby="ui-id-4" role="tabpanel" style="display: none;" aria-hidden="false">
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                          <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="wpb_wrapper">
                              <div class="wpb_single_image wpb_content_element vc_align_left">
                                <div class="wpb_wrapper">
                                  <div class="vc_single_image-wrapper   vc_box_border_grey">
                                  <img src="img/service/serviceoffer4.jpg" class="vc_single_image-img attachment-full" alt=""  sizes="(max-width: 320px) 100vw, 320px" width="320" height="200">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="wpb_column vc_column_container vc_col-sm-8">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element ">
                                <div class="wpb_wrapper">
                                  <h2><?php if(isset($header4)) echo $header4?></h2>
                                  <p class="bigtfont dark">
                                  <?php if(isset($description4)) echo $description4?>
                                  </p>
                                  <p>&nbsp;</p>
                                  <p><a class="button two" href="<?php if(isset($surl4)) echo $surl4?>">Learn More</a></p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                       <!----- 5 ------------->
                      
                      <div id="page5body" class="king-tabs-pane king-clearfix ui-tabs-panel wpb_ui-tabs-hide  ui-widget-content ui-corner-bottom" aria-labelledby="ui-id-5" role="tabpanel" style="display: none;" aria-hidden="false">
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                          <div class="wpb_column vc_column_container vc_col-sm-4">
                            <div class="wpb_wrapper">
                              <div class="wpb_single_image wpb_content_element vc_align_left">
                                <div class="wpb_wrapper">
                                  <div class="vc_single_image-wrapper   vc_box_border_grey">
                                  <img src="img/service/serviceoffer5.jpg" class="vc_single_image-img attachment-full" alt=""  sizes="(max-width: 320px) 100vw, 320px" width="320" height="200">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="wpb_column vc_column_container vc_col-sm-8">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element ">
                                <div class="wpb_wrapper">
                                  <h2><?php if(isset($header5)) echo $header5?></h2>
                                  <p class="bigtfont dark">
                                  <?php if(isset($description5)) echo $description5?>
                                  </p>
                                  <p>&nbsp;</p>
                                  <p><a class="button two" href="<?php if(isset($surl5)) echo $surl5?>">Learn More</a></p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="clear"></div>
          </div>
        </div>
        
        
        
        
       <!--------- Latest News / Blogs ----------------------------------------------------------------------------------> 
        
        
        
        
        
        
        
        
        
        
       <!----------- Our Management Team ---------------------------------------------------------------------------> 
        

        
        
        
        
        
        
        
        
        
        
        
        <div class="vc_row-full-width"></div>
    <div class="vc_row wpb_row vc_row-fluid " style=" ">
      <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section10">
              <div class="container">
              		<style>
						.imgspace{width:11%;min-height:40px;}
					</style>
              		<center>
                        <img src="img/link/hostingpanel-icon1.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon2.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon3.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon4.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon5.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon6.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon7.jpg" alt="" class="imgspace">
                        <img src="img/link/hostingpanel-icon8.jpg" alt="" class="imgspace">
                    </center>
                
              </div>
            </section>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
        
        
        
</body>
       
      
