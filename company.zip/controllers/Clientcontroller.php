<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clientcontroller extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
		//$this->output->set_header("Cache-Control: post-check=0, pre-check=0", false);
		//$this->output->set_header("Pragma: no-cache");
		$this->mm->isLogin();  ///////// Call isLogin() for all function ////////////////////
		date_default_timezone_set("Asia/Dhaka");
	}
	public function index()
	{
		$data = array();
		$data['menu'] = 'home';
		$data['content'] = $this->load->view('client_home',$data,true);
		$data['footercontainer'] = $this->load->view('footercontainer','',true);
		$this->load->view('masterclient',$data);
	}
	
	
	
	
}
