<style>
.ov{overflow:hidden;}
.tp-caption.smalltext_two {font-weight: 400;text-align: center;line-height: 35px;}
.tp-caption.text5 {color: #fff;font-size: 80px;font-weight: 700;}
.tp-caption.text5, .tp-caption.text6, .tp-caption.text7 {position: absolute;text-transform: uppercase;padding: 0;font-family: Raleway,sans-serif;}
.tp-splitted{letter-spacing:7px;}
.homebannertitleposition{
    z-index: 7;white-space: nowrap;min-height: 0px; min-width: 0px;line-height: 23px;border-width: 0px;margin: 0px;letter-spacing: 0px;font-size: 80px;left: 0px;top: 200px; /****/visibility: visible;opacity: 1;transform: matrix(1, 0, 0, 1, 0, 0);width: 100%;}
.homebannersubtitleposition{
    z-index: 6;min-height: 0px;min-width: 0px;line-height: 35px;border-width: 0px; margin: 0px; padding: 0px;letter-spacing: 0px;font-size: 18px;left: 0px;top: 265px;  /****/visibility: visible;opacity: 1;transform: translate3d(0px, 0px, 0px);width: 100%;text-align: center;}
.ps1{padding:35px 0;}
.section9 h2{ font-size:30px;}
.tm1{max-height:200px;float:left;}
.tm1i{width: 555px;}
.img-pro{margin-top:20%}
.focus-box .service-icon{border:none;}
.bennerheight{max-height:600px !important;}
.tp-caption.smalltext_two{font-size:40px;font-weight:bold;}

@media(min-width: 320px) and (max-width: 767px)
{
	/**** Banner *******/
.tp-caption.text5 {color: #fff;font-size: 20px;font-weight: 700;}
.tp-caption.text5, .tp-caption.text6, .tp-caption.text7 {position: absolute;text-transform: uppercase;padding: 0;font-family: Raleway,sans-serif;}
.homebannertitleposition{
    z-index: 7;white-space: nowrap;min-height: 0px; min-width: 0px;line-height: 23px;border-width: 0px;margin: 0px;letter-spacing: 0px;font-size: 20px;left: 0px;top: 50px; /****/visibility: visible;opacity: 1;transform: matrix(1, 0, 0, 1, 0, 0);width: 100%;}
.homebannersubtitleposition{
    z-index: 6;min-height: 0px;min-width: 0px;line-height: 35px;border-width: 0px; margin: 0px; padding: 0px;letter-spacing: 0px;font-size: 18px;left: 0px;top: 65px;  /****/visibility: visible;opacity: 1;transform: translate3d(0px, 0px, 0px);width: 100%;text-align: center;}
	.tp-caption.smalltext_two {font-weight: 400;text-align: center;line-height:35px;font-size:12px;}
	.tp-splitted{letter-spacing: 0px;}
	.navbar-toggle {position: relative;float: none;padding: 12px 10px;margin-top: -55px;margin-right: 0px;margin-bottom: 0;background-color: transparent;border: 0px solid transparent; border-radius: 0;background: #272727;cursor: pointer;}
	.section1.six {padding: 1px 0 0;}
	/**** Domain *******/
	.title1 h2 {color: #fff;font-size: 20px;position: relative;z-index: 1;line-height: 28px;}
	.title1 h2 .text {color: #222;font-size: 10px;font-style: normal;}
	.title1 h2 em {display: block;font-style: normal;font-weight: 400;margin: 0;text-transform: none;width: 100%;font-size:12px;line-height:12px;}
	.domain_search_home #domain-searchform #dsearch{width:50%;height: 30px;padding: 0 0 0 8px;}
	.domain_search_home .drlist{width:25%;height:30px;margin-left:2px;line-height:30px;font-size:10px;margin-bottom: 0px;padding:0px;}
	.domain_search_home #searchsubmit{ margin:0;font-size:10px;width:60px;height:30px;text-align:center !important;padding:0px;}
	.domain_search_home ul.tld_list {float: left;margin: 0;padding: 0px 0 10px;width: 100%;}
	.one_third{margin-top:-20px;}
	.crossed_shape.two{display:none}
	.section-header h2 {padding-bottom: 10px;line-height: 20px;position: relative;display: inline-block;font-size: 20px;text-transform: uppercase;margin-top: 10px;margin-bottom: 0;}
	.ps1{padding:10px 0;}
	h6 {font-size: 10px;line-height: 15px;margin-bottom: 14px;text-transform: none;}
	.focus-box .service-icon {margin-bottom: 30px;width: 80px;height: 80px;margin: auto;border-radius: 50%border: 10px solid #ececec;margin-bottom: 20px;position: relative;-webkit-transition: all 0.2s ease-in-out;transition: all 0.2s ease-in-out;}
	.focus-box .service-icon a img{max-width:70% !important;}
	.section9 {margin-top: 30px;}
	.section9 h2{ font-size:20px;}
	.tm1{max-height:300px;float:left;}
	.tm1i{width: 300px;}
	.client-quote p{font-size:14px;}
	.img-pro{margin-top:17%}
	.scdn{display:none;width:0px;height:0px;}
	.scdnm{margin:0px;padding:0px;}
	.bennerheight{max-height:200px !important;}
}


@media(min-width: 768px) and (max-width: 980px)
{
	.homebannertitleposition{
    z-index: 7;white-space: nowrap;min-height: 0px; min-width: 0px;line-height: 23px;border-width: 0px;margin: 0px;letter-spacing: 0px;font-size: 40px !important;left: 0px;top: 100px; /****/visibility: visible;opacity: 1;transform: matrix(1, 0, 0, 1, 0, 0);width: 100%;}
.homebannersubtitleposition{
    z-index: 6;min-height: 0px;min-width: 0px;line-height: 35px;border-width: 0px; margin: 0px; padding: 0px;letter-spacing: 0px;font-size: 18px;left: 0px;top: 165px;  /****/visibility: visible;opacity: 1;transform: translate3d(0px, 0px, 0px);width: 100%;text-align: center;}
	.scdn{display:none;width:0px;height:0px;}
	.scdnm{margin-left:100px;}
	.section-header h2{font-size:30px !important;line-height: 30px;}
	.bennerheight{max-height:300px !important;}
}
</style>


<?php

	$settingdata = $this->db->query("select * from t_homedata")->result();
	$homebannertitle ='';
	$homeyourdomain='';
	$homebannersubtitle='';
	$homebanner='';
	$homeyourdomain='';
	$homesearchtext='';
	$homesiteuniq='';
	$homesiteuniqsubtext='';
	$homePARALLAXEFFECT='';
	$homeFOCUSHEADING1='';
	$homeFOCUSHEADING2='';
	$homeFOCUSHEADING3='';
	$homeFOCUSHEADING4='';
	$homeMOVABLESECTIONS='';
	$homeWOOCOMMERCE='';
	$homeCUSTOMCONTENTBLOCKS='';
	$homePARALLAXEFFECTbody='';
	$homeMOVABLESECTIONSbody='';
	$homeWOOCOMMERCEbody='';
	$homeCUSTOMCONTENTBLOCKSbody='';
	$homeHostingPlans='';
	$homeHostingPlansbody='';
	$homeHostingPlans1Name='';
	$homeHostingPlans1Price=0;
	$homeHostingPlans2Name='';
	$homeHostingPlans2Price=0;
	$homeHostingPlans3Name='';
	$homeHostingPlans3Price=0;
	$homeHostingPlans4Name='';
	$homeHostingPlans4Price=0;
	
	$special_offer='';
	$specialofferimg='';
	
	$parallaximg='';
	$movableimg='';
	$wooimg='';
	$customcontentimg='';
	
	$homehosting1buttonname='';
	$homehosting2buttonname='';
	$homehosting3buttonname='';
	$homehosting4buttonname='';
	$homeHostingPlanSharedDataUrl='';
	$homeHostingPlanVPSDataUrl='';
	$homeHostingPlanResellerDataUrl='';
	$homeHostingPlanDedicatedDataUrl='';
	$specialofferurl='';
	
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home banner title'){$homebannertitle = $set->value;}
			if($set->name == 'home banner sub title'){$homebannersubtitle = $set->value;}
			if($set->name == 'homebannerimg'){$homebanner = $set->value;}
			if($set->name == 'home yourdomain'){$homeyourdomain = $set->value;}
			if($set->name == 'home searchtext'){$homesearchtext = $set->value;}
			if($set->name == 'home siteuniq'){$homesiteuniq = $set->value;}
			if($set->name == 'home siteuniq subtext'){$homesiteuniqsubtext = $set->value;}
			if($set->name == 'home PARALLAX EFFECT'){$homePARALLAXEFFECT = $set->value;}
			if($set->name == 'home FOCUS HEADING1'){$homeFOCUSHEADING1 = $set->value;}
			if($set->name == 'home FOCUS HEADING2'){$homeFOCUSHEADING2 = $set->value;}
			if($set->name == 'home FOCUS HEADING3'){$homeFOCUSHEADING3 = $set->value;}
			if($set->name == 'home FOCUS HEADING4'){$homeFOCUSHEADING4 = $set->value;}
			if($set->name == 'home MOVABLE SECTIONS'){$homeMOVABLESECTIONS = $set->value;}
			if($set->name == 'home WOOCOMMERCE'){$homeWOOCOMMERCE = $set->value;}
			if($set->name == 'home CUSTOM CONTENT BLOCKS'){$homeCUSTOMCONTENTBLOCKS = $set->value;}
			if($set->name == 'home PARALLAX EFFECT body'){$homePARALLAXEFFECTbody = $set->value;}
			if($set->name == 'home MOVABLE SECTIONS body'){$homeMOVABLESECTIONSbody = $set->value;}
			if($set->name == 'home WOOCOMMERCE body'){$homeWOOCOMMERCEbody = $set->value;}
			if($set->name == 'home CUSTOM CONTENT BLOCKS body'){$homeCUSTOMCONTENTBLOCKSbody = $set->value;}
			if($set->name == 'home Hosting Plans'){$homeHostingPlans = $set->value;}
			if($set->name == 'home Hosting Plans body'){$homeHostingPlansbody = $set->value;}
			if($set->name == 'home Hosting Plans1 Name'){$homeHostingPlans1Name = $set->value;}
			if($set->name == 'home Hosting Plans1 Price'){$homeHostingPlans1Price = $set->value;}
			if($set->name == 'home Hosting Plans2 Name'){$homeHostingPlans2Name = $set->value;}
			if($set->name == 'home Hosting Plans2 Price'){$homeHostingPlans2Price = $set->value;}
			if($set->name == 'home Hosting Plans3 Name'){$homeHostingPlans3Name = $set->value;}
			if($set->name == 'home Hosting Plans3 Price'){$homeHostingPlans3Price = $set->value;}
			if($set->name == 'home Hosting Plans4 Name'){$homeHostingPlans4Name = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$homeHostingPlans4Price = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$homeHostingPlans4Price = $set->value;}
			
			if($set->name == 'special_offer'){$special_offer = $set->value;}
			if($set->name == 'specialofferimg'){$specialofferimg = $set->value;}
			
			if($set->name == 'homehosting1buttonname'){ $homehosting1buttonname = $set->value;}
			if($set->name == 'homehosting2buttonname'){ $homehosting2buttonname = $set->value;}
			if($set->name == 'homehosting3buttonname'){ $homehosting3buttonname = $set->value;}
			if($set->name == 'homehosting4buttonname'){ $homehosting4buttonname = $set->value;}
			
			if($set->name == 'homeHostingPlanSharedDataUrl'){ $homeHostingPlanSharedDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanVPSDataUrl'){ $homeHostingPlanVPSDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanResellerDataUrl'){ $homeHostingPlanResellerDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanDedicatedDataUrl'){ $homeHostingPlanDedicatedDataUrl = $set->value;}
			
			
			
			if($set->name == 'parallaximg'){$parallaximg = $set->value;}
			if($set->name == 'movableimg'){$movableimg = $set->value;}
			if($set->name == 'wooimg'){$wooimg = $set->value;}
			if($set->name == 'customcontentimg'){$customcontentimg = $set->value;}
			//if($set->name == 'home yourdomain'){ $homeyourdomain = $set->value;}
			if($set->name == 'special_offer_url'){ $specialofferurl = $set->value;}
			
		}
	}
	
?>



<div class="container-fluid">




<!------- Slide show start ------------------------------------------------------------------------------>
    <div class="row" style=""> <!---vc_row wpb_row vc_row-fluid -->
      <div class="col-md-12 col-sm-12 col-xs-12"> <!--  wpb_column vc_column_container vc_col-md-12 vc_col-sm-12 ---->
        		<div style="width:100%;float:left;overflow:hidden" class="bennerheight">
        		<img src="img/<?php if(isset($homebanner))echo $homebanner;?>" style="-moz-user-select: none;  width: 100%;   visibility: inherit; opacity: 1; transform: matrix(1.24482, 0, 0, 1.24482, 0, 0); transform-origin: 0% 0% 0px;" class="img-responsive">
               
               
               <div class="tp-caption text5 randomrotate start splitted homebannertitleposition" data-x="center" data-y="220" data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" data-speed="500" data-start="1500" data-easing="Power3.easeInOut" data-splitin="chars" data-splitout="chars" data-elementdelay="0.08" data-endelementdelay="0.08" data-endspeed="300" >
                            <div style="display: block; text-align: left; position: relative;" class="tp-splitted">
                              <div style="position:relative;display:inline-block;text-align:center;width:100%;" class="tp-splitted">
                                <div style="position: relative; display: inline-block; visibility: visible; opacity: 1; transform: translate3d(0px, 0px, 0px);text-align:center;width:100%;" class="tp-splitted" >
								<?php if(isset($homebannertitle)&& !empty($homebannertitle))echo $homebannertitle;?> 
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          
                          <div class="tp-caption smalltext_two sft start homebannersubtitleposition" data-x="center" data-hoffset="0" data-voffset="-10" data-y="295" data-speed="800" data-start="1800" data-easing="Power4.easeOut" data-endspeed="300" data-endeasing="Power1.easeIn" data-captionhidden="off" >
                          <?php if(isset($homebannersubtitle)&& !empty($homebannersubtitle))echo $homebannersubtitle;?>
                          </div> 
                          
        </div>
      </div>
    </div>
    
<!------- Slide show End ------------------------------------------------------------------------------>    
    
    
    
    
<!------- Domain Search Start ------------------------------------------------------------------------->    
<div class="row" style=" "> 
    <div class="col-md-12 col-sm-12 col-xs-12">
      
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section1 six" style="padding-bottom:10px;" data-anim-type="fade-in" data-anim-delay="100">
              <div class="container domain_search_home">
                <div class="title1">
                  <h2><span class="line"></span><span class="text">Search Here</span><br>
                  
                    <?php if(isset($homeyourdomain)&& !empty($homeyourdomain))echo $homeyourdomain;?> <!-- yourdomain --->
                    <em> 
					<?php if(isset($homesearchtext)&& !empty($homesearchtext))echo $homesearchtext;?></em></h2>
                </div>
                <style>
				
				</style>
                <div class="two_third last" style="width: 100%;float:none">
                	<div class="col-md-2 col-sm-3 scdn">&nbsp;</div> <!----scdn--->
                    <div class="col-md-9 col-sm-9 scdnm" align="center">
                    <center>
                  <form method="POST" id="domain-searchform" action="<?php echo '#'?>" >
                    <input class="input-text" name="domain" id="dsearch" placeholder="Enter your Domain Namer here...." type="text">
                    <select class="drlist" name="ext">
                      <option selected="selected">.com</option>
                      <option>.net</option>
                      <option>.org</option>
                      <option>.biz</option>
                      <option>.info</option>
                      <option>.co</option>
                    </select>
                    <input id="searchsubmit" value="Search" type="submit">
                  </form>
                  </center>
                  </div>
                </div>
                
                <!--<div class="one_third last">
                  <ul class="tld_list">
                  	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$count = 0;
							foreach($settingdata as $dp)
							{
								if($dp->subject == 'domainprice' && $dp->name !='.me')
								{
									
					?>
                    <li><?php if(isset($dp->name))echo $dp->name;?> <span><br>
                      <?php if(isset($dp->value))echo $dp->value;?></span></li>
                   
                    <?php	
								}
							}
						}
					?>  
                  </ul>
                </div>-->
                
                
              </div>
              <div class="crossed_shape two"></div>
            </section>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    
    
    </div>
    
    
    
    
    
    
    
    
    
  <!-----------  Hosting Plans  ---------------------------------------->  
    
    
    
    <div class="vc_row-full-width"></div>
    <div class="vc_row wpb_row vc_row-fluid " style=" ">
      <div class="wpb_column vc_column_container vc_col-md-12 vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper" style="margin-top:40px;">
            <div class="title">
              <h2 style="color: ;"><span style="background: ;" class="line blueline"></span><span style="color: ;" class="text">Our Best</span><br>
              
                <?php if(isset($homeHostingPlans)&& !empty($homeHostingPlans))echo $homeHostingPlans;?>
                
                <em style="color: ;">
                <?php if(isset($homeHostingPlansbody)&& !empty($homeHostingPlansbody))echo $homeHostingPlansbody;?>
                </em></h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="vc_row wpb_row vc_row-fluid " style=" padding-bottom: 10px;width:90%;margin:auto;">
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans1Price)&& !empty($homeHostingPlans1Price))echo $homeHostingPlans1Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans1Name)&& !empty($homeHostingPlans1Name))echo $homeHostingPlans1Name;?></h2>
                </div>
                <ul class="plan-list">
                
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting1' && $hp->name !='homehosting1buttonname' && $hp->name !='homeHostingPlanSharedDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>	
                      <li class="light">10 GB Disk Space<br></li>
                      <li class="dark">256 MB Memory<br></li>
                      <li class="light">Free Domain Registration<br></li>
                      <li class="dark">5 Email Accounts<br></li>
                      <li class="light">1 Hosting Space<br></li>
                      <li class="dark">24/7 Full Support</li>
                  <?php
						}
				  ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanSharedDataUrl)) echo $homeHostingPlanSharedDataUrl;?>" class="btn darkbox "><?php if(isset($homehosting1buttonname)&& !empty($homehosting1buttonname)){echo $homehosting1buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col active">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans2Price)&& !empty($homeHostingPlans2Price))echo $homeHostingPlans2Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans2Name)&& !empty($homeHostingPlans2Name))echo $homeHostingPlans2Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting2' && $hp->name !='homehosting2buttonname' && $hp->name !='homeHostingPlanVPSDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>	
                      <li class="light">15 GB Disk Space<br>
                      </li>
                      <li class="dark">512 MB Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">10 Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
				  <?php
						}
                  ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanVPSDataUrl)) echo $homeHostingPlanVPSDataUrl;?>" class="btn darkbox active"><?php if(isset($homehosting2buttonname)&& !empty($homehosting2buttonname)){echo $homehosting2buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans3Price)&& !empty($homeHostingPlans3Price))echo $homeHostingPlans3Price;?><br>
                    <span>/ mo</span></h4>
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans3Name)&& !empty($homeHostingPlans3Name))echo $homeHostingPlans3Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting3' && $hp->name !='homehosting3buttonname' && $hp->name !='homeHostingPlanResellerDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>	
                      <li class="light">20 GB Disk Space<br>
                      </li>
                      <li class="dark">1 GB Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">15 Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
                     <?php
						}
					 ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanResellerDataUrl)) echo $homeHostingPlanResellerDataUrl;?>" class="btn darkbox "><?php if(isset($homehosting3buttonname)&& !empty($homehosting3buttonname)){echo $homehosting3buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="wpb_column vc_column_container vc_col-md-3 vc_col-sm-3">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <div class="vc_empty_space" style="height: 15px"><span class="vc_empty_space_inner"></span></div>
            <div class="animate-in" data-anim-type="fade-in-down" data-anim-delay="100">
              <div class="price-col ">
                <div class="price">
                  <h4><?php if(isset($homeHostingPlans4Price)&& !empty($homeHostingPlans4Price))echo $homeHostingPlans4Price;?><br>
                    <span>One Time</span></h4> <!---   / mo  --------->
                </div>
                <div class="plan-title">
                  <h2><?php if(isset($homeHostingPlans4Name)&& !empty($homeHostingPlans4Name))echo $homeHostingPlans4Name;?></h2>
                </div>
                <ul class="plan-list">
                	<?php
                    	if(isset($settingdata)&& !empty($settingdata))
						{
							$i=1;
							foreach($settingdata as $hp)
							{
								if($hp->subject =='home hosting4' && $hp->name !='homehosting4buttonname' && $hp->name !='homeHostingPlanDedicatedDataUrl')
								{
									if($i<2)
									{
										echo '<li class="light ov">'.$hp->value.'<br></li>';
										$i++;
									}
									else
									{
										$i--;
										echo '<li class="dark ov">'.$hp->value.'<br></li>';
									}
									
								}
							}
						}
						else
						{
					?>
                      <li class="light">Unlimited Disk Space<br>
                      </li>
                      <li class="dark">Unlimited Memory<br>
                      </li>
                      <li class="light">Free Domain Registration<br>
                      </li>
                      <li class="dark">Unlimited Email Accounts<br>
                      </li>
                      <li class="light">1 Hosting Space<br>
                      </li>
                      <li class="dark">24/7 Full Support</li>
                     <?php
						}
					 ?>
                </ul>
                <div class="get-btn"> <a href="<?php if(isset($homeHostingPlanDedicatedDataUrl))  echo $homeHostingPlanDedicatedDataUrl;?>" class="btn darkbox "><?php if(isset($homehosting4buttonname)&& !empty($homehosting4buttonname)){echo $homehosting4buttonname;}else{echo 'Get Started';}?></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
   
   
   
   
   
    
<!------- Domain Search End ----------------------------------------------------------------->        
 <div class="vc_row-full-width"></div>

 <!--- Service Section ------------------------------------------------------------------------>   
 
 
    <div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding" style="position: relative; left: 0px; box-sizing: border-box; width: 100%;">
      <div class="wpb_column vc_column_container vc_col-md-12 vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section2 one">
              <div class="container-fluid" style="width:90%;margin:auto;">
                <div class="section-header ps1" >
                    <h2 class="dark-text">
                        <?php if(isset($homesiteuniq)&& !empty($homesiteuniq))echo $homesiteuniq;?>
                    </h2>
                    <h6>
                        <?php if(isset($homesiteuniqsubtext)&& !empty($homesiteuniqsubtext))echo $homesiteuniqsubtext;?>
                        
                    </h6>
                </div>
                
                 <!-------section-header -------------->
                
                
                
                <div class="row">
           




<span id="ctup-ads-widget-3">
		<div class="col-lg-3 col-md-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon gc" align="center">
								
					<a target="_self" href="#"><img src="<?php if(isset($parallaximg)&& !empty($parallaximg)){echo base_url().'img/'.$parallaximg;}else{ echo base_url().'img/parallaximg.png';} ?>" class="img-pro"></a>

			</div>
                                            
                                            
<center>                                                                        
		<h5>
        	<?php if(isset($homePARALLAXEFFECT)&& !empty($homePARALLAXEFFECT))echo $homePARALLAXEFFECT;?>
        </h5> 
        <?php if(isset($homeFOCUSHEADING1)&& !empty($homeFOCUSHEADING1))echo $homeFOCUSHEADING1;?>
        
        <hr class="gcl"></hr>
			<p>
				<?php if(isset($homePARALLAXEFFECTbody)&& !empty($homePARALLAXEFFECTbody))echo $homePARALLAXEFFECTbody;?>
			</p>
</center>

		</div>
</span>



<!----------------------------------------->



<span id="ctup-ads-widget-4">
		<div class="col-lg-3 col-md-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon bc" align="center">
								
					<a target="_self" href="#">  
                    <img src="<?php if(isset($movableimg)&& !empty($movableimg)){echo base_url().'img/'.$movableimg;}else{ echo base_url().'img/movableimg.png';} ?>" class="img-pro">
                    </a>

											</div>
                                            
                                            
<center>                                             
			<h5 class="red-border-bottom"><?php if(isset($homeMOVABLESECTIONS)&& !empty($homeMOVABLESECTIONS))echo $homeMOVABLESECTIONS;?><!--MOVABLE SECTIONS--></h5>  
            <?php if(isset($homeFOCUSHEADING2)&& !empty($homeFOCUSHEADING2))echo $homeFOCUSHEADING2;?> 
			<hr class="bcl"></hr>
            <p>
            	<?php if(isset($homeMOVABLESECTIONSbody)&& !empty($homeMOVABLESECTIONSbody))echo $homeMOVABLESECTIONSbody;?>
			</p>
</center>            
		</div>
</span>


<!----------------------------->

<span id="ctup-ads-widget-5">
		<div class="col-lg-3 col-md-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon yc" align="center">
								
					<a target="_self" href="#">  
                    	<img src="<?php if(isset($wooimg)&& !empty($wooimg)){echo base_url().'img/'.$wooimg;}else{ echo base_url().'img/woo.png';} ?>" class="img-pro">
                    </a>

			</div>
<center> 
			<h5 class="red-border-bottom"><?php if(isset($homeWOOCOMMERCE)&& !empty($homeWOOCOMMERCE))echo $homeWOOCOMMERCE;?><!---WOOCOMMERCE--></h5>  
            <?php if(isset($homeFOCUSHEADING3)&& !empty($homeFOCUSHEADING3))echo $homeFOCUSHEADING3;?> 
			<hr class="ycl"></hr>
            <p>
            	<?php if(isset($homeWOOCOMMERCEbody)&& !empty($homeWOOCOMMERCEbody))echo $homeWOOCOMMERCEbody;?>
			</p>
</center>
		</div>
</span>


<!----------------------------->

<span id="ctup-ads-widget-6">
		<div class="col-lg-3 col-md-3 col-sm-3 focus-box" data-scrollreveal="enter left after 0.15s over 1s" data-sr-init="true" data-sr-complete="true">
			<div class="service-icon rc" align="center">
								
					<a target="_self" href="#">  
                    <img src="<?php if(isset($customcontentimg)&& !empty($customcontentimg)){echo base_url().'img/'.$customcontentimg;}else{ echo base_url().'img/customcontentimg.png';} ?>" class="img-pro">
                    </a>

			</div>
<center>
			<h5 class="red-border-bottom"><?php if(isset($homeCUSTOMCONTENTBLOCKS)&& !empty($homeCUSTOMCONTENTBLOCKS))echo $homeCUSTOMCONTENTBLOCKS;?><!----CUSTOM CONTENT BLOCKS---></h5>  
             <?php if(isset($homeFOCUSHEADING4)&& !empty($homeFOCUSHEADING4))echo $homeFOCUSHEADING4;?> 
			<hr class="rcl"></hr>
            <p>
            	<?php if(isset($homeCUSTOMCONTENTBLOCKSbody)&& !empty($homeCUSTOMCONTENTBLOCKSbody))echo $homeCUSTOMCONTENTBLOCKSbody;?>
			</p>
</center>
		</div>
</span>

</div>



      </div>
     </section>

            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>   
    
    
    

  <!----------------- Testimonial and Akno-------------------------------------------------------------------------->  
  
  
  
  
     <div class="vc_row-full-width"></div>
    <div class="vc_row wpb_row vc_row-fluid " style="min-height:250px;overflow:hidden ">
      <div class="wpb_column vc_column_container vc_col-md-12 vc_col-sm-12">
        <div class="vc_column-inner ">
          <div class="wpb_wrapper">
            <section class="section9">
              <div class="container">
              	
                <!------------- Testimonial slide start--------------------->
                	<div class="vc_col-md-6 vc_col-sm-6 tm1" >
 					
                	<h2 style="color:#252525;">Announcements</h2>
                    
                    <!------------------------------------------->
                    
                    <script src="http://code.jquery.com/jquery-latest.js"></script>

					<script language="javascript">'use strict';$(function() {var width = 700; var animationSpeed = 1250; var pause = 5500; var currentSlide = 1;var $slider = $('#slider'); var $slideContainer = $('.slides', $slider); var $slides = $('.slide', $slider); var interval; function startSlider() { interval = setInterval(function() { $slideContainer.animate({'margin-left': '-='+width}, animationSpeed, function() {if (++currentSlide === $slides.length) {currentSlide = 1; $slideContainer.css('margin-left', 0); }});}, pause);} function pauseSlider() {clearInterval(interval);}$slideContainer.on('mouseenter', pauseSlider).on('mouseleave', startSlider);startSlider();});</script>
                    
                    
                    <style type="text/css">#slider {width: 100%; height: 400px; border: 3px solid #FFFFFF; border-radius: 0px; overflow: hidden; position: relative;  cursor: hand; cursor: pointer}#slider .slides {width: 2800px; height: 400px;  display: block; margin: 0; padding: 0;}#slider .slide {width: 700px; height: 400px; float: left; list-style-type: none;}.DOT161208 {position: absolute; max-width: 700px; margin: 0px;}.c39285  {position: absolute; bottom: 0px; width:100%;  padding: 12px; background-color: rgba(0, 0, 0, 0.7); color: #FFFFF; font-size:24pt; font-family:Tahoma; text-align:center; line-height:48px; z-index:33; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box;}
                    .info-testimonial img{float:left;margin:10px 0 0 20px;}
					info-testimonial span{float:left;}
                    </style>
                    
                    <div id="slider">
                    <ul class="slides">
                    	
                    
					<?php 

                                    $result = json_decode (base64_decode (curl_get2('http://www.dhakasoft.ws/anounc',array())));
                                    $DOM = new DOMDocument();
                                    $DOM->loadHTML($result[0]->announcement);
                                    $Detail = $DOM->getElementsByTagName('tr');
                                    
                                foreach($Detail as $de)
                                {
                                    $aDataTableHeaderHTML[] = trim($de->textContent);
                                }
                                $count = count($aDataTableHeaderHTML);
                                for($i=0; $i<$count; $i++)
                                {
                    ?>
                    <li class="slide slide1">
                     <div style="width: 100%;opacity: 1;display: block;position: relative;">
                                    <div id="testdiv1">
                                        <div class="owl-item tm1i" style="">
                                            <div class="ts-item-testimonial-1">
                                              <div class="client-quote"> <i class="fa fa-quote-left"></i>
                                                <blockquote>
                                                  <p>
                                                  <?php 
														echo $aDataTableHeaderHTML[$i];
													?>
                                                  </p>
                                                </blockquote>
                                              </div>
                                              
                                             <!-------------------------------------------------------------------------------->
                                             
    										 <!-------------------------------------------------------------------------------->
    											
                                            </div>
                                          </div>
                                    </div>
                            </div>
                     </li>  
                     <?php 
					 	}
					 ?>

                    


                    </ul>
                    </div>
                    </div>
                   

                    
                    
                    
                    <!---------- Testimonial slide End ---------------------------------->
                    
                    
                    
                    <!----------- Special Offer Start ---------------------------------->
                    
                    
                    <div class="vc_col-md-6 vc_col-sm-6" style="min-height:250px;float:right;">
 
                	<h2 style="color:#252525;"><?php if(isset($special_offer))  echo $special_offer;?></h2>
                    
                    
                    <style>
						.ui-widget {font-family: Verdana,Arial,sans-serif;font-size: 1.1em;}
						.ui-helper-reset {margin: 0;padding: 0;border: 0;outline: 0;line-height: 1.3;text-decoration: none;font-size: 100%;list-style: none;}
						.ts-acordion.ui-accordion .ui-accordion-header {background: #f3f3f3;font-size: 14px;font-weight: 300;line-height: 26px;border: none;-webkit-border-radius: 3px;-moz-border-radius: 3px;-ms-border-radius: 3px;-o-border-radius: 3px;border-radius: 3px;margin: 0 0 18px 0;padding: 13px 32px 13px 15px;outline: none;}
						.ui-accordion .ui-accordion-icons {padding-left: 2.2em;}
						.ui-accordion .ui-accordion-header {display: block;cursor: pointer;position: relative;margin: 2px 0 0 0;padding: .5em .5em .5em .7em;min-height: 0;font-size: 100%;}
						.ui-corner-all, .ui-corner-bottom, .ui-corner-right, .ui-corner-br {border-bottom-right-radius: 4px;}
						.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {border: 1px solid #d3d3d3;background: #e6e6e6 url("../images/ui-bg_glass_75_e6e6e6_1x400.png") 50% 50% repeat-x;font-weight: normal;color: #555555;}
					</style>
                    <!--------------------------------------------->
                    
                    <div class="ts-acordion ts-acordion-720 ui-accordion ui-widget ui-helper-reset" role="tablist">
                  <div class="acordion-content ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" style="display: block; " id="ui-id-2" aria-labelledby="ui-id-1" role="tabpanel" aria-hidden="true">
                            
                		<div class="wpb_text_column wpb_content_element ">
                    		<div class="wpb_wrapper">
                        <p>
                        	<a href="<?php if(isset($specialofferurl)) echo $specialofferurl;?>"> <img src="<?php if(isset($specialofferimg))  {echo 'img/product/'.$specialofferimg;}else{ echo 'img/noofferexist.png';}?>" class="img-responsive" /> </a>
                        </p>
            
                    		</div>
                		</div>
            		</div>

                    </div>
                    </div>
                <!------ Special Offer End ---------------------------->
                
              </div> <!------ Close Container ---------->
             </section>
           </div>
         </div>
       </div>
     </div>
    

                
                
                
                
                
    
    
    <!--==============================================================================-->
    <!------ Partner Link --------------------------------------------------------------------------------------------------------->
    <div class="vc_row-full-width"></div>
    
    
    
  </div>
  
  <?php 
			
			function curl_get2($url, array $get = NULL, array $options = array()) 
			{    
				$defaults = array(
					CURLOPT_URL => $url. (strpos($url, '?') === FALSE ? '?' : ''). http_build_query($get), 
					CURLOPT_HEADER => 0, 
					CURLOPT_RETURNTRANSFER => TRUE, 
					CURLOPT_TIMEOUT => 200
				);
				$ch = curl_init(); 
				curl_setopt_array($ch, ($options + $defaults)); 
				$result = curl_exec($ch);
				curl_close($ch);
				return $result; 
			 }
?>			 