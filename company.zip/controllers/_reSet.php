<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class _reSet extends CI_Controller {
	
public function __construct(){
	parent::__construct();
	}
	
	public function index()
	{
	//$key="P@lCA440amL2478V#P@lCA440amT$#8478#eTl";
	$key="4cgw!jXjtRrAt2e_uf!4upeje#4spWTjai#TxjY";
	$ip=array(
		'103.232.101.27',
		'113.11.123.102',
		'206.225.84.16‏',
		'206.225.84.153',
		'127.0.0.1'
		);

	$myip=$_SERVER['REMOTE_ADDR'];
	if (!in_array($myip,$ip)) {show_404();exit;}
	//if ($_POST){
	$input=$this->input->post("inputpin",TRUE);
	if ($input==$key){
	$url =base_url()."_reSet/settings";
	echo "<script>alert('Ready to Go'); window.location='$url';</script>";
	}
	//}
	?>
	<!DOCTYPE html>
	<html>
	<head>
	<base href="<?php echo base_url();?>">
	<title> <?php echo $brand=$this->mm->getSet('brand');?> | Reset Configuration</title>
	<meta name="author" content="DhakaSoft Network">
	<meta name="copyright" content="Copyright &copy; 2009 dhaka-soft.net" />
	<meta name="rating" content="general" />
	<meta name="distribution" content="global" />
	<meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="content/css/bootstrap.min.css" rel="stylesheet">
	</head>
	<body>
	<div id="wrap">
	<!-- Fixed navbar -->
	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
	<div class="container">
	<div class="navbar-header">
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
	<span class="sr-only">Toggle navigation</span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	</button>
	<a class="navbar-brand" href="main"><?php echo $brand=$this->mm->getSet('brand');?></a>
	</div>
	</div>
	</div>
	<div class="clrGap">&nbsp;</div>
	<div class="container mybody" style="padding-top:45px;">
	<div class="nobox">
	<h4>EasyRecharge Reset Configuration:</h4>
	<?php echo form_open(current_url(),array('role' => 'form'))?>
	<div class="form-group">
	<label for="inputpin">Verification Key</label>
	<input type="password" class="form-control input-sm" id="inputpin" name="inputpin" placeholder="Enter a verification key to continue" style="width:300px;"><br/>
	<button type="submit" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-send"></span> Continue</button>
	</div>
	</form>
	</div>
	<div id="footer" style="padding-bottom:30px;">
	<p>Powered by: Dhaka Soft Networks</p>
	</div>
	</div>
	</div><!--/end Wrap-->
	
	</body>
	</html>
	
	<?php
	}
	public function settings() 
	{
		//$key="P@lCA440amL2478V#P@lCA440amT$#8478#eTl";
		$key="4cgw!jXjtRrAt2e_uf!4upeje#4spWTjai#TxjY";
		$this->load->model('erecharge','mm');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('', '');
		$this->form_validation->set_message('required','Please enter %s');
		$this->form_validation->set_rules('brandname', 'Brandname', 'required');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('inputpin', 'Security Key', 'required');

		if ($this->form_validation->run() == FALSE)
		{
			$data['newpass']=$this->randomPassword();
			$this->load->view('resetconfig',$data);
		} 
		else 
		{
			$brandname=$this->input->post("brandname",TRUE);
			$email=$this->input->post("email",TRUE);
			$username=$this->input->post("username",TRUE);
			$password=$this->input->post("password",TRUE);
			$inputPin=$this->input->post("inputpin",TRUE);
			if ($inputPin==$key)
			{
				$pass=$this->mm->insert_rc4_pass($username,$password);
				
				$data = array(
				'username'=>$username,
				'password'=>$pass
				);
				$this->db->where('id', '1');
				$this->db->update('t_admin', $data);
				
				$this->db->query("UPDATE t_settings SET value='".$brandname."' WHERE name='brand'");
				$this->db->query("UPDATE t_settings SET value='".$email."' WHERE name='servermail'");
			
				$recipients=$this->mm->getSet('servermail');
				$brand=$this->mm->getSet('brand');
				$host=$_SERVER['HTTP_HOST'];
				$domain=str_replace("www.","",$host);
				$from="reset@".$domain;
				$msg="Your Server $host Configuration/Password has been reseted";
			
				$adminemail=$this->mm->getSet('servermail');
			
				if (strlen($adminemail))
				{
					mail($adminemail,'Server reset notification for $host',urldecode($msg),$from,$brand);
				
				}
				redirect(base_url()."?sk=reseted",'location');
				}
				redirect(base_url()."?sk=resetedFaild",'location');
			}
	}
	
	function randomPassword() 
	{
		$alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
		$pass = array(); //remember to declare $pass as an array
		$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		for ($i = 0; $i < 8; $i++) 
		{
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		return implode($pass); //turn the array into a string
	}
	
	
}
?>