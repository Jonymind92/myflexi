<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}

</style>


<?php 
	$ourteam = $this->db->query("select * from  t_pic where subject='ourteam'")->result();
?>

<div class="container">
  <div class="row">
    <div class="col-md-5 col-sm-5 col-xs-12">
    	<h3>Upload New Team Member</h3>
      <div class="form">
        <form action="<?php echo 'admincontroller/insert_aboutus_team'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
          	 <tr>
              <td>Name
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
					if(isset($_GET['esk'])&& !empty($_GET['esk']))echo '<label class="ems mymsg fl-r">'.$_GET['esk'].'</label>';
				?>
              <br> 
                <input type="text"  name="name"  style="width:100%;min-height:30px;font-size:16px;"><br /><br /></td>
            </tr>
             <tr>
              <td>Designation 
              
              <br> 
                <input type="text"  name="designation"  style="width:100%;min-height:30px;font-size:16px;"><br /><br /></td>
            </tr>
            <tr>
              <td>Photo
              
              <br> 
                <input type="file"  name="pic"  style="width:100%;min-height:30px;font-size:16px;"><br></td>
            </tr>
            

            
            <tr>
              <td><input type="submit" value="Save" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
  
  
  <div class="row">
    <div class="col-md-8 col-sm-8 col-xs-12">
    	<h3>Uploaded Team Member List</h3>
      <div>
        		<?php
                	if(isset($_GET['ssk'])&& !empty($_GET['ssk']))echo '<label class="ms mymsg fl-r">'.$_GET['ssk'].'</label>';
					if(isset($_GET['eesk'])&& !empty($_GET['eesk']))echo '<label class="ems mymsg fl-r">'.$_GET['eesk'].'</label>';
				?>
          <table style="width:100%;" class="table table-striped table-bordered">
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Designation</th>
              <th>Photo</th>
              <th></th>
            </tr>
            <?php 
				if(isset($ourteam)&& !empty($ourteam))
				{
					$sl=0;
					foreach($ourteam as $p)
					{
			?>
			<tr>
            	<td><?php echo ++$sl;?></td>
                <td><?php if(isset($p->name)&& !empty($p->name))echo $p->name?></td>
                <td><?php if(isset($p->value1)&& !empty($p->value1))echo $p->value1?></td>
                <td><?php if(isset($p->value2)&& !empty($p->value2)){?><img src="img/aboutus/<?php echo $p->value2?>" style="width:80px; height:80px;" /><?php }?></td>
                <td style="text-align:center;"><a href="<?php echo 'admincontroller/about_ourteam_edit_form/'.$p->value2;?>">[Edit]</a>&nbsp;&nbsp;<a href="<?php echo 'admincontroller/aboutus_member_delete/'.$p->value2;?>">[delete]</a></td>
            </tr>
            <?php 
					}
				}
			?>
            
          </table>
        
      </div>
    </div>
  </div>
  
</div>
