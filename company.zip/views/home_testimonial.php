<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<?php
	$testimonial = $this->db->query("select value from t_homedata where subject='testimonial'")->row()->value;
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
        <form action="<?php echo 'admincontroller/update_hometestimonial'?>" method="post">
          <table style="width:100%;">
            <tr>
              <td>Testimonial
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <textarea  name="testimonial" value="<?php if(isset($testimonial)&& !empty($testimonial))echo $testimonial;?> " style="width:100%;min-height:150px;height:auto;font-size:16px;"><?php if(isset($testimonial)&& !empty($testimonial))echo $testimonial;?></textarea></td>
            </tr>
            
            
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
