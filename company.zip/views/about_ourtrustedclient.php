<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}

</style>


<?php 
	$ourteam = $this->db->query("select * from  t_pic where subject='ourctrustedlient'")->result();
?>

<div class="container">
  <div class="row">
    <div class="col-md-5 col-sm-5 col-xs-12">
    	<h3>Upload New Trusted Client Image</h3>
      <div class="form">
        <form action="<?php echo 'admincontroller/insert_aboutus_trusted_client'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
			
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
					if(isset($_GET['esk'])&& !empty($_GET['esk']))echo '<label class="ems mymsg fl-r">'.$_GET['esk'].'</label>';
				?>
              <br> 
            <tr>
              <td>Photo
              
              <br> 
                <input type="file"  name="pic"  style="width:100%;min-height:30px;font-size:16px;"><br></td>
            </tr>
            

            
            <tr>
              <td><input type="submit" value="Upload" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
  
  
  <div class="row">
    <div class="col-md-5 col-sm-5 col-xs-12">
    	<h3>Uploaded Trusted Client List</h3>
      <div>
        		<?php
                	if(isset($_GET['ssk'])&& !empty($_GET['ssk']))echo '<label class="ms mymsg fl-r">'.$_GET['ssk'].'</label>';
					if(isset($_GET['eesk'])&& !empty($_GET['eesk']))echo '<label class="ems mymsg fl-r">'.$_GET['eesk'].'</label>';
				?>
          <table style="width:100%;" class="table table-striped table-bordered">
            <tr>
              <th>#</th>
              <th>Photo</th>
              <th></th>
            </tr>
            <?php 
				if(isset($ourteam)&& !empty($ourteam))
				{
					$sl=0;
					foreach($ourteam as $p)
					{
			?>
			<tr>
            	<td><?php echo ++$sl;?></td>
                <td><?php if(isset($p->value2)&& !empty($p->value2)){?><img src="img/aboutus/<?php echo $p->value2?>" style="width:80px; height:80px;" /><?php }?></td>
                <td style="text-align:center;"><a href="<?php echo 'admincontroller/aboutus_trusted_client_edit_form/'.$p->value2;?>">[Edit]</a>&nbsp;&nbsp;<a href="<?php echo 'admincontroller/aboutus_trusted_client_delete/'.$p->value2;?>">[delete]</a></td>
            </tr>
            <?php 
					}
				}
			?>
            
          </table>
        
      </div>
    </div>
  </div>
  
</div>
