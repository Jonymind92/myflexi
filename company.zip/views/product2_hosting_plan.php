<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.bgc{background:#C6FFFF}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from t_product2data")->result();
	$product2HostingPlans='';
	$product2HostingPlansbody='';
	
	$product2HostingPlans1Name='';
	$product2HostingPlans1Price='';
	$product2Hosting1processor='';
	$product2Hosting1RAM='';
	$product2Hosting1HDD='';
	$product2Hosting1OS='';
	$product2Hosting1LAN='';
	$product2Hosting1Application='';
	$product2Hosting1ConcurrentCalls='';
	$product2Hosting1Billing='';
	$product2Hosting1Apps='';
	$product2Hosting1Service='';
	
	$product2HostingPlans2Name='';
	$product2HostingPlans2Price='';
	$product2Hosting2processor='';
	$product2Hosting2RAM='';
	$product2Hosting2HDD='';
	$product2Hosting2OS='';
	$product2Hosting2LAN='';
	$product2Hosting2Application='';
	$product2Hosting2ConcurrentCalls='';
	$product2Hosting2Billing='';
	$product2Hosting2Apps='';
	$product2Hosting2Service='';
	
	$product2HostingPlans3Name='';
	$product2HostingPlans3Price='';
	$product2Hosting3processor='';
	$product2Hosting3RAM='';
	$product2Hosting3HDD='';
	$product2Hosting3OS='';
	$product2Hosting3LAN='';
	$product2Hosting3Application='';
	$product2Hosting3ConcurrentCalls='';
	$product2Hosting3Billing='';
	$product2Hosting3Apps='';
	$product2Hosting3Service='';
	
	$product2HostingPlans4Name='';
	$product2HostingPlans4Price='';
	$product2Hosting4processor='';
	$product2Hosting4RAM='';
	$product2Hosting4HDD='';
	$product2Hosting4OS='';
	$product2Hosting4LAN='';
	$product2Hosting4Application='';
	$product2Hosting4ConcurrentCalls='';
	$product2Hosting4Billing='';
	$product2Hosting4Apps='';
	$product2Hosting4Service='';
	
	$product2Hosting1buttonname='';
	$product2Hosting2buttonname='';
	$product2Hosting3buttonname='';
	$product2Hosting4buttonname='';
	
	$product2HostingPlanSharedDataUrl='';
	$product2HostingPlanVPSDataUrl='';
	$product2HostingPlanResellerDataUrl='';
	$product2HostingPlanDedicatedDataUrl='';
	
	
	//form section focus need to work, create 4 section focus in db then work 
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home Hosting Plans'){$product2HostingPlans = $set->value;}
			if($set->name == 'home Hosting Plans body'){$product2HostingPlansbody = $set->value;}
			
			if($set->name == 'home Hosting Plans1 Name'){$product2HostingPlans1Name = $set->value;}
			if($set->name == 'home Hosting Plans1 Price'){$product2HostingPlans1Price = $set->value;}
			if($set->name == 'home hosting1 processor'){$product2Hosting1processor = $set->value;}
			if($set->name == 'home hosting1 RAM'){$product2Hosting1RAM = $set->value;}
			if($set->name == 'home hosting1 HDD'){$product2Hosting1HDD = $set->value;}
			if($set->name == 'home hosting1 OS'){$product2Hosting1OS = $set->value;}
			if($set->name == 'home hosting1 LAN'){$product2Hosting1LAN = $set->value;}
			if($set->name == 'home hosting1 Application'){$product2Hosting1Application = $set->value;}
			if($set->name == 'home hosting1 Concurrent Calls'){$product2Hosting1ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting1 Billing'){$product2Hosting1Billing = $set->value;}
			if($set->name == 'home hosting1 Apps'){$product2Hosting1Apps = $set->value;}
			if($set->name == 'home hosting1 Service'){$product2Hosting1Service = $set->value;}
			
			if($set->name == 'home Hosting Plans2 Name'){$product2HostingPlans2Name = $set->value;}
			if($set->name == 'home Hosting Plans2 Price'){$product2HostingPlans2Price = $set->value;}
			if($set->name == 'home hosting2 processor'){$product2Hosting2processor = $set->value;}
			if($set->name == 'home hosting2 RAM'){$product2Hosting2RAM = $set->value;}
			if($set->name == 'home hosting2 HDD'){$product2Hosting2HDD = $set->value;}
			if($set->name == 'home hosting2 OS'){$product2Hosting2OS = $set->value;}
			if($set->name == 'home hosting2 LAN'){$product2Hosting2LAN = $set->value;}
			if($set->name == 'home hosting2 Application'){$product2Hosting2Application = $set->value;}
			if($set->name == 'home hosting2 Concurrent Calls'){$product2Hosting2ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting2 Billing'){$product2Hosting2Billing = $set->value;}
			if($set->name == 'home hosting2 Apps'){$product2Hosting2Apps = $set->value;}
			if($set->name == 'home hosting2 Service'){$product2Hosting2Service = $set->value;}
			
			if($set->name == 'home Hosting Plans3 Name'){$product2HostingPlans3Name = $set->value;}
			if($set->name == 'home Hosting Plans3 Price'){$product2HostingPlans3Price = $set->value;}
			if($set->name == 'home hosting3 processor'){$product2Hosting3processor = $set->value;}
			if($set->name == 'home hosting3 RAM'){$product2Hosting3RAM = $set->value;}
			if($set->name == 'home hosting3 HDD'){$product2Hosting3HDD = $set->value;}
			if($set->name == 'home hosting3 OS'){$product2Hosting3OS = $set->value;}
			if($set->name == 'home hosting3 LAN'){$product2Hosting3LAN = $set->value;}
			if($set->name == 'home hosting3 Application'){$product2Hosting3Application = $set->value;}
			if($set->name == 'home hosting3 Concurrent Calls'){$product2Hosting3ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting3 Billing'){$product2Hosting3Billing = $set->value;}
			if($set->name == 'home hosting3 Apps'){$product2Hosting3Apps = $set->value;}
			if($set->name == 'home hosting3 Service'){$product2Hosting3Service = $set->value;}
			
			if($set->name == 'home Hosting Plans4 Name'){$product2HostingPlans4Name = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$product2HostingPlans4Price = $set->value;}
			if($set->name == 'home hosting4 processor'){$product2Hosting4processor = $set->value;}
			if($set->name == 'home hosting4 RAM'){$product2Hosting4RAM = $set->value;}
			if($set->name == 'home hosting4 HDD'){$product2Hosting4HDD = $set->value;}
			if($set->name == 'home hosting4 OS'){$product2Hosting4OS = $set->value;}
			if($set->name == 'home hosting4 LAN'){$product2Hosting4LAN = $set->value;}
			if($set->name == 'home hosting4 Application'){$product2Hosting4Application = $set->value;}
			if($set->name == 'home hosting4 Concurrent Calls'){$product2Hosting4ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting4 Billing'){$product2Hosting4Billing = $set->value;}
			if($set->name == 'home hosting4 Apps'){$product2Hosting4Apps = $set->value;}
			if($set->name == 'home hosting4 Service'){$product2Hosting4Service = $set->value;}
			
			if($set->name == 'homehosting1buttonname'){$product2Hosting1buttonname = $set->value;}
			if($set->name == 'homehosting2buttonname'){$product2Hosting2buttonname = $set->value;}
			if($set->name == 'homehosting3buttonname'){$product2Hosting3buttonname = $set->value;}
			if($set->name == 'homehosting4buttonname'){$product2Hosting4buttonname = $set->value;}
			
			if($set->name == 'homeHostingPlanSharedDataUrl'){ $product2HostingPlanSharedDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanVPSDataUrl'){ $product2HostingPlanVPSDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanResellerDataUrl'){ $product2HostingPlanResellerDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanDedicatedDataUrl'){ $product2HostingPlanDedicatedDataUrl = $set->value;}
			
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Easy Billing Hosting Plans</h3>
        <form action="<?php echo 'admincontroller/update_easy_billing_hosting_plan'?>" method="post">
          <table style="width:100%;">
            <tr>
              <td>Hosting Plans Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="homeHostingPlans" value="<?php if(isset($product2HostingPlans)&& !empty($product2HostingPlans))echo $product2HostingPlans;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            <tr>
              <td><br>Hosting Plans Description<br>
                <textarea name="homeHostingPlansbody" value="<?php if(isset($product2HostingPlansbody)&& !empty($product2HostingPlansbody))echo $product2HostingPlansbody;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($product2HostingPlansbody)&& !empty($product2HostingPlansbody))echo $product2HostingPlansbody;?></textarea>
                </td>
            </tr>
            <tr>
              	<td>
        <table>
        	<tr>
            	<th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>
            <tr>
            	<th>Plan1</th>
                <th>Plan2</th>
                <th>Plan3</th>
                <th>Plan4</th>
            </tr>              
            <tr>
                <td><br>Price<br /><input type="text" name="homeHostingPlans1Price" value="<?php if(isset($product2HostingPlans1Price))echo $product2HostingPlans1Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans2Price" value="<?php if(isset($product2HostingPlans2Price))echo $product2HostingPlans2Price ?>" class="bgc"/></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans3Price" value="<?php if(isset($product2HostingPlans3Price))echo $product2HostingPlans3Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans4Price" value="<?php if(isset($product2HostingPlans4Price))echo $product2HostingPlans4Price ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans1Name" value="<?php if(isset($product2HostingPlans1Name))echo $product2HostingPlans1Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans2Name" value="<?php if(isset($product2HostingPlans2Name))echo $product2HostingPlans2Name ?>" class="bgc"/></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans3Name" value="<?php if(isset($product2HostingPlans3Name))echo $product2HostingPlans3Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans4Name" value="<?php if(isset($product2HostingPlans4Name))echo $product2HostingPlans4Name ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>processor<br /><input type="text" name="homehosting1processor" value="<?php if(isset($product2Hosting1processor))echo $product2Hosting1processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting2processor" value="<?php if(isset($product2Hosting2processor))echo $product2Hosting2processor ?>" class="bgc"/></td>
                <td><br>processor<br /><input type="text" name="homehosting3processor" value="<?php if(isset($product2Hosting3processor))echo $product2Hosting3processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting4processor" value="<?php if(isset($product2Hosting4processor))echo $product2Hosting4processor ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>RAM<br /><input type="text" name="homehosting1RAM" value="<?php if(isset($product2Hosting1RAM))echo $product2Hosting1RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting2RAM" value="<?php if(isset($product2Hosting2RAM))echo $product2Hosting2RAM ?>" class="bgc"/></td>
                <td><br>RAM<br /><input type="text" name="homehosting3RAM" value="<?php if(isset($product2Hosting3RAM))echo $product2Hosting3RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting4RAM" value="<?php if(isset($product2Hosting4RAM))echo $product2Hosting4RAM ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>HDD<br /><input type="text" name="homehosting1HDD" value="<?php if(isset($product2Hosting1HDD))echo $product2Hosting1HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting2HDD" value="<?php if(isset($product2Hosting2HDD))echo $product2Hosting2HDD ?>" class="bgc"/></td>
                <td><br>HDD<br /><input type="text" name="homehosting3HDD" value="<?php if(isset($product2Hosting3HDD))echo $product2Hosting3HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting4HDD" value="<?php if(isset($product2Hosting4HDD))echo $product2Hosting4HDD ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>OS<br /><input type="text" name="homehosting1OS" value="<?php if(isset($product2Hosting1OS))echo $product2Hosting1OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting2OS" value="<?php if(isset($product2Hosting2OS))echo $product2Hosting2OS ?>" class="bgc"/></td>
                <td><br>OS<br /><input type="text" name="homehosting3OS" value="<?php if(isset($product2Hosting3OS))echo $product2Hosting3OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting4OS" value="<?php if(isset($product2Hosting4OS))echo $product2Hosting4OS ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>LAN<br /><input type="text" name="homehosting1LAN" value="<?php if(isset($product2Hosting1LAN))echo $product2Hosting1LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting2LAN" value="<?php if(isset($product2Hosting2LAN))echo $product2Hosting2LAN ?>" class="bgc"/></td>
                <td><br>LAN<br /><input type="text" name="homehosting3LAN" value="<?php if(isset($product2Hosting3LAN))echo $product2Hosting3LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting4LAN" value="<?php if(isset($product2Hosting4LAN))echo $product2Hosting4LAN ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Application<br /><input type="text" name="homehosting1Application" value="<?php if(isset($product2Hosting1Application))echo $product2Hosting1Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting2Application" value="<?php if(isset($product2Hosting2Application))echo $product2Hosting2Application ?>" class="bgc"/></td>
                <td><br>Application<br /><input type="text" name="homehosting3Application" value="<?php if(isset($product2Hosting3Application))echo $product2Hosting3Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting4Application" value="<?php if(isset($product2Hosting4Application))echo $product2Hosting4Application ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting1ConcurrentCalls" value="<?php if(isset($product2Hosting1ConcurrentCalls))echo $product2Hosting1ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting2ConcurrentCalls" value="<?php if(isset($product2Hosting2ConcurrentCalls))echo $product2Hosting2ConcurrentCalls ?>" class="bgc"/></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting3ConcurrentCalls" value="<?php if(isset($product2Hosting3ConcurrentCalls))echo $product2Hosting3ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting4ConcurrentCalls" value="<?php if(isset($product2Hosting4ConcurrentCalls))echo $product2Hosting4ConcurrentCalls ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Billing<br /><input type="text" name="homehosting1Billing" value="<?php if(isset($product2Hosting1Billing))echo $product2Hosting1Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting2Billing" value="<?php if(isset($product2Hosting2Billing))echo $product2Hosting2Billing ?>" class="bgc"/></td>
                <td><br>Billing<br /><input type="text" name="homehosting3Billing" value="<?php if(isset($product2Hosting3Billing))echo $product2Hosting3Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting4Billing" value="<?php if(isset($product2Hosting4Billing))echo $product2Hosting4Billing ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Apps<br /><input type="text" name="homehosting1Apps" value="<?php if(isset($product2Hosting1Apps))echo $product2Hosting1Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting2Apps" value="<?php if(isset($product2Hosting2Apps))echo $product2Hosting2Apps ?>" class="bgc"/></td>
                <td><br>Apps<br /><input type="text" name="homehosting3Apps" value="<?php if(isset($product2Hosting3Apps))echo $product2Hosting3Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting4Apps" value="<?php if(isset($product2Hosting4Apps))echo $product2Hosting4Apps ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Service<br /><input type="text" name="homehosting1Service" value="<?php if(isset($product2Hosting1Service))echo $product2Hosting1Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting2Service" value="<?php if(isset($product2Hosting2Service))echo $product2Hosting2Service ?>" class="bgc"/></td>
                <td><br>Service<br /><input type="text" name="homehosting3Service" value="<?php if(isset($product2Hosting3Service))echo $product2Hosting3Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting4Service" value="<?php if(isset($product2Hosting4Service))echo $product2Hosting4Service ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Name<br /><input type="text" name="homehosting1buttonname" value="<?php if(isset($product2Hosting1buttonname))echo $product2Hosting1buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting2buttonname" value="<?php if(isset($product2Hosting2buttonname))echo $product2Hosting2buttonname ?>" class="bgc"/></td>
                <td><br>Button Name<br /><input type="text" name="homehosting3buttonname" value="<?php if(isset($product2Hosting3buttonname))echo $product2Hosting3buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting4buttonname" value="<?php if(isset($product2Hosting4buttonname))echo $product2Hosting4buttonname ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanSharedDataUrl" value="<?php if(isset($product2HostingPlanSharedDataUrl))echo $product2HostingPlanSharedDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanVPSDataUrl" value="<?php if(isset($product2HostingPlanVPSDataUrl))echo $product2HostingPlanVPSDataUrl ?>" class="bgc"/></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanResellerDataUrl" value="<?php if(isset($product2HostingPlanResellerDataUrl))echo $product2HostingPlanResellerDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanDedicatedDataUrl" value="<?php if(isset($product2HostingPlanDedicatedDataUrl))echo $product2HostingPlanDedicatedDataUrl ?>" class="bgc"/></td>
            </tr>
        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
