<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>
<script>
$( document ).ready(function() {
    function readURL(input) 
	{

		if (input.files && input.files[0]) 
		{
			var reader = new FileReader();
	
			reader.onload = function (e) 
			{
				$('#blah').attr('src', e.target.result);
			}
	
			reader.readAsDataURL(input.files[0]);
		}
	}
	
	
	$("#imgInp").change(function(){
		readURL(this);
	});

});

</script>
<?php
	$specialoffer = $this->db->query("select * from t_homedata where subject='homespecialoffer'")->result();
	$header='';
	$image='';
	foreach($specialoffer as $k)
	{
		if($k->name=='special_offer')
		{
			$header=$k->value;
		}
		if($k->name=='specialofferimg')
		{
			$image=$k->value;
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
      <div class="form">
        <form action="<?php echo 'admincontroller/update_home_special_officer'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Special Offer Header
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="header" value="<?php if(isset($header)&& !empty($header))echo $header;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
              
            <tr>   
              <td><br />Special Offer image (600x300)
              <br> 
                <input id="imgInp" type="file" name="pic">
                </td>
            </tr>
            <tr>   
                <td>
            		<img id="blah" src="<?php if(isset($image)&&!empty($image)){ echo 'img/product/'.$image;}else{echo 'img/upload_offer_img.png';}?>"  style="border:5px solid #CCCCCC; width:450px !important;height:110px">  
                </td>
            </tr>
            <tr>
              <td>Link Url
              <br>
                <input type="text"  name="linkurl" value="<?php if(isset($linkurl)&& !empty($linkurl))echo $linkurl;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
