<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.fl-r{float:right;m}
</style>

<div class="container">
  <div class="row">
    <div class="col-md-5 col-sm-5 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Easy Recharge Page Banner</h3>
      <?php
    	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
		if(isset($_GET['esk'])&& !empty($_GET['esk']))echo '<label class="ems mymsg fl-r">'.$_GET['esk'].'</label>';
	  ?>
        <form action="<?php echo 'admincontroller/update_easy_recharge_banner'?>" method="post" enctype="multipart/form-data">
          <table style="width:100%;">
            <tr>
              <td>Banner Image&nbsp;(1920x650px) 
              <br> 
                <input type="file"  name="pic"></td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
