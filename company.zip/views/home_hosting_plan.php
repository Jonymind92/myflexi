<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.bgc{background:#C6FFFF}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from t_homedata")->result();
	$homeHostingPlans='';
	$homeHostingPlansbody='';
	
	$homeHostingPlans1Name='';
	$homeHostingPlans1Price='';
	$homehosting1processor='';
	$homehosting1RAM='';
	$homehosting1HDD='';
	$homehosting1OS='';
	$homehosting1LAN='';
	$homehosting1Application='';
	$homehosting1ConcurrentCalls='';
	$homehosting1Billing='';
	$homehosting1Apps='';
	$homehosting1Service='';
	
	$homeHostingPlans2Name='';
	$homeHostingPlans2Price='';
	$homehosting2processor='';
	$homehosting2RAM='';
	$homehosting2HDD='';
	$homehosting2OS='';
	$homehosting2LAN='';
	$homehosting2Application='';
	$homehosting2ConcurrentCalls='';
	$homehosting2Billing='';
	$homehosting2Apps='';
	$homehosting2Service='';
	
	$homeHostingPlans3Name='';
	$homeHostingPlans3Price='';
	$homehosting3processor='';
	$homehosting3RAM='';
	$homehosting3HDD='';
	$homehosting3OS='';
	$homehosting3LAN='';
	$homehosting3Application='';
	$homehosting3ConcurrentCalls='';
	$homehosting3Billing='';
	$homehosting3Apps='';
	$homehosting3Service='';
	
	$homeHostingPlans4Name='';
	$homeHostingPlans4Price='';
	$homehosting4processor='';
	$homehosting4RAM='';
	$homehosting4HDD='';
	$homehosting4OS='';
	$homehosting4LAN='';
	$homehosting4Application='';
	$homehosting4ConcurrentCalls='';
	$homehosting4Billing='';
	$homehosting4Apps='';
	$homehosting4Service='';
	
	$homehosting1buttonname='';
	$homehosting2buttonname='';
	$homehosting3buttonname='';
	$homehosting4buttonname='';
	
	$homeHostingPlanSharedDataUrl='';
	$homeHostingPlanVPSDataUrl='';
	$homeHostingPlanResellerDataUrl='';
	$homeHostingPlanDedicatedDataUrl='';
	
	
	//form section focus need to work, create 4 section focus in db then work 
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home Hosting Plans'){$homeHostingPlans = $set->value;}
			if($set->name == 'home Hosting Plans body'){$homeHostingPlansbody = $set->value;}
			
			if($set->name == 'home Hosting Plans1 Name'){$homeHostingPlans1Name = $set->value;}
			if($set->name == 'home Hosting Plans1 Price'){$homeHostingPlans1Price = $set->value;}
			if($set->name == 'home hosting1 processor'){$homehosting1processor = $set->value;}
			if($set->name == 'home hosting1 RAM'){$homehosting1RAM = $set->value;}
			if($set->name == 'home hosting1 HDD'){$homehosting1HDD = $set->value;}
			if($set->name == 'home hosting1 OS'){$homehosting1OS = $set->value;}
			if($set->name == 'home hosting1 LAN'){$homehosting1LAN = $set->value;}
			if($set->name == 'home hosting1 Application'){$homehosting1Application = $set->value;}
			if($set->name == 'home hosting1 Concurrent Calls'){$homehosting1ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting1 Billing'){$homehosting1Billing = $set->value;}
			if($set->name == 'home hosting1 Apps'){$homehosting1Apps = $set->value;}
			if($set->name == 'home hosting1 Service'){$homehosting1Service = $set->value;}
			
			if($set->name == 'home Hosting Plans2 Name'){$homeHostingPlans2Name = $set->value;}
			if($set->name == 'home Hosting Plans2 Price'){$homeHostingPlans2Price = $set->value;}
			if($set->name == 'home hosting2 processor'){$homehosting2processor = $set->value;}
			if($set->name == 'home hosting2 RAM'){$homehosting2RAM = $set->value;}
			if($set->name == 'home hosting2 HDD'){$homehosting2HDD = $set->value;}
			if($set->name == 'home hosting2 OS'){$homehosting2OS = $set->value;}
			if($set->name == 'home hosting2 LAN'){$homehosting2LAN = $set->value;}
			if($set->name == 'home hosting2 Application'){$homehosting2Application = $set->value;}
			if($set->name == 'home hosting2 Concurrent Calls'){$homehosting2ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting2 Billing'){$homehosting2Billing = $set->value;}
			if($set->name == 'home hosting2 Apps'){$homehosting2Apps = $set->value;}
			if($set->name == 'home hosting2 Service'){$homehosting2Service = $set->value;}
			
			if($set->name == 'home Hosting Plans3 Name'){$homeHostingPlans3Name = $set->value;}
			if($set->name == 'home Hosting Plans3 Price'){$homeHostingPlans3Price = $set->value;}
			if($set->name == 'home hosting3 processor'){$homehosting3processor = $set->value;}
			if($set->name == 'home hosting3 RAM'){$homehosting3RAM = $set->value;}
			if($set->name == 'home hosting3 HDD'){$homehosting3HDD = $set->value;}
			if($set->name == 'home hosting3 OS'){$homehosting3OS = $set->value;}
			if($set->name == 'home hosting3 LAN'){$homehosting3LAN = $set->value;}
			if($set->name == 'home hosting3 Application'){$homehosting3Application = $set->value;}
			if($set->name == 'home hosting3 Concurrent Calls'){$homehosting3ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting3 Billing'){$homehosting3Billing = $set->value;}
			if($set->name == 'home hosting3 Apps'){$homehosting3Apps = $set->value;}
			if($set->name == 'home hosting3 Service'){$homehosting3Service = $set->value;}
			
			if($set->name == 'home Hosting Plans4 Name'){$homeHostingPlans4Name = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$homeHostingPlans4Price = $set->value;}
			if($set->name == 'home hosting4 processor'){$homehosting4processor = $set->value;}
			if($set->name == 'home hosting4 RAM'){$homehosting4RAM = $set->value;}
			if($set->name == 'home hosting4 HDD'){$homehosting4HDD = $set->value;}
			if($set->name == 'home hosting4 OS'){$homehosting4OS = $set->value;}
			if($set->name == 'home hosting4 LAN'){$homehosting4LAN = $set->value;}
			if($set->name == 'home hosting4 Application'){$homehosting4Application = $set->value;}
			if($set->name == 'home hosting4 Concurrent Calls'){$homehosting4ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting4 Billing'){$homehosting4Billing = $set->value;}
			if($set->name == 'home hosting4 Apps'){$homehosting4Apps = $set->value;}
			if($set->name == 'home hosting4 Service'){$homehosting4Service = $set->value;}
			
			if($set->name == 'homehosting1buttonname'){$homehosting1buttonname = $set->value;}
			if($set->name == 'homehosting2buttonname'){$homehosting2buttonname = $set->value;}
			if($set->name == 'homehosting3buttonname'){$homehosting3buttonname = $set->value;}
			if($set->name == 'homehosting4buttonname'){$homehosting4buttonname = $set->value;}
			
			if($set->name == 'homeHostingPlanSharedDataUrl'){ $homeHostingPlanSharedDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanVPSDataUrl'){ $homeHostingPlanVPSDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanResellerDataUrl'){ $homeHostingPlanResellerDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanDedicatedDataUrl'){ $homeHostingPlanDedicatedDataUrl = $set->value;}
			
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Home page Hosting Plans</h3>
        <form action="<?php echo 'admincontroller/update_hosting_plan'?>" method="post">
          <table style="width:100%;">
            <tr>
              <td>Hosting Plans Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="homeHostingPlans" value="<?php if(isset($homeHostingPlans)&& !empty($homeHostingPlans))echo $homeHostingPlans;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            <tr>
              <td><br>Hosting Plans Description<br>
                <textarea name="homeHostingPlansbody" value="<?php if(isset($homeHostingPlansbody)&& !empty($homeHostingPlansbody))echo $homeHostingPlansbody;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($homeHostingPlansbody)&& !empty($homeHostingPlansbody))echo $homeHostingPlansbody;?></textarea>
                </td>
            </tr>
            <tr>
              	<td>
        <table>
        	<tr>
            	<th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>
            <tr>
            	<th>Plan1</th>
                <th>Plan2</th>
                <th>Plan3</th>
                <th>Plan4</th>
            </tr>              
            <tr>
                <td><br>Price<br /><input type="text" name="homeHostingPlans1Price" value="<?php if(isset($homeHostingPlans1Price))echo $homeHostingPlans1Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans2Price" value="<?php if(isset($homeHostingPlans2Price))echo $homeHostingPlans2Price ?>" class="bgc"/></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans3Price" value="<?php if(isset($homeHostingPlans3Price))echo $homeHostingPlans3Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans4Price" value="<?php if(isset($homeHostingPlans4Price))echo $homeHostingPlans4Price ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans1Name" value="<?php if(isset($homeHostingPlans1Name))echo $homeHostingPlans1Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans2Name" value="<?php if(isset($homeHostingPlans2Name))echo $homeHostingPlans2Name ?>" class="bgc"/></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans3Name" value="<?php if(isset($homeHostingPlans3Name))echo $homeHostingPlans3Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans4Name" value="<?php if(isset($homeHostingPlans4Name))echo $homeHostingPlans4Name ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>processor<br /><input type="text" name="homehosting1processor" value="<?php if(isset($homehosting1processor))echo $homehosting1processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting2processor" value="<?php if(isset($homehosting2processor))echo $homehosting2processor ?>" class="bgc"/></td>
                <td><br>processor<br /><input type="text" name="homehosting3processor" value="<?php if(isset($homehosting3processor))echo $homehosting3processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting4processor" value="<?php if(isset($homehosting4processor))echo $homehosting4processor ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>RAM<br /><input type="text" name="homehosting1RAM" value="<?php if(isset($homehosting1RAM))echo $homehosting1RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting2RAM" value="<?php if(isset($homehosting2RAM))echo $homehosting2RAM ?>" class="bgc"/></td>
                <td><br>RAM<br /><input type="text" name="homehosting3RAM" value="<?php if(isset($homehosting3RAM))echo $homehosting3RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting4RAM" value="<?php if(isset($homehosting4RAM))echo $homehosting4RAM ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>HDD<br /><input type="text" name="homehosting1HDD" value="<?php if(isset($homehosting1HDD))echo $homehosting1HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting2HDD" value="<?php if(isset($homehosting2HDD))echo $homehosting2HDD ?>" class="bgc"/></td>
                <td><br>HDD<br /><input type="text" name="homehosting3HDD" value="<?php if(isset($homehosting3HDD))echo $homehosting3HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting4HDD" value="<?php if(isset($homehosting4HDD))echo $homehosting4HDD ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>OS<br /><input type="text" name="homehosting1OS" value="<?php if(isset($homehosting1OS))echo $homehosting1OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting2OS" value="<?php if(isset($homehosting2OS))echo $homehosting2OS ?>" class="bgc"/></td>
                <td><br>OS<br /><input type="text" name="homehosting3OS" value="<?php if(isset($homehosting3OS))echo $homehosting3OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting4OS" value="<?php if(isset($homehosting4OS))echo $homehosting4OS ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>LAN<br /><input type="text" name="homehosting1LAN" value="<?php if(isset($homehosting1LAN))echo $homehosting1LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting2LAN" value="<?php if(isset($homehosting2LAN))echo $homehosting2LAN ?>" class="bgc"/></td>
                <td><br>LAN<br /><input type="text" name="homehosting3LAN" value="<?php if(isset($homehosting3LAN))echo $homehosting3LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting4LAN" value="<?php if(isset($homehosting4LAN))echo $homehosting4LAN ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Application<br /><input type="text" name="homehosting1Application" value="<?php if(isset($homehosting1Application))echo $homehosting1Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting2Application" value="<?php if(isset($homehosting2Application))echo $homehosting2Application ?>" class="bgc"/></td>
                <td><br>Application<br /><input type="text" name="homehosting3Application" value="<?php if(isset($homehosting3Application))echo $homehosting3Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting4Application" value="<?php if(isset($homehosting4Application))echo $homehosting4Application ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting1ConcurrentCalls" value="<?php if(isset($homehosting1ConcurrentCalls))echo $homehosting1ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting2ConcurrentCalls" value="<?php if(isset($homehosting2ConcurrentCalls))echo $homehosting2ConcurrentCalls ?>" class="bgc"/></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting3ConcurrentCalls" value="<?php if(isset($homehosting3ConcurrentCalls))echo $homehosting3ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting4ConcurrentCalls" value="<?php if(isset($homehosting4ConcurrentCalls))echo $homehosting4ConcurrentCalls ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Billing<br /><input type="text" name="homehosting1Billing" value="<?php if(isset($homehosting1Billing))echo $homehosting1Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting2Billing" value="<?php if(isset($homehosting2Billing))echo $homehosting2Billing ?>" class="bgc"/></td>
                <td><br>Billing<br /><input type="text" name="homehosting3Billing" value="<?php if(isset($homehosting3Billing))echo $homehosting3Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting4Billing" value="<?php if(isset($homehosting4Billing))echo $homehosting4Billing ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Apps<br /><input type="text" name="homehosting1Apps" value="<?php if(isset($homehosting1Apps))echo $homehosting1Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting2Apps" value="<?php if(isset($homehosting2Apps))echo $homehosting2Apps ?>" class="bgc"/></td>
                <td><br>Apps<br /><input type="text" name="homehosting3Apps" value="<?php if(isset($homehosting3Apps))echo $homehosting3Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting4Apps" value="<?php if(isset($homehosting4Apps))echo $homehosting4Apps ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Service<br /><input type="text" name="homehosting1Service" value="<?php if(isset($homehosting1Service))echo $homehosting1Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting2Service" value="<?php if(isset($homehosting2Service))echo $homehosting2Service ?>" class="bgc"/></td>
                <td><br>Service<br /><input type="text" name="homehosting3Service" value="<?php if(isset($homehosting3Service))echo $homehosting3Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting4Service" value="<?php if(isset($homehosting4Service))echo $homehosting4Service ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Name<br /><input type="text" name="homehosting1buttonname" value="<?php if(isset($homehosting1buttonname))echo $homehosting1buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting2buttonname" value="<?php if(isset($homehosting2buttonname))echo $homehosting2buttonname ?>" class="bgc"/></td>
                <td><br>Button Name<br /><input type="text" name="homehosting3buttonname" value="<?php if(isset($homehosting3buttonname))echo $homehosting3buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting4buttonname" value="<?php if(isset($homehosting4buttonname))echo $homehosting4buttonname ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanSharedDataUrl" value="<?php if(isset($homeHostingPlanSharedDataUrl))echo $homeHostingPlanSharedDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanVPSDataUrl" value="<?php if(isset($homeHostingPlanVPSDataUrl))echo $homeHostingPlanVPSDataUrl ?>" class="bgc"/></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanResellerDataUrl" value="<?php if(isset($homeHostingPlanResellerDataUrl))echo $homeHostingPlanResellerDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanDedicatedDataUrl" value="<?php if(isset($homeHostingPlanDedicatedDataUrl))echo $homeHostingPlanDedicatedDataUrl ?>" class="bgc"/></td>
            </tr>
        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
