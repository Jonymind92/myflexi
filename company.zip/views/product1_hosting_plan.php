<link rel="stylesheet" href="css/mystyle.css" />
<script src="js/myjs.js"></script>
<style>
.form {
	min-width: 250px;
	min-height: 250px;
	padding: 50px 50px;
	margin-bottom: 50px;
}
.bgc{background:#C6FFFF}
.fl-r{float:right;m}
</style>
<?php
	$settingdata = $this->db->query("select * from t_productdata")->result();
	$product1HostingPlans='';
	$product1HostingPlansbody='';
	
	$product1HostingPlans1Name='';
	$product1HostingPlans1Price='';
	$product1Hosting1processor='';
	$product1Hosting1RAM='';
	$product1Hosting1HDD='';
	$product1Hosting1OS='';
	$product1Hosting1LAN='';
	$product1Hosting1Application='';
	$product1Hosting1ConcurrentCalls='';
	$product1Hosting1Billing='';
	$product1Hosting1Apps='';
	$product1Hosting1Service='';
	
	$product1HostingPlans2Name='';
	$product1HostingPlans2Price='';
	$product1Hosting2processor='';
	$product1Hosting2RAM='';
	$product1Hosting2HDD='';
	$product1Hosting2OS='';
	$product1Hosting2LAN='';
	$product1Hosting2Application='';
	$product1Hosting2ConcurrentCalls='';
	$product1Hosting2Billing='';
	$product1Hosting2Apps='';
	$product1Hosting2Service='';
	
	$product1HostingPlans3Name='';
	$product1HostingPlans3Price='';
	$product1Hosting3processor='';
	$product1Hosting3RAM='';
	$product1Hosting3HDD='';
	$product1Hosting3OS='';
	$product1Hosting3LAN='';
	$product1Hosting3Application='';
	$product1Hosting3ConcurrentCalls='';
	$product1Hosting3Billing='';
	$product1Hosting3Apps='';
	$product1Hosting3Service='';
	
	$product1HostingPlans4Name='';
	$product1HostingPlans4Price='';
	$product1Hosting4processor='';
	$product1Hosting4RAM='';
	$product1Hosting4HDD='';
	$product1Hosting4OS='';
	$product1Hosting4LAN='';
	$product1Hosting4Application='';
	$product1Hosting4ConcurrentCalls='';
	$product1Hosting4Billing='';
	$product1Hosting4Apps='';
	$product1Hosting4Service='';
	
	$product1Hosting1buttonname='';
	$product1Hosting2buttonname='';
	$product1Hosting3buttonname='';
	$product1Hosting4buttonname='';
	
	$product1HostingPlanSharedDataUrl='';
	$product1HostingPlanVPSDataUrl='';
	$product1HostingPlanResellerDataUrl='';
	$product1HostingPlanDedicatedDataUrl='';
	
	
	//form section focus need to work, create 4 section focus in db then work 
	if(isset($settingdata)&& !empty($settingdata))
	{
		foreach($settingdata as $set)
		{
			if($set->name == 'home Hosting Plans'){$product1HostingPlans = $set->value;}
			if($set->name == 'home Hosting Plans body'){$product1HostingPlansbody = $set->value;}
			
			if($set->name == 'home Hosting Plans1 Name'){$product1HostingPlans1Name = $set->value;}
			if($set->name == 'home Hosting Plans1 Price'){$product1HostingPlans1Price = $set->value;}
			if($set->name == 'home hosting1 processor'){$product1Hosting1processor = $set->value;}
			if($set->name == 'home hosting1 RAM'){$product1Hosting1RAM = $set->value;}
			if($set->name == 'home hosting1 HDD'){$product1Hosting1HDD = $set->value;}
			if($set->name == 'home hosting1 OS'){$product1Hosting1OS = $set->value;}
			if($set->name == 'home hosting1 LAN'){$product1Hosting1LAN = $set->value;}
			if($set->name == 'home hosting1 Application'){$product1Hosting1Application = $set->value;}
			if($set->name == 'home hosting1 Concurrent Calls'){$product1Hosting1ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting1 Billing'){$product1Hosting1Billing = $set->value;}
			if($set->name == 'home hosting1 Apps'){$product1Hosting1Apps = $set->value;}
			if($set->name == 'home hosting1 Service'){$product1Hosting1Service = $set->value;}
			
			if($set->name == 'home Hosting Plans2 Name'){$product1HostingPlans2Name = $set->value;}
			if($set->name == 'home Hosting Plans2 Price'){$product1HostingPlans2Price = $set->value;}
			if($set->name == 'home hosting2 processor'){$product1Hosting2processor = $set->value;}
			if($set->name == 'home hosting2 RAM'){$product1Hosting2RAM = $set->value;}
			if($set->name == 'home hosting2 HDD'){$product1Hosting2HDD = $set->value;}
			if($set->name == 'home hosting2 OS'){$product1Hosting2OS = $set->value;}
			if($set->name == 'home hosting2 LAN'){$product1Hosting2LAN = $set->value;}
			if($set->name == 'home hosting2 Application'){$product1Hosting2Application = $set->value;}
			if($set->name == 'home hosting2 Concurrent Calls'){$product1Hosting2ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting2 Billing'){$product1Hosting2Billing = $set->value;}
			if($set->name == 'home hosting2 Apps'){$product1Hosting2Apps = $set->value;}
			if($set->name == 'home hosting2 Service'){$product1Hosting2Service = $set->value;}
			
			if($set->name == 'home Hosting Plans3 Name'){$product1HostingPlans3Name = $set->value;}
			if($set->name == 'home Hosting Plans3 Price'){$product1HostingPlans3Price = $set->value;}
			if($set->name == 'home hosting3 processor'){$product1Hosting3processor = $set->value;}
			if($set->name == 'home hosting3 RAM'){$product1Hosting3RAM = $set->value;}
			if($set->name == 'home hosting3 HDD'){$product1Hosting3HDD = $set->value;}
			if($set->name == 'home hosting3 OS'){$product1Hosting3OS = $set->value;}
			if($set->name == 'home hosting3 LAN'){$product1Hosting3LAN = $set->value;}
			if($set->name == 'home hosting3 Application'){$product1Hosting3Application = $set->value;}
			if($set->name == 'home hosting3 Concurrent Calls'){$product1Hosting3ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting3 Billing'){$product1Hosting3Billing = $set->value;}
			if($set->name == 'home hosting3 Apps'){$product1Hosting3Apps = $set->value;}
			if($set->name == 'home hosting3 Service'){$product1Hosting3Service = $set->value;}
			
			if($set->name == 'home Hosting Plans4 Name'){$product1HostingPlans4Name = $set->value;}
			if($set->name == 'home Hosting Plans4 Price'){$product1HostingPlans4Price = $set->value;}
			if($set->name == 'home hosting4 processor'){$product1Hosting4processor = $set->value;}
			if($set->name == 'home hosting4 RAM'){$product1Hosting4RAM = $set->value;}
			if($set->name == 'home hosting4 HDD'){$product1Hosting4HDD = $set->value;}
			if($set->name == 'home hosting4 OS'){$product1Hosting4OS = $set->value;}
			if($set->name == 'home hosting4 LAN'){$product1Hosting4LAN = $set->value;}
			if($set->name == 'home hosting4 Application'){$product1Hosting4Application = $set->value;}
			if($set->name == 'home hosting4 Concurrent Calls'){$product1Hosting4ConcurrentCalls = $set->value;}
			if($set->name == 'home hosting4 Billing'){$product1Hosting4Billing = $set->value;}
			if($set->name == 'home hosting4 Apps'){$product1Hosting4Apps = $set->value;}
			if($set->name == 'home hosting4 Service'){$product1Hosting4Service = $set->value;}
			
			if($set->name == 'homehosting1buttonname'){$product1Hosting1buttonname = $set->value;}
			if($set->name == 'homehosting2buttonname'){$product1Hosting2buttonname = $set->value;}
			if($set->name == 'homehosting3buttonname'){$product1Hosting3buttonname = $set->value;}
			if($set->name == 'homehosting4buttonname'){$product1Hosting4buttonname = $set->value;}
			
			if($set->name == 'homeHostingPlanSharedDataUrl'){ $product1HostingPlanSharedDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanVPSDataUrl'){ $product1HostingPlanVPSDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanResellerDataUrl'){ $product1HostingPlanResellerDataUrl = $set->value;}
			if($set->name == 'homeHostingPlanDedicatedDataUrl'){ $product1HostingPlanDedicatedDataUrl = $set->value;}
			
		}
	}
?>
<div class="container">
  <div class="row">
    <div class="col-md-9 col-sm-9 col-xs-12">
      <div class="form">
      <h3 style="margin-top:-20px;text-transform:uppercase;">Voip Servers Hosting Plans</h3>
        <form action="<?php echo 'admincontroller/update_voip_server_hosting_plan'?>" method="post">
          <table style="width:100%;">
            <tr>
              <td>Hosting Plans Title
              <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
				?>
              <br> 
                <input type="text"  name="homeHostingPlans" value="<?php if(isset($product1HostingPlans)&& !empty($product1HostingPlans))echo $product1HostingPlans;?> " style="width:100%;min-height:50px;font-size:16px;"></td>
            </tr>
            <tr>
              <td><br>Hosting Plans Description<br>
                <textarea name="homeHostingPlansbody" value="<?php if(isset($product1HostingPlansbody)&& !empty($product1HostingPlansbody))echo $product1HostingPlansbody;?>" style="width:100%;height:100px;font-size:16px;" ><?php if(isset($product1HostingPlansbody)&& !empty($product1HostingPlansbody))echo $product1HostingPlansbody;?></textarea>
                </td>
            </tr>
            <tr>
              	<td>
        <table>
        	<tr>
            	<th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>
            <tr>
            	<th>Plan1</th>
                <th>Plan2</th>
                <th>Plan3</th>
                <th>Plan4</th>
            </tr>              
            <tr>
                <td><br>Price<br /><input type="text" name="homeHostingPlans1Price" value="<?php if(isset($product1HostingPlans1Price))echo $product1HostingPlans1Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans2Price" value="<?php if(isset($product1HostingPlans2Price))echo $product1HostingPlans2Price ?>" class="bgc"/></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans3Price" value="<?php if(isset($product1HostingPlans3Price))echo $product1HostingPlans3Price ?>" /></td>
                <td><br>Price<br /><input type="text" name="homeHostingPlans4Price" value="<?php if(isset($product1HostingPlans4Price))echo $product1HostingPlans4Price ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans1Name" value="<?php if(isset($product1HostingPlans1Name))echo $product1HostingPlans1Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans2Name" value="<?php if(isset($product1HostingPlans2Name))echo $product1HostingPlans2Name ?>" class="bgc"/></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans3Name" value="<?php if(isset($product1HostingPlans3Name))echo $product1HostingPlans3Name ?>" /></td>
                <td><br>Server Name<br /><input type="text" name="homeHostingPlans4Name" value="<?php if(isset($product1HostingPlans4Name))echo $product1HostingPlans4Name ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>processor<br /><input type="text" name="homehosting1processor" value="<?php if(isset($product1Hosting1processor))echo $product1Hosting1processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting2processor" value="<?php if(isset($product1Hosting2processor))echo $product1Hosting2processor ?>" class="bgc"/></td>
                <td><br>processor<br /><input type="text" name="homehosting3processor" value="<?php if(isset($product1Hosting3processor))echo $product1Hosting3processor ?>" /></td>
                <td><br>processor<br /><input type="text" name="homehosting4processor" value="<?php if(isset($product1Hosting4processor))echo $product1Hosting4processor ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>RAM<br /><input type="text" name="homehosting1RAM" value="<?php if(isset($product1Hosting1RAM))echo $product1Hosting1RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting2RAM" value="<?php if(isset($product1Hosting2RAM))echo $product1Hosting2RAM ?>" class="bgc"/></td>
                <td><br>RAM<br /><input type="text" name="homehosting3RAM" value="<?php if(isset($product1Hosting3RAM))echo $product1Hosting3RAM ?>" /></td>
                <td><br>RAM<br /><input type="text" name="homehosting4RAM" value="<?php if(isset($product1Hosting4RAM))echo $product1Hosting4RAM ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>HDD<br /><input type="text" name="homehosting1HDD" value="<?php if(isset($product1Hosting1HDD))echo $product1Hosting1HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting2HDD" value="<?php if(isset($product1Hosting2HDD))echo $product1Hosting2HDD ?>" class="bgc"/></td>
                <td><br>HDD<br /><input type="text" name="homehosting3HDD" value="<?php if(isset($product1Hosting3HDD))echo $product1Hosting3HDD ?>" /></td>
                <td><br>HDD<br /><input type="text" name="homehosting4HDD" value="<?php if(isset($product1Hosting4HDD))echo $product1Hosting4HDD ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>OS<br /><input type="text" name="homehosting1OS" value="<?php if(isset($product1Hosting1OS))echo $product1Hosting1OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting2OS" value="<?php if(isset($product1Hosting2OS))echo $product1Hosting2OS ?>" class="bgc"/></td>
                <td><br>OS<br /><input type="text" name="homehosting3OS" value="<?php if(isset($product1Hosting3OS))echo $product1Hosting3OS ?>" /></td>
                <td><br>OS<br /><input type="text" name="homehosting4OS" value="<?php if(isset($product1Hosting4OS))echo $product1Hosting4OS ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>LAN<br /><input type="text" name="homehosting1LAN" value="<?php if(isset($product1Hosting1LAN))echo $product1Hosting1LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting2LAN" value="<?php if(isset($product1Hosting2LAN))echo $product1Hosting2LAN ?>" class="bgc"/></td>
                <td><br>LAN<br /><input type="text" name="homehosting3LAN" value="<?php if(isset($product1Hosting3LAN))echo $product1Hosting3LAN ?>" /></td>
                <td><br>LAN<br /><input type="text" name="homehosting4LAN" value="<?php if(isset($product1Hosting4LAN))echo $product1Hosting4LAN ?>" class="bgc"/></td>
            </tr>
            
            <tr>
                <td><br>Application<br /><input type="text" name="homehosting1Application" value="<?php if(isset($product1Hosting1Application))echo $product1Hosting1Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting2Application" value="<?php if(isset($product1Hosting2Application))echo $product1Hosting2Application ?>" class="bgc"/></td>
                <td><br>Application<br /><input type="text" name="homehosting3Application" value="<?php if(isset($product1Hosting3Application))echo $product1Hosting3Application ?>" /></td>
                <td><br>Application<br /><input type="text" name="homehosting4Application" value="<?php if(isset($product1Hosting4Application))echo $product1Hosting4Application ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting1ConcurrentCalls" value="<?php if(isset($product1Hosting1ConcurrentCalls))echo $product1Hosting1ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting2ConcurrentCalls" value="<?php if(isset($product1Hosting2ConcurrentCalls))echo $product1Hosting2ConcurrentCalls ?>" class="bgc"/></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting3ConcurrentCalls" value="<?php if(isset($product1Hosting3ConcurrentCalls))echo $product1Hosting3ConcurrentCalls ?>" /></td>
                <td><br>Concurrent Calls<br /><input type="text" name="homehosting4ConcurrentCalls" value="<?php if(isset($product1Hosting4ConcurrentCalls))echo $product1Hosting4ConcurrentCalls ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Billing<br /><input type="text" name="homehosting1Billing" value="<?php if(isset($product1Hosting1Billing))echo $product1Hosting1Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting2Billing" value="<?php if(isset($product1Hosting2Billing))echo $product1Hosting2Billing ?>" class="bgc"/></td>
                <td><br>Billing<br /><input type="text" name="homehosting3Billing" value="<?php if(isset($product1Hosting3Billing))echo $product1Hosting3Billing ?>" /></td>
                <td><br>Billing<br /><input type="text" name="homehosting4Billing" value="<?php if(isset($product1Hosting4Billing))echo $product1Hosting4Billing ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Apps<br /><input type="text" name="homehosting1Apps" value="<?php if(isset($product1Hosting1Apps))echo $product1Hosting1Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting2Apps" value="<?php if(isset($product1Hosting2Apps))echo $product1Hosting2Apps ?>" class="bgc"/></td>
                <td><br>Apps<br /><input type="text" name="homehosting3Apps" value="<?php if(isset($product1Hosting3Apps))echo $product1Hosting3Apps ?>" /></td>
                <td><br>Apps<br /><input type="text" name="homehosting4Apps" value="<?php if(isset($product1Hosting4Apps))echo $product1Hosting4Apps ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Service<br /><input type="text" name="homehosting1Service" value="<?php if(isset($product1Hosting1Service))echo $product1Hosting1Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting2Service" value="<?php if(isset($product1Hosting2Service))echo $product1Hosting2Service ?>" class="bgc"/></td>
                <td><br>Service<br /><input type="text" name="homehosting3Service" value="<?php if(isset($product1Hosting3Service))echo $product1Hosting3Service ?>" /></td>
                <td><br>Service<br /><input type="text" name="homehosting4Service" value="<?php if(isset($product1Hosting4Service))echo $product1Hosting4Service ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Name<br /><input type="text" name="homehosting1buttonname" value="<?php if(isset($product1Hosting1buttonname))echo $product1Hosting1buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting2buttonname" value="<?php if(isset($product1Hosting2buttonname))echo $product1Hosting2buttonname ?>" class="bgc"/></td>
                <td><br>Button Name<br /><input type="text" name="homehosting3buttonname" value="<?php if(isset($product1Hosting3buttonname))echo $product1Hosting3buttonname ?>" /></td>
                <td><br>Button Name<br /><input type="text" name="homehosting4buttonname" value="<?php if(isset($product1Hosting4buttonname))echo $product1Hosting4buttonname ?>" class="bgc"/></td>
            </tr>
            <tr>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanSharedDataUrl" value="<?php if(isset($product1HostingPlanSharedDataUrl))echo $product1HostingPlanSharedDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanVPSDataUrl" value="<?php if(isset($product1HostingPlanVPSDataUrl))echo $product1HostingPlanVPSDataUrl ?>" class="bgc"/></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanResellerDataUrl" value="<?php if(isset($product1HostingPlanResellerDataUrl))echo $product1HostingPlanResellerDataUrl ?>" /></td>
                <td><br>Button Url<br /><input type="text" name="homeHostingPlanDedicatedDataUrl" value="<?php if(isset($product1HostingPlanDedicatedDataUrl))echo $product1HostingPlanDedicatedDataUrl ?>" class="bgc"/></td>
            </tr>
        </table>
                </td>
            </tr>
            
            <tr>
              <td><input type="submit" value="Update" class="register" style="margin-top:30px;"/></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
