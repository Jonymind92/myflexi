<?php
	$setting = $this->db->query("select * from t_settings")->result();
	$facebook='';
	$googleplus='';
	$twitter='';
	$forum='';
	$loginlink='';
	$registerlink='';
	$phone='';
	$email='';
	$emaillink='';
	$footerCopyrighttext='';
	
	$aboutcompany='';
	$address='';
	
	if(isset($setting)&& !empty($setting))
	{
		foreach($setting as $set)
		{
			if($set->name == 'facebook'){$facebook = $set->value;}
			if($set->name == 'google plus'){$googleplus = $set->value;}
			if($set->name == 'twitter'){$twitter = $set->value;}
			if($set->name == 'forum'){$forum = $set->value;}
			
			if($set->name == 'Login Link'){$loginlink = $set->value;}
			if($set->name == 'Register Link'){$registerlink = $set->value;}
			if($set->name == 'phone'){$phone = $set->value;}
			if($set->name == 'servermail'){$email = $set->value;}
			if($set->name == 'E-mail us link'){$emaillink = $set->value;}
			if($set->name == 'Footer Copyright text'){$footerCopyrighttext = $set->value;}
			
			if($set->name == 'About Company work'){$aboutcompany = $set->value;}
			if($set->name == 'Address'){$address = $set->value;}
		}
	}
?>


<!DOCTYPE html>
<!--[if lt IE 7 ]><html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]><html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]><html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]><html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="js_active  vc_desktop  vc_transform  vc_transform  vc_transform js" lang="en-US">
<!--<![endif]-->
<head>
<base href="<?php echo base_url();?>">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="css/a34e7f98a8ceaec80db862e8a574ab8e.css" data-minify="1">
<link rel="stylesheet" href="css/4911e4fb07c647bb97f681d573eab9ca.css" data-minify="1">
<link rel="stylesheet" href="css/3f565f564a220364e406f29f879dcfa8.css" data-minify="1">
<link rel="stylesheet" href="css/27a4b03e4d1b5c49156047301ad1c86a.css" data-minify="1">
<link rel="stylesheet" href="css/7c7e6c086e14d6a1829ace6d2b4394ba.css" data-minify="1">
<link rel="stylesheet" href="css/e25a2ba6128ca5a232e87ebd7c79a3c9.css" data-minify="1">
<link rel="stylesheet" href="css/ee0837a1460e7ae1cd06d711b4d6ea89.css" data-minify="1">
<link rel="stylesheet" href="css/ea6d7d8a344a3de364ab93f9b6208358.css" data-minify="1">
<link rel="stylesheet" href="css/9c1fdbdd658f6e0321e299a3d0b61a77.css" data-minify="1">
<link rel="stylesheet" href="css/6c2143998c0aca509f0619b90f30f8e6.css" data-minify="1">
<link rel="stylesheet" href="css/77f52756d5252b644828155974aa014f.css" data-minify="1">
<style>
.navbar-toggle {position: relative;float: none;padding: 12px 10px;margin-top: -55px;margin-right: 0px;margin-bottom: 0;background-color: transparent;border: 0px solid transparent;border-radius: 0;background: #272727;cursor:pointer;}
.navbar-nav > li > a{font-weight:bold;}
</style>

<script async src="js/lazyload.js"></script>
<script src="js/5b185a99fbf5165813a74edffc366acf.js" data-minify="1"></script>
<script src="js/ae69a70aae0aebad81df0530103fd95e.js" data-minify="1"></script>
<script src="js/af6373799ec5285d295c1cee3a92527e.js" data-minify="1"></script>
<script src="js/97577f70046fa1d45099722137154580.js" data-minify="1"></script>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
<link rel="pingback" href="http://fluentthemes.com/wp/zionhost/xmlrpc.php">
<link rel="shortcut icon" href="http://dhakasoft.ws/contents/favicon.ico">

<title>DhakaSoft Network</title>

<link rel="dns-prefetch" href="http://s.w.org/">
<link rel="dns-prefetch" href="http://fonts.gstatic.com/">
<link rel="alternate" type="application/rss+xml" title="Zionhost » Feed" href="http://fluentthemes.com/wp/zionhost/feed/">
<link rel="alternate" type="application/rss+xml" title="Zionhost » Comments Feed" href="http://fluentthemes.com/wp/zionhost/comments/feed/">
<link rel="stylesheet" id="zionhost-blue-css" href="css/blue.css" type="text/css" media="all">
<script type="text/javascript">/*  */
var wc_add_to_cart_params = {"ajax_url":"\/wp\/zionhost\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/wp\/zionhost\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"http:\/\/fluentthemes.com\/wp\/zionhost\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/*  */</script>
<link rel="https://api.w.org/" href="http://fluentthemes.com/wp/zionhost/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://fluentthemes.com/wp/zionhost/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://fluentthemes.com/wp/zionhost/wp-includes/wlwmanifest.xml">
<meta name="generator" content="WordPress 4.6.1">
<meta name="generator" content="WooCommerce 2.6.4">
<link rel="canonical" href="http://fluentthemes.com/wp/zionhost/">
<link rel="shortlink" href="http://fluentthemes.com/wp/zionhost/">
<link rel="alternate" type="application/json+oembed" href="http://fluentthemes.com/wp/zionhost/wp-json/oembed/1.0/embed?url=http%3A%2F%2Ffluentthemes.com%2Fwp%2Fzionhost%2F">
<link rel="alternate" type="text/xml+oembed" href="http://fluentthemes.com/wp/zionhost/wp-json/oembed/1.0/embed?url=http%3A%2F%2Ffluentthemes.com%2Fwp%2Fzionhost%2F&amp;format=xml">
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress.">
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://fluentthemes.com/wp/zionhost/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><!--[if IE  8]><link rel="stylesheet" type="text/css" href="http://fluentthemes.com/wp/zionhost/wp-content/plugins/js_composer/assets/css/vc-ie8.min.css" media="screen"><![endif]-->
<style id="custom-style">
.site_wrapper {
	background: #fff none repeat scroll 0 0
}
.footer-cross {
	padding-top: 0
}
.woocommerce ul.products li.product, .woocommerce-page ul.products li.product {
	width: 30%;
	margin: 0 3% 2.992em 0
}

span{
    border: 0;
    font-family: inherit;
    font-size: 16px;
    font-style: inherit;
    font-weight: inherit;
    margin: 0;
    outline: 0;
    padding: 0;
    vertical-align: baseline;
}
.section-header {
    text-align: center;
    padding: 75px 0;
}
.section-header h2 {
    padding-bottom: 10px;
    line-height: 40px;
    position: relative;
    display: inline-block;
    font-size: 45px;
    text-transform: uppercase;
    margin-top: 0;
    margin-bottom: 0;
}
.focus {
    padding-bottom: 100px;
    overflow: hidden;
    background: #FFFFFF;
}
.focus-box .service-icon {
    margin-bottom: 30px;
    width: 145px;
    height: 145px;
    margin: auto;
    border-radius: 50%;
    border: 10px solid #ececec;
    margin-bottom: 20px;
    position: relative;
    -webkit-transition: all 0.2s ease-in-out;
    transition: all 0.2s ease-in-out;
}
.focus-box .service-icon .pixeden {
    border-radius: 50%;
    margin: auto;
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    display: block;
}
.focus .row .focus-box {
    display: inline-block;
    float: none !important;
    margin-right: -4px;
    vertical-align: top;
    margin-bottom: 25px;
}
.gcl{border: 1px solid #34D293;width:125px;margin-bottom:20px;}
.bcl{border: 1px solid #3AB0E2;width:125px;margin-bottom:20px;}
.ycl{border: 1px solid #F7D861;width:125px;margin-bottom:20px;}
.rcl{border: 1px solid #E96656;width:125px;margin-bottom:20px;}
.gc:hover{border-color:#34D293;}
.bc:hover{border-color:#3AB0E2;}
.yc:hover{border-color:#F7D861;}
.rc:hover{border-color:#E96656;}


.bg_parallax {
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
}
.lsc{margin-top:40px;}
form textarea{width:270px;height:80px;}
.fsm{margin-left:100px;}
@media only screen and (max-width: 639px) {
.woocommerce ul.products li.product, .woocommerce-page ul.products li.product {
	width: 100%;
	margin: auto
}
}
@media(max-width: 767px)
{
	.ts-top-footer .contact-info span i {font-size: 10px;color: #fff;padding: 7px 0 0 0;}
	.ts-top-footer .contact-info span {text-align: center;height: 20px;line-height: 10px;width: 20px;margin-right: 0px;}
	.ts-top-footer .contact-info a {color: #fff;font-size: 60%;font-weight: 300;}
	.ts-top-footer .contact-info span:hover{height: 20px;line-height: 10px;width: 20px;position:fixed}
	.ts-top-footer .contact-info span i {font-size: 10px;color: #fff;padding:0;}
	.fmp{margin:0;padding:0;}
	.lsc{margin-top:10px;}	
	.section10 { margin-top: 15px;}
	.title h2 em{margin-top:15px;}
	.title h2{font-size: 20px;}
	.price-col ul.plan-list li {height: 30px;line-height: 30px;}
	.crossed_shape{margin:0px !important;}
	.fsm{margin-left:0px;}
}
#style-selector {
	top: 145px !important
}
</style>
<noscript>
<style type="text/css">
.wpb_animate_when_almost_visible {
	opacity: 1
}
.active{color:#267AE9;}
</style>
</noscript>
<script data-no-minify="1" data-cfasync="false">(function(w,d){function a(){var b=d.createElement("script");b.async=!0;b.src="http://fluentthemes.com/wp/zionhost/wp-content/plugins/wp-rocket/inc/front/js/lazyload.1.0.5.min.js";var a=d.getElementsByTagName("script")[0];a.parentNode.insertBefore(b,a)}w.attachEvent?w.attachEvent("onload",a):w.addEventListener("load",a,!1)})(window,document);</script>
<link rel="stylesheet" media="screen" href="css/color-switcher.css">
<link rel="alternate stylesheet" type="text/css" href="css/blue.css" title="blue">
<link rel="alternate stylesheet" type="text/css" href="css/red.css" title="red">
<link rel="alternate stylesheet" type="text/css" href="css/orange.css" title="orange">
<link rel="alternate stylesheet" type="text/css" href="css/olive.css" title="olive">
<link rel="alternate stylesheet" type="text/css" href="css/green.css" title="green">
<link rel="alternate stylesheet" type="text/css" href="css/pink.css" title="pink">
<link rel="alternate stylesheet" type="text/css" href="css/violet.css" title="violet">
<link rel="alternate stylesheet" type="text/css" href="css/sea.css" title="sea">
<link rel="alternate stylesheet" type="text/css" href="css/lightblue.css" title="lightblue">
<link rel="alternate stylesheet" type="text/css" href="css/lightgreen.css" title="lightgreen">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head><body class="home page page-id-7 page-template page-template-page-vc page-template-page-vc-php wpb-js-composer js-comp-ver-4.12.1 vc_responsive bg-cover">
<div class="site_wrapper">
  <header>
    <div id="topHeader">
      <div class="wrapper">
        <div class="top_nav">
          <div class="container">
            <ul class="left">
              <li><a href="<?php if(isset($facebook)&& !empty($facebook)){ echo $facebook;}else{echo '#';}?>"><i class="fa fa-facebook"></i></a></li>
              <li><a href="<?php if(isset($twitter)&& !empty($twitter)) {echo $twitter;}else{echo '#';}?>"><i class="fa fa-twitter"></i></a></li>
              <li><a href="<?php if(isset($googleplus)&& !empty($forum)) {echo $googleplus;}else{echo '#';}?>"><i class="fa fa-google-plus"></i></a></li>
              <li class="last"><a href="<?php if(isset($forum)&& !empty($forum)) {echo $forum;}else{echo '#';}?>"><i class="fa fa-commenting"></i></a></li>
            </ul>
            <ul class="right-nav">
              <li><a href="<?php if(isset($loginlink)&& !empty($loginlink)){ echo $loginlink;}else{echo '#';}?>"><i class="fa fa-user"></i> Login</a></li>
             <li><a href="<?php if(isset($registerlink)&& !empty($registerlink)){ echo $registerlink;}else{echo '#';}?>"><i class="fa fa-user"></i> Register</a></li>
              <li class="phoneno"><i class="fa fa-phone"></i> <?php if(isset($phone)&& !empty($phone)){ echo $phone;}else{echo '123456789';}?></li>
              <li class="last"><a href="<?php if(isset($emaillink)&& !empty($emaillink)){ echo $emaillink;}else{echo '#';}?>"><i class="fa fa-envelope-o"></i> E-mail Us</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="scrollto_sticky" style="z-index: 9999; position: static; top: auto;">
      <div class="container">
        <div class="logo"><a href="<?php echo ''?>" id="logo">Logo</a></div>
        <div class="menu_main new_floating">
          <div class="navbar yamm navbar-default new_m_bottom">
            <div class="navbar-header">
              <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"> <span>Menu</span>
                <button type="button"> <i class="fa fa-bars"></i></button>
              </div>
            </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
              <nav class="menu-main-menu-container">
                <ul id="menu-main-menu" class="nav navbar-nav menu-even">
                 
                 <li id="nav-menu-item-844" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a <?php if(isset($menu)&&$menu=='home') echo 'class="active"'?> href="<?php echo 'main/index'?>" class="menu-link sub-menu-link">HOME</a></li>
                  
                  
                  
                  
                  <li id="nav-menu-item-844" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a <?php if(isset($menu)&&$menu=='products1') echo 'class="active"'?> href="<?php echo 'main/voip_server'?>" class="menu-link sub-menu-link">SWITCH SERVERS</a></li>
                  
                  <li id="nav-menu-item-844" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a <?php if(isset($menu)&&$menu=='products2') echo 'class="active"'?> href="<?php echo 'main/easy_billing'?>" class="menu-link sub-menu-link">EASY BILLING</a></li>
                  
                  <li id="nav-menu-item-844" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a <?php if(isset($menu)&&$menu=='products3') echo 'class="active"'?> href="<?php echo 'main/easy_recharge'?>" class="menu-link sub-menu-link">EASY RECHARGE</a></li>
                  
                  <li id="nav-menu-item-844" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a <?php if(isset($menu)&&$menu=='service') echo 'class="active"'?> href="<?php echo 'main/service_page'?>" class="menu-link sub-menu-link">SERVICE</a></li>
                  
                  
                  
                  
                  <!--<li id="nav-menu-item-419" class="dropdown  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="<?php echo ''?>" class="menu-link dropdown-toggle">Portfolio</a>
                    <ul class="dropdown-menu menu-odd  menu-depth-1">
                      <li id="nav-menu-item-86" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php echo ''?>" class="menu-link sub-menu-link">Portfolio Columns 4</a></li>
                      <li id="nav-menu-item-471" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php echo ''?>" class="menu-link sub-menu-link">Portfolio Columns 3</a></li>
                      
                    </ul>
                  </li>
                  <li id="nav-menu-item-278" class="dropdown  menu-item-even menu-item-depth-0 wide-menu menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="<?php echo ''?>" class="menu-link dropdown-toggle">Elements</a>
                    <ul class="dropdown-menu menu-odd  menu-depth-1">
                      <li id="nav-menu-item-470" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-zionhost_mega_menu">
                        <div class="yamm-content">
                          <div class="row list-unstyled">
                            <div class="col-sm-3">
                              <ul>
                                <li>
                                  <p> Elements 1</p>
                                </li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-plus-circle"></i> Accordion</a></li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-external-link-square"></i> Call to Action</a></li>
                              </ul>
                            </div>
                            <div class="col-sm-3">
                              <ul>
                                <li>
                                  <p> Elements 2</p>
                                </li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-tags"></i> Icon Boxes</a></li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-qrcode"></i> Tabs</a></li>
                              </ul>
                            </div>
                            <div class="col-sm-3">
                              <ul>
                                <li>
                                  <p> Elements 3</p>
                                </li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-user"></i> Team Member</a></li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-pencil-square"></i> Sample Menu</a></li>
                              </ul>
                            </div>
                            <div class="col-sm-3">
                              <ul>
                                <li>
                                  <p> Elements 4</p>
                                </li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-tags"></i> Icon Boxes</a></li>
                                <li><a href="<?php echo ''?>"><i class="fa fa-qrcode"></i> Tabs</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </li>
                  <li id="nav-menu-item-805" class="dropdown  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="<?php echo ''?>" class="menu-link dropdown-toggle">Shop</a>
                    <ul class="dropdown-menu menu-odd  menu-depth-1">
                      <li id="nav-menu-item-811" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php echo ''?>" class="menu-link sub-menu-link">Shop Right Sidebar</a></li>
                      <li id="nav-menu-item-813" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-taxonomy menu-item-object-product_cat"><a href="<?php echo ''?>" class="menu-link sub-menu-link">Shop Left Sidebar</a></li>
                    </ul>
                  </li>
                  <li id="nav-menu-item-56" class="dropdown  menu-item-even menu-item-depth-0 menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="<?php echo ''?>" class="menu-link dropdown-toggle">Blog</a>
                    <ul class="dropdown-menu menu-odd  menu-depth-1">
                      <li id="nav-menu-item-139" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php echo ''?>" class="menu-link sub-menu-link">Blog Standard</a></li>

                    </ul>
                  </li>-->
                  
                  <li id="nav-menu-item-844" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a <?php if(isset($menu)&&$menu=='aboutus') echo 'class="active"'?> href="<?php echo 'main/aboutus'?>" class="menu-link sub-menu-link">ABOUTUS</a></li>
                  
                  <li id="nav-menu-item-844" class="  menu-item-odd menu-item-depth-1 menu-item menu-item-type-post_type menu-item-object-page"><a <?php if(isset($menu)&&$menu=='contact') echo 'class="active"'?> href="<?php echo 'main/contact_page'?>" class="menu-link sub-menu-link">CONTACT</a></li>
                  
                  
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div style="display: none; width: 1263px; height: 78px; float: left;"></div>
  </header>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  <div class="clearfix"></div>
  
  <!------  Content   Start ----------------------------------------------------------------------------->
  
  <?php if(isset($content)) echo $content;?>
  
  <!------  Content   End ----------------------------------------------------------------------------->
  
  
  <div class="clearfix lsc" style=""></div>
  
  <!-------- Link Section ---------------------------------------------------------------------------------------------------->
  <style>
  	.ts-section-top-footer {background: #54b4f2;}
	.ts-top-footer .contact-info:first-child { border: none;}
	.contact-info {text-align:center;height: 70px;line-height: 70px;border-left: 1px solid rgba(255,255,255,0.20);padding-top: 7px;}
  	.contact-info span {background: #54b4f2;}
	.contact-info span{text-align: center;height: 48px;line-height: 48px;width: 48px;border: 2px solid #fff;border-radius: 68px;-moz-border-radius: 68px;-webkit-border-radius: 68px;-ms-border-radius: 68px;-o-border-radius: 68px;text-align: center;margin-right: 15px;display: inline-block;-webkit-transform: scale(1);-moz-transform: scale(1);-ms-transform: scale(1);-o-transform: scale(1);transform: scale(1);background: #54b4f2;}
	.contact-info span:hover {text-align: center;height: 48px;line-height: 48px;width: 48px;border: 4px solid #D2FFFF;border-radius: 48px;-moz-border-radius: 48px;-webkit-border-radius: 48px;-ms-border-radius: 48px;-o-border-radius: 68px;text-align: center;margin: 10px 0 0 0;display: inline-block;background: #FFF;animation-delay: 2s;-webkit-animation-delay: 5s;-moz-animation-delay: 2s;-ms-animation-delay: 2s;-o-animation-delay: 2s;}
	.contact-info span:hover i {font-size: 20px;color: #54b4f2;}
	.contact-info span i {font-size: 20px;color: #fff;}
	.fa {display: inline-block;font: normal normal normal 14px/1 FontAwesome;font-size: inherit;-moz-osx-font-smoothing: grayscale;transform: translate(0, 0);}
	.contact-info a {color: #fff;font-size: 150%;font-weight: 300;}
	.imgspace { width: 11%;min-height: 40px;max-height: 80px;}
  </style>
  
  <div class="ts-section-top-footer">    
                    <div class="ts-top-footer">
                <div class="container">
                    <div class="row">
                    		<!--<div class="col-md-12 col-sm-12 col-xs-12 fmp">
                         		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 ts-contact-email-info contact-info">
                            			<span><i class="fa fa-envelope-o"></i></span>
                            			<a href="<?php if(isset($emaillink))echo $emaillink;?>">Email us</a>
                        		</div>
                                 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 ts-contact-email-info contact-info fmp">
                            			<span><i class="fa fa-phone"></i></span>
                            			<a href=""><?php if(isset($phone))echo $phone;?></a>
                       			</div>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 ts-contact-email-info contact-info fmp">
                            		<span><i class="fa fa-comment-o"></i></span>
                            		<a href="javascript:$zopim.livechat.window.show()">Live chat with us</a>
                        		</div>
                        </div>-->
                                                                                         
                    </div>                            
                </div>
            </div>
                                            
    </div>
  
  
  
  
 <!---------------------------------------------------------------------------------------------------------------------------> 
  
  
  <style>
  	.crossed_shape {float: left;height: 1px;margin: 0 0 60px;padding:0;width: 100%;}
	.style-1,.style-2,.style-3{background:#DFDFDF;border-radius:8px;padding-left:10px;}
	.btnsend {border-radius: 60px;background-color: #54B4F2;font-weight: bold;padding: 11px 42px;color: #fff;font-family: 'Poppins','Open Sans', Helvetica, Arial, sans-serif;display: inline-block;cursor: pointer;text-align: center;box-sizing: border-box;height: 35px;line-height: 1px;margin-left: 60px;
}
.ms{color:#00F}
.ems{color:#F00}
  </style>
  <footer>
    <div id="show_footer" class="footer seven">
      <div class="crossed_shape"></div>
      <div class="container-fluid" style="width:90%;margin:auto;">
      
        <!-----------------  1 ---------------------------------------------->
        <div class="one_fourth last animate-in" data-anim-type="fade-in-right" data-anim-delay="400" style="margin-right:20px !important;">
          <h4 class="white">About Company</h4>
          <div class="title_line"></div>
          <p><?php if(isset($aboutcompany))echo $aboutcompany;?></p>
          <div class="clearfix margin_top1"></div>
          <ul class="faddress">
            <li><i class="fa fa-map-marker fa-lg"></i>&nbsp;&nbsp;<?php if(isset($address))echo $address;?></li>
            <li><i class="fa fa-phone"></i>&nbsp;&nbsp;<?php if(isset($phone))echo $phone;?></li>
            <li><a href="mailto:info@yourdomain.com"><i class="fa fa-envelope"></i>&nbsp;&nbsp;<?php if(isset($email))echo $email;?></a></li>
          </ul>
          <div class="clearfix margin_top1"></div>
          
          
          
          <ul class="social_icons animate-in" data-anim-type="fade-in-right" data-anim-delay="400">
            <li><a href="<?php if(isset($facebook)&& !empty($facebook)){ echo $facebook;}else{echo '#';}?>"><i class="fa fa-facebook"></i></a></li>
            <li><a href="<?php if(isset($twitter)&& !empty($twitter)){ echo $twitter;}else{echo '#';}?>"><i class="fa fa-twitter"></i></a></li>
            <li><a href="<?php if(isset($googleplus)&& !empty($googleplus)){ echo $googleplus;}else{echo '#';}?>"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="<?php if(isset($forum)&& !empty($forum)){ echo $forum;}else{echo '#';}?>"><i class="fa fa-commenting"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            <li class="last"><a href="#"><i class="fa fa-flickr"></i></a></li>
          </ul>
          
          
        </div>
        
         <!----------------- 2  ---------------------------------------------->
        <div class="one_fourth animate-in" data-anim-type="fade-in-right" data-anim-delay="200">
        	<div class="fsm"> 
          <h4 class="white">Product & Service</h4>
          <div class="title_line"></div>
          <ul class="listitem">
            <li id="menu-item-35" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-35"><i class="fa fa-angle-right"></i>&nbsp;<a href="<?php echo 'main/voip_server'?>">VOIP SERVERS</a></li>
            <li id="menu-item-36" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-36"><i class="fa fa-angle-right"></i>&nbsp;<a href="<?php echo 'main/easy_billing'?>">EASY BILLING</a></li>
            <li id="menu-item-37" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-37"><i class="fa fa-angle-right"></i>&nbsp;<a href="<?php echo 'main/easy_recharge'?>">EASY RECHARGE</a></li>
            <li id="menu-item-38" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-38"><i class="fa fa-angle-right"></i>&nbsp;<a href="<?php echo 'main/service_page'?>">SERVICE</a></li>
            <!--<li id="menu-item-39" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-39"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">Rackspace Community</a></li>
            <li id="menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-40"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">Developer Center</a></li>-->
          </ul>
          </div>
        </div>
        
         <!----------------  3 ----------------------------------------------->
        <div class="one_fourth animate-in" data-anim-type="fade-in-right" data-anim-delay="300">
        	<div class="fsm">
          <h4 class="white">Legal and Help</h4>
          <div class="title_line"></div>
          <ul class="listitem">
            <li id="menu-item-41" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-41"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">Contact Us</a></li>
            <li id="menu-item-42" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">My Account</a></li>
            <li id="menu-item-43" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-43"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">Legal &amp; Privacy</a></li>
            <li id="menu-item-44" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-44"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">Report Abuse</a></li>
            <li id="menu-item-45" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-45"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">Terms of Service</a></li>
            <li id="menu-item-46" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-46"><i class="fa fa-angle-right"></i>&nbsp;<a href="#">Subpoenas</a></li>
          </ul>
          </div>
        </div>
        
        <!-----------------   4 ---------------------------------------------->
        	<style>
			input, textarea {background: #f0f0f0;border-radius: 2px;border: none;box-shadow: none;margin-bottom: 0px;}
			.one_half{margin-bottom:0 !important}
		</style>
        <div class="one_fourth animate-in" data-anim-type="fade-in-right" data-anim-delay="100" style="margin-right:-20px;">
        		 <h4 class="white">Instant Query</h4>
               <form action="<?php echo 'main/contactmail2'?>" id="fcon" method="post" style="width:100%;">
                  <table style="width:100%;">
                    <tbody>
                      
                      <tr>
                        <td>Name<br>
                          <input name="name" id="name" class="style-2" type="text" style="width:270px;height:26px;"></td>
                      </tr>
                      <tr>
                        <td>Email<br>
                          <input name="email" class="style-1" style="width:270px;height:26px;"></td>
                      </tr>
                      <tr>
                        <td>Subject<br>
                          <input name="subject" class="style-1" type="text" style="width:270px;height:26px;"></td>
                      </tr>
                      <tr>
                        <td>Message<br>
                          <textarea name="message" class="style-3" style="height:80px;width:270px !important"></textarea></td>
                      </tr>
                      <tr>
                        <td><center>
                            <input value="Send" class="btnsend" type="submit">
                          </center></td>
                      </tr>
                    </tbody>
                  </table>
                </form>
                <?php
                	if(isset($_GET['sk'])&& !empty($_GET['sk']))echo '<label class="ms mymsg fl-r">'.$_GET['sk'].'</label>';
					if(isset($_GET['esk'])&& !empty($_GET['esk']))echo '<label class="ems mymsg fl-r">'.$_GET['esk'].'</label>';
				?>
        </div>
        
        
      </div>
    </div>
    
    
    
    <style>
		.copyrights .one_half .payments span {padding-top: 5px;float: left;margin: 0 3% 0 18%;color: #ddd;}
	</style>
    <div class="copyrights">
      <div class="container">
        <div class="one_half"><span><?php if(isset($footerCopyrighttext)&& !empty($footerCopyrighttext))echo $footerCopyrighttext;?></span></div>
        <div class="one_half last">
          <div class="payments"><span>Payments We Accept</span> <img src="img/card-02.png" alt=""> <img src="img/card-01.png" alt=""> <img src="img/card-04.png" alt=""> <img src="img/card-05.png" alt=""> <img src="img/card-03.png" alt=""></div>
        </div>
      </div>
    </div>
  </footer>
</div>
<div id="style-selector" style="left: 0px;" class="hide-me">
  <div class="style-selector-wrapper"> <span class="title">Choose Theme Options</span>
    <div> <span class="title-sub2">Predefined Color Skins</span>
      <ul class="styles">
        <li><a href="#" onclick="setActiveStyleSheet('default'); return false;" title="Blue"><span class="pre-color-skin1"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('red'); return false;" title="Red"><span class="pre-color-skin2"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('orange'); return false;" title="Orange"><span class="pre-color-skin3"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('olive'); return false;" title="Olive"><span class="pre-color-skin4"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('green'); return false;" title="Green"><span class="pre-color-skin5"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('pink'); return false;" title="Pink"><span class="pre-color-skin6"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('violet'); return false;" title="Violet"><span class="pre-color-skin7"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('sea'); return false;" title="Sea"><span class="pre-color-skin8"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('lightblue'); return false;" title="Light Blue"><span class="pre-color-skin9"></span></a></li>
        <li><a href="#" onclick="setActiveStyleSheet('lightgreen'); return false;" title="Light Green"><span class="pre-color-skin10"></span></a></li>
      </ul>
      <span class="title-sub2">Choose Layout:</span>
      <div class="styles">
        <ul class="layout-style">
          <li><a href="#" class="btn btn-grey">Wide</a></li>
          <li class="last"><a href="#" class="btn btn-grey">Boxed</a></li>
        </ul>
      </div>
      <a href="#" class="close icon-chevron-right"></a></div>
  </div>
</div>
<a href="#" class="scrollup" style="display: none;"></a> <script>(function($) {
  "use strict";
// makes sure the whole site is loaded
jQuery(window).load(function() {
	"use strict";
        // will first fade out the loading animation
	jQuery(".status").fadeOut();
        // will fade out the whole DIV that covers the website.
	jQuery(".preloader").delay(1000).fadeOut("slow");
})
})(jQuery);</script> <script>(function($) {
  "use strict";
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({

      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true

      // "singleItem:true" is a shortcut for:
      // items : 1, 
      // itemsDesktop : false,
      // itemsDesktopSmall : false,
      // itemsTablet: false,
      // itemsMobile : false

      });
    });
	})(jQuery);</script> <script type="text/javascript">jQuery(document).ready(function($) {
			// jQuery Validation
			$("#nesletter").validate({
				// if valid, post data via AJAX
				submitHandler: function() {
					var subscribefile_newsletter="http://fluentthemes.com/wp/zionhost/wp-content/themes/zionhost/subscribe/subscribe-newsletter.php";
					$.post(subscribefile_newsletter, { name: $("fname").val(), email: $("#email").val() }, function(data) {
						$('#newsletter_response').html(data);
					});
				},
				// all fields are required
				rules: {
					fname: {
						required: false
					},
					email: {
						required: false,
						email: false
					}
				}
			});
		});</script> <script type="text/javascript">jQuery(document).ready(function($) {
			// jQuery Validation
			$("#footer_signup").validate({
				// if valid, post data via AJAX
				submitHandler: function() {
					var subscribefile="http://fluentthemes.com/wp/zionhost/wp-content/themes/zionhost/subscribe/subscribe.php";
					$.post(subscribefile, { email: $("#email").val() }, function(data) {
						$('#footer_response').html(data);
					});
				},
				// all fields are required
				rules: {
					email: {
						required: true,
						email: true
					}
				}
			});
		});</script> 
		
		<script type="text/javascript">/*  */
var woocommerce_params = {"ajax_url":"\/wp\/zionhost\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/wp\/zionhost\/?wc-ajax=%%endpoint%%"};
/*  */</script> <script type="text/javascript">/*  */
var wc_cart_fragments_params = {"ajax_url":"\/wp\/zionhost\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/wp\/zionhost\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/*  */</script> <script type="text/javascript">/*  */
var prefix_object_name = {"error_while_ajax_request":"Error while ajax request","thank_you_your_email_has_been_sent":"Thank you, your email has been sent","please_try_again":"Please, fill in the required fields correctly!"};
/*  */</script> 
<script src="js/c8f5c7291533d6c44f4fb049cab4bbe5.js" data-minify="1"></script>
<script src="js/d74acbf7255d0ad2f01f8aefc69e2f34.js" data-minify="1"></script>

<script src="js/7942254cade8fc7038508f67209fd6c1.js" data-minify="1"></script>
<script src="js/13dabbe2570686a8bbc40e2f7e0c449f.js" data-minify="1"></script>
<script src="js/8ea296dc80b4cb919218c6ad60951568.js" data-minify="1"></script>
<script src="js/281dcadb2204310e3a7a77760efe884a.js" data-minify="1"></script>
<script src="js/8ff67ad3c1e13e0919b0314c5f82f302.js" data-minify="1"></script>
<script src="js/93d72ad06d967395569ce25fa69543c8.js" data-minify="1"></script>
<script src="js/2708e580f3fcf20af760f31308c03ba4.js" data-minify="1"></script>
<script src="js/3ca4d8fe15c30ebe73b6597de66eb2a9.js" data-minify="1"></script>
<script src="js/dd3f0cb9ad5953208f8fa87c79d3e008.js" data-minify="1"></script>
<script src="js/5010c85fa7c763d2ac232f44a326fe29.js" data-minify="1"></script>
</body>
</html>
